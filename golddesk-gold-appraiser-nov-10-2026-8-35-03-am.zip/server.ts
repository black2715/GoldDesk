import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to scrape real PNB gold rate from https://digigoldloan.pnb.bank.in/
async function fetchPnbGoldRate() {
  const urls = [
    'https://digigoldloan.pnb.bank.in/',
    'https://digigoldloan.pnb.bank.in/GoldLoan/Processor/CustomerLogin'
  ];

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache'
        },
        signal: AbortSignal.timeout(12000)
      });

      if (!response.ok) continue;

      const html = await response.text();

      // Pattern 1: Header pattern in digigoldloan.pnb.bank.in e.g. "22K: &#8377;12,309/gm" or "22K: ₹12,309/gm"
      const match22 = html.match(/22\s*K\s*:\s*(?:&#8377;|&#x20B9;|&rupee;|₹|Rs\.?)?\s*([\d,]+(?:\.\d+)?)\s*\/\s*(?:gm|g|gram)/i);
      const match24 = html.match(/24\s*K\s*:\s*(?:&#8377;|&#x20B9;|&rupee;|₹|Rs\.?)?\s*([\d,]+(?:\.\d+)?)\s*\/\s*(?:gm|g|gram)/i);

      // Pattern 2: CustomerLogin pattern e.g. "22 carat = ₹12309/gm"
      const fallback22 = html.match(/22\s*(?:carat|karat|ct|k)\s*[=:\-–]?\s*(?:&#8377;|&#x20B9;|&rupee;|₹|Rs\.?|INR)?\s*([\d,]+(?:\.\d{1,2})?)\s*\/\s*(?:gm|gms|g|gram)/i);

      let rate22 = 0;
      if (match22 && match22[1]) {
        rate22 = Math.round(Number(match22[1].replace(/,/g, '')));
      } else if (fallback22 && fallback22[1]) {
        rate22 = Math.round(Number(fallback22[1].replace(/,/g, '')));
      }

      let rate24 = 0;
      if (match24 && match24[1]) {
        rate24 = Math.round(Number(match24[1].replace(/,/g, '')));
      }

      if (rate22 > 1000 && rate22 < 100000) {
        return {
          ok: true,
          rate: rate22,
          rate24: rate24 || Math.round(rate22 * (24 / 22)),
          sourceUrl: url,
          fetchedAt: new Date().toISOString(),
          agriPercent: 85,
          nonAgriPercent: 68
        };
      }
    } catch (err: any) {
      console.warn(`[PNB Fetch Error for ${url}]:`, err?.message || err);
    }
  }

  throw new Error('Could not parse actual 22K gold rate from PNB. Please verify connection or enter manually.');
}

// Route: Real PNB Gold Rate
app.get('/api/rates/pnb', async (_req: Request, res: Response) => {
  try {
    const data = await fetchPnbGoldRate();
    res.json(data);
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error.message || 'Failed to fetch actual PNB gold rates',
      sourceUrl: 'https://digigoldloan.pnb.bank.in/'
    });
  }
});

// Route: Cloud Storage Connector verification / test
app.post('/api/cloud-storage/test', async (req: Request, res: Response) => {
  const { provider, accessToken } = req.body;
  if (!provider) {
    return res.status(400).json({ ok: false, error: 'Provider is required' });
  }

  try {
    if (provider === 'gdrive') {
      if (!accessToken) throw new Error('Google Drive access token is required');
      const testRes = await fetch('https://www.googleapis.com/drive/v3/about?fields=user,storageQuota', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!testRes.ok) throw new Error(`Google Drive returned status ${testRes.status}`);
      const info = await testRes.json();
      return res.json({ ok: true, provider: 'gdrive', user: info.user?.displayName || info.user?.emailAddress });
    }

    if (provider === 'onedrive') {
      if (!accessToken) throw new Error('OneDrive access token is required');
      const testRes = await fetch('https://graph.microsoft.com/v1.0/me/drive', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!testRes.ok) throw new Error(`OneDrive returned status ${testRes.status}`);
      const info = await testRes.json();
      return res.json({ ok: true, provider: 'onedrive', driveType: info.driveType });
    }

    if (provider === 'dropbox') {
      if (!accessToken) throw new Error('Dropbox access token is required');
      const testRes = await fetch('https://api.dropboxapi.com/2/users/get_current_account', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (!testRes.ok) throw new Error(`Dropbox returned status ${testRes.status}`);
      const info = await testRes.json();
      return res.json({ ok: true, provider: 'dropbox', name: info.name?.display_name });
    }

    return res.status(400).json({ ok: false, error: 'Unsupported provider' });
  } catch (err: any) {
    return res.status(400).json({ ok: false, error: err.message || 'Connection test failed' });
  }
});

// Setup Vite middleware in development or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GoldDesk Server running on port ${PORT}`);
  });
}

startServer();
