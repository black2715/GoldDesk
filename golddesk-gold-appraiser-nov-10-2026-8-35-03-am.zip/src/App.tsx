import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Customers } from './components/Customers';
import { Loans } from './components/Loans';
import { InspectionView } from './components/Inspection';
import { Settlements } from './components/Settlements';
import { Renewals } from './components/Renewals';
import { GoldRateCard } from './components/GoldRateCard';
import { Analytics } from './components/Analytics';
import { Settings } from './components/Settings';

// Modals
import { CustomerModal } from './components/modals/CustomerModal';
import { CustomerViewModal } from './components/modals/CustomerViewModal';
import { LoanModal } from './components/modals/LoanModal';
import { LoanViewModal } from './components/modals/LoanViewModal';
import { InspectionModal } from './components/modals/InspectionModal';
import { PaymentModal } from './components/modals/PaymentModal';
import { PaymentLogModal } from './components/modals/PaymentLogModal';
import { RenewalModal } from './components/modals/RenewalModal';
import { ReminderModal } from './components/modals/ReminderModal';
import { ReceivableModal } from './components/modals/ReceivableModal';
import { OfflineIndicator } from './components/OfflineIndicator';

import { Customer, Loan, Inspection, Payment } from './types';

function MainApp() {
  const { user, login } = useAuth();
  const { ready } = useData();

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Modals state
  const [customerModalData, setCustomerModalData] = useState<{ open: boolean; customer?: Customer | null }>({
    open: false
  });
  const [viewCustomer, setViewCustomer] = useState<Customer | null>(null);

  const [loanModalOpen, setLoanModalOpen] = useState(false);
  const [viewLoan, setViewLoan] = useState<Loan | null>(null);

  const [inspectionModalData, setInspectionModalData] = useState<{ open: boolean; inspection?: Inspection | null }>({
    open: false
  });

  const [paymentModalData, setPaymentModalData] = useState<{
    open: boolean;
    acct: 'a2' | 'hA1' | 'hA2';
    payment?: Payment | null;
    presetAmount?: number;
  }>({
    open: false,
    acct: 'a2'
  });
  const [paymentLogPayment, setPaymentLogPayment] = useState<Payment | null>(null);

  const [renewalLoan, setRenewalLoan] = useState<Loan | null>(null);
  const [reminderLoan, setReminderLoan] = useState<Loan | null>(null);
  const [receivableModalOpen, setReceivableModalOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[#f4f6fa] text-[#19243a]">
      {/* Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
      />

      {/* Main viewport */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          currentTab={currentTab}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        <main className="flex-1 max-w-[1550px] w-full mx-auto p-4 sm:p-6 lg:p-8">
          {/* If user is not yet logged in with Google, show Google Auth onboarding banner */}
          {!user && (
            <div className="mb-6 p-4 sm:p-5 bg-gradient-to-r from-[#111b30] to-[#1c2e50] text-white rounded-2xl shadow-sm border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <strong className="block text-sm sm:text-base font-extrabold text-white">
                  Welcome to GoldDesk
                </strong>
                <p className="text-xs text-slate-300 mt-1">
                  Sign in with your Google account to automatically synchronize data in real time across your PC, tablet, and mobile with persistent offline support.
                </p>
              </div>
              <button
                onClick={() => login()}
                className="shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 bg-white text-slate-900 rounded-xl text-xs font-bold transition shadow-sm hover:bg-slate-100 cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                Sign In with Google
              </button>
            </div>
          )}

          {/* Page Routing */}
          {currentTab === 'dashboard' && (
            <Dashboard
              onNavigate={setCurrentTab}
              onOpenNewLoan={() => setLoanModalOpen(true)}
              onOpenNewCustomer={() => setCustomerModalData({ open: true, customer: null })}
            />
          )}

          {currentTab === 'customers' && (
            <Customers
              onOpenNewCustomer={() => setCustomerModalData({ open: true, customer: null })}
              onEditCustomer={c => setCustomerModalData({ open: true, customer: c })}
              onViewCustomer={c => setViewCustomer(c)}
            />
          )}

          {currentTab === 'loans' && (
            <Loans
              onOpenNewLoan={() => setLoanModalOpen(true)}
              onViewLoan={l => setViewLoan(l)}
            />
          )}

          {currentTab === 'inspection' && (
            <InspectionView
              onOpenNewInspection={() => setInspectionModalData({ open: true, inspection: null })}
              onEditInspection={i => setInspectionModalData({ open: true, inspection: i })}
            />
          )}

          {currentTab === 'settlements' && (
            <Settlements
              onOpenPaymentModal={(acct, p, amt) =>
                setPaymentModalData({ open: true, acct, payment: p, presetAmount: amt })
              }
              onOpenLogModal={p => setPaymentLogPayment(p)}
            />
          )}

          {currentTab === 'renewals' && (
            <Renewals
              onOpenRenewModal={l => setRenewalLoan(l)}
              onOpenReminderModal={l => setReminderLoan(l)}
              onViewLoan={l => setViewLoan(l)}
            />
          )}

          {currentTab === 'rates' && <GoldRateCard />}

          {currentTab === 'analytics' && (
            <Analytics
              onOpenReceivableModal={() => setReceivableModalOpen(true)}
            />
          )}

          {currentTab === 'settings' && <Settings />}
        </main>
      </div>

      {/* Global Modals */}
      {customerModalData.open && (
        <CustomerModal
          customer={customerModalData.customer}
          onClose={() => setCustomerModalData({ open: false })}
        />
      )}

      {viewCustomer && (
        <CustomerViewModal
          customer={viewCustomer}
          onClose={() => setViewCustomer(null)}
          onOpenLoan={l => setViewLoan(l)}
        />
      )}

      {loanModalOpen && (
        <LoanModal
          onClose={() => setLoanModalOpen(false)}
        />
      )}

      {viewLoan && (
        <LoanViewModal
          loan={viewLoan}
          onClose={() => setViewLoan(null)}
        />
      )}

      {inspectionModalData.open && (
        <InspectionModal
          inspection={inspectionModalData.inspection}
          onClose={() => setInspectionModalData({ open: false })}
        />
      )}

      {paymentModalData.open && (
        <PaymentModal
          acct={paymentModalData.acct}
          payment={paymentModalData.payment}
          presetAmount={paymentModalData.presetAmount}
          onClose={() => setPaymentModalData({ open: false, acct: 'a2' })}
        />
      )}

      {paymentLogPayment && (
        <PaymentLogModal
          payment={paymentLogPayment}
          onClose={() => setPaymentLogPayment(null)}
        />
      )}

      {renewalLoan && (
        <RenewalModal
          loan={renewalLoan}
          onClose={() => setRenewalLoan(null)}
        />
      )}

      {reminderLoan && (
        <ReminderModal
          loan={reminderLoan}
          onClose={() => setReminderLoan(null)}
        />
      )}

      {receivableModalOpen && (
        <ReceivableModal
          onClose={() => setReceivableModalOpen(false)}
        />
      )}

      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <MainApp />
      </DataProvider>
    </AuthProvider>
  );
}
