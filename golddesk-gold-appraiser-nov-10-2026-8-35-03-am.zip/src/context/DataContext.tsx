import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from './AuthContext';
import {
  Customer,
  Loan,
  Inspection,
  Payment,
  Settlement,
  Receivable,
  Holiday,
  AppSettings,
  PhotoRecord,
  DatabaseState
} from '../types';
import {
  DEFAULT_SETTINGS,
  mergeSettings,
  splitCharge,
  uid,
  validateBackup,
  exportBackup
} from '../lib/core';
import {
  compressImage,
  blobToDataURL,
  uploadToGoogleDrive,
  uploadToOneDrive,
  uploadToDropbox
} from '../lib/cloudStorage';

interface DataContextType {
  dbState: DatabaseState;
  ready: boolean;
  online: boolean;
  storageError: string | null;

  // Mutations
  saveCustomer: (c: Partial<Customer>) => Promise<Customer>;
  deleteCustomer: (id: string) => Promise<void>;

  saveLoan: (loanData: Partial<Loan>, files?: { gold?: File | null; app?: File | null }) => Promise<Loan>;
  deleteLoan: (id: string) => Promise<void>;
  renewLoan: (oldLoanId: string, renewData: {
    ledger: string;
    amount: number;
    date: string;
    renewal: string;
    applyCharge: boolean;
    note?: string;
  }) => Promise<void>;
  closeLoan: (loanId: string, note?: string) => Promise<void>;

  saveInspection: (insp: Partial<Inspection>) => Promise<Inspection>;
  deleteInspection: (id: string) => Promise<void>;

  recordPayment: (paymentData: {
    acct: 'a2' | 'hA1' | 'hA2';
    amount: number;
    date: string;
    note?: string;
    id?: string;
  }) => Promise<Payment>;
  reversePayment: (id: string) => Promise<void>;

  saveReceivable: (r: { amount: number; sourceDate: string; description?: string }) => Promise<Receivable>;
  recordReceivableReceipt: (id: string, receipt: { amount: number; date: string; reference?: string }) => Promise<void>;

  saveHoliday: (date: string, name: string) => Promise<Holiday>;
  deleteHoliday: (id: string) => Promise<void>;

  saveSettings: (newSettings: Partial<AppSettings>) => Promise<void>;

  uploadPhoto: (file: File, type: string, loanId?: string, ledger?: string) => Promise<PhotoRecord>;
  getPhotoData: (photoId: string) => Promise<string>;

  exportJsonBackup: () => Promise<any>;
  importJsonBackup: (data: any) => Promise<{ ok: boolean; errors: string[]; warnings: string[] }>;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [ready, setReady] = useState(false);
  const [online, setOnline] = useState(navigator.onLine);
  const [storageError, setStorageError] = useState<string | null>(null);

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [receivables, setReceivables] = useState<Receivable[]>([]);
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [photos, setPhotos] = useState<PhotoRecord[]>([]);

  // Monitor browser online/offline status
  useEffect(() => {
    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Listen to Firestore in real-time when authenticated
  useEffect(() => {
    if (!user) {
      setReady(true);
      return;
    }

    const userId = user.uid;
    const unsubscribes: Array<() => void> = [];

    // Helper for subcollection listeners
    const listenSub = <T,>(
      collName: string,
      setter: React.Dispatch<React.SetStateAction<T[]>>
    ) => {
      const path = `users/${userId}/${collName}`;
      const unsub = onSnapshot(
        collection(db, path),
        snapshot => {
          const items = snapshot.docs.map(docSnap => ({
            id: docSnap.id,
            ...docSnap.data()
          })) as T[];
          setter(items);
        },
        error => {
          handleFirestoreError(error, OperationType.GET, path);
        }
      );
      unsubscribes.push(unsub);
    };

    listenSub<Customer>('customers', setCustomers);
    listenSub<Loan>('loans', setLoans);
    listenSub<Inspection>('inspections', setInspections);
    listenSub<Payment>('payments', setPayments);
    listenSub<Settlement>('settlements', setSettlements);
    listenSub<Receivable>('receivables', setReceivables);
    listenSub<Holiday>('holidays', setHolidays);
    listenSub<PhotoRecord>('photos', setPhotos);

    // Settings listener
    const settingsPath = `users/${userId}/settings/main`;
    const unsubSettings = onSnapshot(
      doc(db, settingsPath),
      snapshot => {
        if (snapshot.exists()) {
          setSettings(mergeSettings(snapshot.data() as Partial<AppSettings>));
        } else {
          // Initialize default settings in Firestore for new users
          setDoc(doc(db, settingsPath), {
            ...DEFAULT_SETTINGS,
            userId,
            updatedAt: new Date().toISOString()
          }).catch(err => {
            handleFirestoreError(err, OperationType.WRITE, settingsPath);
          });
        }
        setReady(true);
      },
      error => {
        handleFirestoreError(error, OperationType.GET, settingsPath);
      }
    );
    unsubscribes.push(unsubSettings);

    return () => {
      unsubscribes.forEach(unsub => unsub());
    };
  }, [user]);

  // Combined state object
  const dbState: DatabaseState = useMemo(
    () => ({
      schema: 5,
      customers,
      loans,
      inspections,
      payments,
      settlements,
      receivables,
      holidays,
      settings,
      photos
    }),
    [customers, loans, inspections, payments, settlements, receivables, holidays, settings, photos]
  );

  // ---------- Mutations ----------

  const saveCustomer = async (c: Partial<Customer>): Promise<Customer> => {
    if (!user) throw new Error('Sign in to save customer');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = c.id || `C-${1001 + (customers.length ? Math.max(0, ...customers.map(x => Number(String(x.id).replace(/\D/g, '')) - 1000 || 0)) + 1 : 0)}`;

    const fullCustomer: Customer = {
      id,
      userId,
      name: (c.name || '').trim(),
      mobile: (c.mobile || '').trim(),
      address: (c.address || '').trim(),
      aadhaar: (c.aadhaar || '').trim(),
      otherId: (c.otherId || '').trim(),
      account: (c.account || '').trim(),
      ifsc: (c.ifsc || '').trim(),
      createdAt: c.createdAt || now,
      updatedAt: now
    };

    const path = `users/${userId}/customers/${id}`;
    try {
      await setDoc(doc(db, path), fullCustomer);
      return fullCustomer;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const deleteCustomer = async (id: string): Promise<void> => {
    if (!user) throw new Error('Sign in to delete customer');
    const userId = user.uid;

    const path = `users/${userId}/customers/${id}`;
    try {
      // Find and delete linked loans
      const linkedLoans = loans.filter(l => l.cid === id);
      const batch = writeBatch(db);
      batch.delete(doc(db, path));
      linkedLoans.forEach(l => {
        batch.delete(doc(db, `users/${userId}/loans/${l.id}`));
      });
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const uploadPhoto = async (
    file: File,
    type: string,
    loanId?: string,
    ledger?: string
  ): Promise<PhotoRecord> => {
    if (!user) throw new Error('Sign in to upload photo');
    const userId = user.uid;
    const now = new Date().toISOString();
    const photoId = uid('img');

    // Compress photo
    const compressedBlob = await compressImage(file, 1600);
    const dataUrl = await blobToDataURL(compressedBlob);

    let storageProvider: 'local' | 'firestore' | 'gdrive' | 'onedrive' | 'dropbox' = 'firestore';
    let cloudUrl = '';

    const cloud = settings.cloudStorage;

    // Check Cloud Storage Connectors
    if (cloud?.googleDriveEnabled && cloud.googleDriveAccessToken) {
      const gres = await uploadToGoogleDrive(
        cloud.googleDriveAccessToken,
        `GoldDesk_${ledger || 'Photo'}_${type}_${photoId}.jpg`,
        compressedBlob
      );
      if (gres.ok && gres.webViewLink) {
        storageProvider = 'gdrive';
        cloudUrl = gres.webViewLink;
      }
    } else if (cloud?.oneDriveEnabled && cloud.oneDriveAccessToken) {
      const ores = await uploadToOneDrive(
        cloud.oneDriveAccessToken,
        `GoldDesk_${ledger || 'Photo'}_${type}_${photoId}.jpg`,
        compressedBlob
      );
      if (ores.ok && ores.webUrl) {
        storageProvider = 'onedrive';
        cloudUrl = ores.webUrl;
      }
    } else if (cloud?.dropboxEnabled && cloud.dropboxAccessToken) {
      const dres = await uploadToDropbox(
        cloud.dropboxAccessToken,
        `GoldDesk_${ledger || 'Photo'}_${type}_${photoId}.jpg`,
        compressedBlob
      );
      if (dres.ok && dres.path) {
        storageProvider = 'dropbox';
        cloudUrl = dres.path;
      }
    }

    const photoRecord: PhotoRecord = {
      id: photoId,
      userId,
      loanId,
      ledger,
      type,
      dataUrl,
      storageProvider,
      cloudUrl,
      filename: file.name,
      createdAt: now
    };

    const path = `users/${userId}/photos/${photoId}`;
    try {
      await setDoc(doc(db, path), photoRecord);
      return photoRecord;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const getPhotoData = async (photoId: string): Promise<string> => {
    const photo = photos.find(p => p.id === photoId);
    if (!photo) return '';
    return photo.dataUrl || photo.cloudUrl || '';
  };

  const saveLoan = async (
    loanData: Partial<Loan>,
    files?: { gold?: File | null; app?: File | null }
  ): Promise<Loan> => {
    if (!user) throw new Error('Sign in to save gold loan');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = loanData.id || uid('L');

    const charge = Number(loanData.charge) || 0;
    const alloc = splitCharge(charge, settings);

    const imageIds: string[] = [...(loanData.imageIds || [])];

    if (files?.gold) {
      const rec = await uploadPhoto(files.gold, 'gold', id, loanData.ledger);
      imageIds.push(rec.id);
    }
    if (files?.app) {
      const rec = await uploadPhoto(files.app, 'application', id, loanData.ledger);
      imageIds.push(rec.id);
    }

    const fullLoan: Loan = {
      id,
      userId,
      cid: loanData.cid || '',
      ledger: (loanData.ledger || '').trim(),
      amount: Number(loanData.amount) || 0,
      charge,
      received: charge,
      date: loanData.date || now.slice(0, 10),
      renewal: loanData.renewal || '',
      renewalStatus: loanData.renewalStatus || 'Active',
      renewedFrom: loanData.renewedFrom || '',
      renewedTo: loanData.renewedTo || '',
      imageIds,
      previousImageIds: loanData.previousImageIds || [],
      notes: loanData.notes || '',
      alloc: {
        charge: alloc.charge,
        a1: alloc.a1,
        a2: alloc.a2,
        helper: alloc.helper,
        payA1: alloc.payA1,
        payA2: alloc.payA2
      },
      renewalHistory: loanData.renewalHistory || [
        { date: now.slice(0, 10), action: 'Loan registered' }
      ],
      createdAt: loanData.createdAt || now,
      updatedAt: now
    };

    const path = `users/${userId}/loans/${id}`;
    try {
      await setDoc(doc(db, path), fullLoan);
      return fullLoan;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const deleteLoan = async (id: string): Promise<void> => {
    if (!user) throw new Error('Sign in to delete loan');
    const userId = user.uid;
    const path = `users/${userId}/loans/${id}`;

    try {
      // NOTE: We delete the loan document, but as per requirement 4:
      // "Never automatically delete photos."
      // Photos in photos collection are permanently preserved!
      await deleteDoc(doc(db, path));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const renewLoan = async (
    oldLoanId: string,
    renewData: {
      ledger: string;
      amount: number;
      date: string;
      renewal: string;
      applyCharge: boolean;
      note?: string;
    }
  ): Promise<void> => {
    if (!user) throw new Error('Sign in to renew loan');
    const oldLoan = loans.find(l => l.id === oldLoanId);
    if (!oldLoan) throw new Error('Old loan not found');

    const userId = user.uid;
    const now = new Date().toISOString();
    const newId = uid('L');

    const charge = renewData.applyCharge ? splitCharge(oldLoan.amount, settings).charge : 0;
    const alloc = splitCharge(charge, settings);

    const newLoan: Loan = {
      id: newId,
      userId,
      cid: oldLoan.cid,
      ledger: renewData.ledger.trim(),
      amount: renewData.amount,
      charge,
      received: charge,
      date: renewData.date,
      renewal: renewData.renewal,
      renewalStatus: 'Active',
      renewedFrom: oldLoan.id,
      imageIds: [],
      previousImageIds: oldLoan.imageIds || [],
      notes: renewData.note || '',
      alloc: {
        charge: alloc.charge,
        a1: alloc.a1,
        a2: alloc.a2,
        helper: alloc.helper,
        payA1: alloc.payA1,
        payA2: alloc.payA2
      },
      renewalHistory: [
        {
          date: now.slice(0, 10),
          action: `Renewal of ${oldLoan.ledger}`,
          note: renewData.note
        }
      ],
      createdAt: now,
      updatedAt: now
    };

    const updatedOldLoan: Loan = {
      ...oldLoan,
      renewalStatus: 'Renewed',
      renewedTo: newId,
      renewalHistory: [
        ...(oldLoan.renewalHistory || []),
        {
          date: now.slice(0, 10),
          previousDate: oldLoan.renewal,
          action: `Renewed as ${renewData.ledger}`,
          note: renewData.note
        }
      ],
      updatedAt: now
    };

    const batch = writeBatch(db);
    batch.set(doc(db, `users/${userId}/loans/${newId}`), newLoan);
    batch.set(doc(db, `users/${userId}/loans/${oldLoan.id}`), updatedOldLoan);
    await batch.commit();
  };

  const closeLoan = async (loanId: string, note?: string): Promise<void> => {
    if (!user) throw new Error('Sign in to close loan');
    const loan = loans.find(l => l.id === loanId);
    if (!loan) throw new Error('Loan not found');

    const userId = user.uid;
    const now = new Date().toISOString();

    const updated: Loan = {
      ...loan,
      renewalStatus: 'Closed Loan',
      renewalHistory: [
        ...(loan.renewalHistory || []),
        {
          date: now.slice(0, 10),
          previousDate: loan.renewal,
          action: 'Closed Loan',
          note: note || ''
        }
      ],
      updatedAt: now
    };

    const path = `users/${userId}/loans/${loanId}`;
    try {
      await setDoc(doc(db, path), updated);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const saveInspection = async (insp: Partial<Inspection>): Promise<Inspection> => {
    if (!user) throw new Error('Sign in to save inspection');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = insp.id || uid('IN');

    const fullInsp: Inspection = {
      id,
      userId,
      date: insp.date || now.slice(0, 10),
      branch: (insp.branch || '').trim(),
      packets: Number(insp.packets) || 1,
      rate: insp.rate != null ? Number(insp.rate) : Number(settings.packetRate ?? 100),
      charge: Number(insp.charge) || 0,
      received: Number(insp.received) || 0,
      createdAt: insp.createdAt || now,
      updatedAt: now
    };

    const path = `users/${userId}/inspections/${id}`;
    try {
      await setDoc(doc(db, path), fullInsp);
      return fullInsp;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const deleteInspection = async (id: string): Promise<void> => {
    if (!user) throw new Error('Sign in to delete inspection');
    const userId = user.uid;
    const path = `users/${userId}/inspections/${id}`;
    try {
      await deleteDoc(doc(db, path));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  // Requirement 9: Record partial and full payments only in the Settlement page. Maintain history.
  const recordPayment = async (paymentData: {
    acct: 'a2' | 'hA1' | 'hA2';
    amount: number;
    date: string;
    note?: string;
    id?: string;
  }): Promise<Payment> => {
    if (!user) throw new Error('Sign in to record payment');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = paymentData.id || uid('PAY');

    const existingPayment = paymentData.id ? payments.find(p => p.id === paymentData.id) : null;

    let history = existingPayment?.history || [];
    if (existingPayment) {
      history = [
        ...history,
        {
          at: now,
          action: 'Corrected',
          from: {
            amount: existingPayment.amount,
            date: existingPayment.date,
            note: existingPayment.note
          },
          to: {
            amount: paymentData.amount,
            date: paymentData.date,
            note: paymentData.note || ''
          }
        }
      ];
    } else {
      history = [
        {
          at: now,
          action: 'Recorded',
          amount: paymentData.amount,
          date: paymentData.date
        }
      ];
    }

    const fullPayment: Payment = {
      id,
      userId,
      acct: paymentData.acct,
      date: paymentData.date,
      amount: Number(paymentData.amount),
      note: (paymentData.note || '').trim(),
      status: 'active',
      createdAt: existingPayment?.createdAt || now,
      updatedAt: now,
      history
    };

    const path = `users/${userId}/payments/${id}`;
    try {
      await setDoc(doc(db, path), fullPayment);
      return fullPayment;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const reversePayment = async (id: string): Promise<void> => {
    if (!user) throw new Error('Sign in to reverse payment');
    const payment = payments.find(p => p.id === id);
    if (!payment) throw new Error('Payment not found');

    const userId = user.uid;
    const now = new Date().toISOString();

    const updated: Payment = {
      ...payment,
      status: 'reversed',
      updatedAt: now,
      history: [
        ...(payment.history || []),
        {
          at: now,
          action: 'Reversed',
          amount: payment.amount,
          date: payment.date
        }
      ]
    };

    const path = `users/${userId}/payments/${id}`;
    try {
      await setDoc(doc(db, path), updated);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const saveReceivable = async (r: {
    amount: number;
    sourceDate: string;
    description?: string;
  }): Promise<Receivable> => {
    if (!user) throw new Error('Sign in to save adjustment');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = uid('REC');

    const fullRec: Receivable = {
      id,
      userId,
      sourceDate: r.sourceDate,
      amount: Number(r.amount) || 0,
      description: r.description || '',
      paid: 0,
      payments: [],
      createdAt: now,
      updatedAt: now
    };

    const path = `users/${userId}/receivables/${id}`;
    try {
      await setDoc(doc(db, path), fullRec);
      return fullRec;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const recordReceivableReceipt = async (
    id: string,
    receipt: { amount: number; date: string; reference?: string }
  ): Promise<void> => {
    if (!user) throw new Error('Sign in to record adjustment receipt');
    const rec = receivables.find(r => r.id === id);
    if (!rec) throw new Error('Receivable not found');

    const userId = user.uid;
    const now = new Date().toISOString();

    const newPaymentList = [
      ...(rec.payments || []),
      {
        id: uid('RCP'),
        amount: Number(receipt.amount),
        date: receipt.date,
        reference: receipt.reference
      }
    ];

    const totalPaid = newPaymentList.reduce((sum, p) => sum + p.amount, 0);

    const updated: Receivable = {
      ...rec,
      paid: totalPaid,
      payments: newPaymentList,
      updatedAt: now
    };

    const path = `users/${userId}/receivables/${id}`;
    try {
      await setDoc(doc(db, path), updated);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const saveHoliday = async (date: string, name: string): Promise<Holiday> => {
    if (!user) throw new Error('Sign in to add holiday');
    const userId = user.uid;
    const now = new Date().toISOString();
    const id = uid('HOL');

    const fullHoliday: Holiday = {
      id,
      userId,
      date,
      name: name.trim() || 'Holiday',
      createdAt: now,
      updatedAt: now
    };

    const path = `users/${userId}/holidays/${id}`;
    try {
      await setDoc(doc(db, path), fullHoliday);
      return fullHoliday;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
      throw err;
    }
  };

  const deleteHoliday = async (id: string): Promise<void> => {
    if (!user) throw new Error('Sign in to delete holiday');
    const userId = user.uid;
    const path = `users/${userId}/holidays/${id}`;
    try {
      await deleteDoc(doc(db, path));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const saveSettings = async (newSettings: Partial<AppSettings>): Promise<void> => {
    if (!user) throw new Error('Sign in to save settings');
    const userId = user.uid;
    const now = new Date().toISOString();

    const merged = mergeSettings({
      ...settings,
      ...newSettings,
      updatedAt: now
    });

    const path = `users/${userId}/settings/main`;
    try {
      await setDoc(doc(db, path), { ...merged, userId });
      setSettings(merged);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const exportJsonBackup = async () => {
    const images: Record<string, string> = {};
    photos.forEach(p => {
      if (p.dataUrl) images[p.id] = p.dataUrl;
    });
    return exportBackup(dbState, images);
  };

  const importJsonBackup = async (
    data: any
  ): Promise<{ ok: boolean; errors: string[]; warnings: string[] }> => {
    if (!user) throw new Error('Sign in to import backup');
    const validation = validateBackup(data);
    if (!validation.ok || !validation.db) {
      return validation;
    }

    const userId = user.uid;
    const batch = writeBatch(db);

    // Save imported settings
    batch.set(
      doc(db, `users/${userId}/settings/main`),
      { ...validation.db.settings, userId }
    );

    // Replace customers
    validation.db.customers.forEach(c => {
      batch.set(doc(db, `users/${userId}/customers/${c.id}`), { ...c, userId });
    });

    // Replace loans
    validation.db.loans.forEach(l => {
      batch.set(doc(db, `users/${userId}/loans/${l.id}`), { ...l, userId });
    });

    // Replace inspections
    validation.db.inspections.forEach(i => {
      batch.set(doc(db, `users/${userId}/inspections/${i.id}`), { ...i, userId });
    });

    // Replace payments
    validation.db.payments.forEach(p => {
      batch.set(doc(db, `users/${userId}/payments/${p.id}`), { ...p, userId });
    });

    // Replace holidays
    validation.db.holidays.forEach(h => {
      batch.set(doc(db, `users/${userId}/holidays/${h.id}`), { ...h, userId });
    });

    // Replace photos
    if (validation.images) {
      Object.entries(validation.images).forEach(([photoId, dataUrl]) => {
        batch.set(doc(db, `users/${userId}/photos/${photoId}`), {
          id: photoId,
          userId,
          type: 'imported',
          dataUrl,
          storageProvider: 'firestore',
          createdAt: new Date().toISOString()
        });
      });
    }

    await batch.commit();
    return { ok: true, errors: [], warnings: validation.warnings };
  };

  return (
    <DataContext.Provider
      value={{
        dbState,
        ready,
        online,
        storageError,
        saveCustomer,
        deleteCustomer,
        saveLoan,
        deleteLoan,
        renewLoan,
        closeLoan,
        saveInspection,
        deleteInspection,
        recordPayment,
        reversePayment,
        saveReceivable,
        recordReceivableReceipt,
        saveHoliday,
        deleteHoliday,
        saveSettings,
        uploadPhoto,
        getPhotoData,
        exportJsonBackup,
        importJsonBackup
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
};
