/* GoldDesk Gold Rate poster renderer using PNB reference artwork */

export const POSTER_WIDTH = 1086;
export const POSTER_HEIGHT = 1448;

const INK = '#8b0118';
const WHITE = '#ffffff';

const L = {
  date: { cx: 615, base: 628, size: 85, max: 313, color: WHITE },
  rate: { right: 1022, base: 769, size: 92, max: 334, color: WHITE },
  pctA: { right: 629, base: 941, size: 72, max: 125, color: INK },
  pctN: { right: 630, base: 1125, size: 74, max: 126, color: INK },
  valA: { right: 1039, base: 943, size: 88, max: 342, color: INK },
  valN: { right: 1039, base: 1130, size: 92, max: 319, color: INK }
};

export const inr = (n: number | string) =>
  Math.round(Number(n) || 0).toLocaleString('en-IN');

let loadAssetsPromise: Promise<HTMLImageElement> | null = null;

export async function loadPosterAssets(): Promise<HTMLImageElement> {
  if (!loadAssetsPromise) {
    loadAssetsPromise = (async () => {
      try {
        const ff = new FontFace('GDPoster', 'url(/fonts/PlayfairDisplay-Lining.ttf)', {
          weight: '400 900'
        });
        await ff.load();
        document.fonts.add(ff);
      } catch (e) {
        console.warn('Poster font load fallback:', e);
      }

      try {
        const fr = new FontFace('GDRupee', 'url(/fonts/NotoSansTamil.ttf)', {
          weight: '100 900'
        });
        await fr.load();
        document.fonts.add(fr);
      } catch (e) {
        console.warn('Rupee font load fallback:', e);
      }

      const img = new Image();
      img.src = '/assets/poster-template.jpg';
      await img.decode();
      return img;
    })();
  }
  return loadAssetsPromise;
}

function put(
  ctx: CanvasRenderingContext2D,
  text: string,
  spec: { cx?: number; right?: number; base: number; size: number; max: number; color: string },
  align: 'center' | 'right'
) {
  const hasRupee = text.charAt(0) === '₹';
  const hasDash = text.slice(-2) === '/-';
  let body = text;
  if (hasRupee) body = body.slice(2);
  if (hasDash) body = body.slice(0, -1);

  const fs = spec.size;
  ctx.font = '900 ' + fs + 'px GDPoster, "Playfair Display", serif';
  const bw = ctx.measureText(body).width;

  ctx.font = '800 ' + fs * 0.96 + 'px GDRupee, "Noto Sans Tamil", sans-serif';
  const rw = hasRupee ? ctx.measureText('₹').width : 0;

  const gapR = hasRupee ? fs * 0.22 : 0;
  const gapD = hasDash ? fs * 0.04 : 0;
  const dw = hasDash ? fs * 0.42 : 0;

  const total = rw + gapR + bw + gapD + dw;
  const sx = Math.min(1, spec.max / total);

  const x0 = align === 'center' ? (spec.cx || 0) - (total * sx) / 2 : (spec.right || 0) - total * sx;

  ctx.save();
  ctx.translate(x0, spec.base);
  ctx.scale(sx, 1);
  ctx.fillStyle = ctx.strokeStyle = spec.color;
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.lineJoin = 'round';

  let x = 0;
  if (hasRupee) {
    ctx.font = '800 ' + fs * 0.96 + 'px GDRupee, "Noto Sans Tamil", sans-serif';
    ctx.fillText('₹', 0, 0);
    x += rw + gapR;
  }

  ctx.font = '900 ' + fs + 'px GDPoster, "Playfair Display", serif';
  ctx.lineWidth = Math.max(1, fs * 0.02);
  ctx.fillText(body, x, 0);
  ctx.strokeText(body, x, 0);
  x += bw + gapD;

  if (hasDash) {
    ctx.fillRect(x, -fs * 0.4, dw, fs * 0.095);
  }

  ctx.restore();
}

export interface PosterData {
  date: string;
  rate: number;
  agriPct: number;
  nonAgriPct: number;
}

export async function renderPoster(data: PosterData): Promise<HTMLCanvasElement> {
  const templateImg = await loadPosterAssets();
  const c = document.createElement('canvas');
  c.width = POSTER_WIDTH;
  c.height = POSTER_HEIGHT;
  const ctx = c.getContext('2d')!;

  ctx.drawImage(templateImg, 0, 0, POSTER_WIDTH, POSTER_HEIGHT);

  const [y, m, d] = String(data.date).split('-');
  const rate = Number(data.rate) || 0;

  put(ctx, d + '.' + m + '.' + y.slice(2), L.date, 'center');
  put(ctx, '₹ ' + inr(rate) + '/-', L.rate, 'right');
  put(ctx, data.agriPct + '%', L.pctA, 'right');
  put(ctx, data.nonAgriPct + '%', L.pctN, 'right');
  put(ctx, '₹ ' + inr((rate * data.agriPct) / 100) + '/-', L.valA, 'right');
  put(ctx, '₹ ' + inr((rate * data.nonAgriPct) / 100) + '/-', L.valN, 'right');

  return c;
}
