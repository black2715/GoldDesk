import { CloudStorageConfig, PhotoRecord } from '../types';

export async function testCloudStorageConnection(
  provider: 'gdrive' | 'onedrive' | 'dropbox',
  accessToken: string
): Promise<{ ok: boolean; user?: string; error?: string }> {
  try {
    const res = await fetch('/api/cloud-storage/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, accessToken })
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { ok: false, error: err.message || 'Network error testing cloud storage' };
  }
}

export async function uploadToGoogleDrive(
  accessToken: string,
  fileName: string,
  blob: Blob
): Promise<{ ok: boolean; fileId?: string; webViewLink?: string; error?: string }> {
  try {
    const metadata = {
      name: fileName,
      mimeType: blob.type || 'image/jpeg'
    };

    const form = new FormData();
    form.append(
      'metadata',
      new Blob([JSON.stringify(metadata)], { type: 'application/json' })
    );
    form.append('file', blob);

    const res = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`
        },
        body: form
      }
    );

    if (!res.ok) {
      throw new Error(`Google Drive upload failed with status ${res.status}`);
    }

    const data = await res.json();
    return { ok: true, fileId: data.id, webViewLink: data.webViewLink };
  } catch (err: any) {
    return { ok: false, error: err.message || 'Google Drive upload failed' };
  }
}

export async function uploadToOneDrive(
  accessToken: string,
  fileName: string,
  blob: Blob
): Promise<{ ok: boolean; webUrl?: string; error?: string }> {
  try {
    const cleanName = encodeURIComponent(fileName);
    const res = await fetch(
      `https://graph.microsoft.com/v1.0/me/drive/root:/GoldDesk_Photos/${cleanName}:/content`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': blob.type || 'image/jpeg'
        },
        body: blob
      }
    );

    if (!res.ok) {
      throw new Error(`OneDrive upload failed with status ${res.status}`);
    }

    const data = await res.json();
    return { ok: true, webUrl: data.webUrl };
  } catch (err: any) {
    return { ok: false, error: err.message || 'OneDrive upload failed' };
  }
}

export async function uploadToDropbox(
  accessToken: string,
  fileName: string,
  blob: Blob
): Promise<{ ok: boolean; path?: string; error?: string }> {
  try {
    const res = await fetch('https://content.dropboxapi.com/2/files/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Dropbox-API-Arg': JSON.stringify({
          path: `/GoldDesk_Photos/${fileName}`,
          mode: 'add',
          autorename: true,
          mute: false
        }),
        'Content-Type': 'application/octet-stream'
      },
      body: blob
    });

    if (!res.ok) {
      throw new Error(`Dropbox upload failed with status ${res.status}`);
    }

    const data = await res.json();
    return { ok: true, path: data.path_display };
  } catch (err: any) {
    return { ok: false, error: err.message || 'Dropbox upload failed' };
  }
}

// Compress client image for storage and viewing
export async function compressImage(file: File, maxDimension: number = 1600): Promise<Blob> {
  const bmp = await createImageBitmap(file).catch(() => null);
  if (!bmp) throw new Error('Selected file is not a valid readable image.');

  const scale = Math.min(1, maxDimension / Math.max(bmp.width, bmp.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bmp.width * scale);
  canvas.height = Math.round(bmp.height * scale);

  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      b => (b ? resolve(b) : reject(new Error('Image compression failed'))),
      'image/jpeg',
      0.88
    );
  });
}

export const blobToDataURL = (b: Blob): Promise<string> =>
  new Promise(res => {
    const f = new FileReader();
    f.onload = () => res(f.result as string);
    f.onerror = () => res('');
    f.readAsDataURL(b);
  });
