import {
  AppSettings,
  Customer,
  DatabaseState,
  Inspection,
  Loan,
  Payment,
  Settlement,
  Receivable
} from '../types';

export const SCHEMA = 5;

export const pad = (n: number) => String(n).padStart(2, '0');
export const toISO = (d: Date) =>
  d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());

export const parseISO = (s: string) => {
  const [y, m, d] = String(s).split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const addDays = (iso: string, n: number) => {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
};

export const round2 = (n: any) => {
  n = Number(n) || 0;
  return Math.round((n + (n >= 0 ? 1e-9 : -1e-9)) * 100) / 100;
};

export const uid = (p: string = 'id') =>
  p + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

export const isISO = (s: any) =>
  typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && toISO(parseISO(s)) === s;

export const isSunday = (iso: string) => parseISO(iso).getDay() === 0;

export const DEFAULT_SETTINGS: AppSettings = {
  appraiser1Name: 'Aravindhan',
  appraiser2Name: 'Appraiser 2',
  helperName: 'Vengatesan',
  split1: 37.5,
  split2: 37.5,
  splitHelper: 25,
  bankMode: 'percent',
  bankShareValue: 50,
  feeMode: 'fixed',
  feeStandard: 500,
  feeHigh: 1000,
  feeThreshold: 500000,
  feePercent: 0.2,
  feeMin: 0,
  feeMax: 0,
  packetRate: 100,
  reminderDays: 10,
  rateWhatsapp: '',
  rateProxy: '',
  rateFetchedAt: '',
  rateVia: '',
  agriPercent: 85,
  nonAgriPercent: 68,
  rate: 0,
  rateSavedFor: '',
  branchName: 'CUDDALORE',
  branchCode: '010400',
  reminder: {
    gross: false,
    nett: false,
    items: false,
    due: true,
    fontScale: 1,
    notice: ''
  },
  cloudStorage: {
    googleDriveEnabled: false,
    oneDriveEnabled: false,
    dropboxEnabled: false
  }
};

export const TAMIL_NOTICE =
  'வணக்கம்,\n\nதங்களது நகைக் கடனுக்கான காலக்கெடு (Due Date) விரைவில் முடிவடைய உள்ளது. எனவே, காலக்கெடு முடிவடைவதற்கு முன்பாக நிலுவைத் தொகையைச் செலுத்தி அடமான நகையை மீட்டுக்கொள்ளுமாறு கேட்டுக்கொள்கிறோம்.\n\nகடனைப் புதுப்பித்துக் கொள்ள (Renewal) விரும்பினால், வங்கிக் கிளையை அணுகுங்கள். வங்கிக்கு வரும்போது ஆதார் அட்டை மற்றும் பான் கார்டின் நகலை தவறாமல் கொண்டு வாருங்கள். நன்றி!';

export const mergeSettings = (s?: Partial<AppSettings>): AppSettings => {
  const o: AppSettings = { ...DEFAULT_SETTINGS, ...(s || {}) };
  o.reminder = { ...DEFAULT_SETTINGS.reminder, ...((s && s.reminder) || {}) };
  o.cloudStorage = { ...DEFAULT_SETTINGS.cloudStorage, ...((s && s.cloudStorage) || {}) };
  return o;
};

export const emptyDB = (): DatabaseState => ({
  schema: SCHEMA,
  customers: [],
  loans: [],
  inspections: [],
  settlements: [],
  payments: [],
  receivables: [],
  holidays: [],
  settings: mergeSettings(),
  photos: [],
  audit: []
});

/* Date rules */
export const rateDate = (now?: Date) => {
  now = now || new Date();
  const d = new Date(now);
  if (d.getHours() >= 19) d.setDate(d.getDate() + 1);
  return toISO(d);
};

export function weekBounds(ref: string): [string, string] {
  const d = parseISO(ref);
  const back = (d.getDay() + 6) % 7; // Monday = 0
  const a = new Date(d);
  a.setDate(d.getDate() - back);
  const b = new Date(a);
  b.setDate(a.getDate() + 5); // Saturday
  return [toISO(a), toISO(b)];
}

export function bounds(period: 'day' | 'week' | 'month' | 'year', ref: string): [string, string] {
  const d = parseISO(ref);
  if (period === 'week') return weekBounds(ref);
  if (period === 'month') {
    return [
      toISO(new Date(d.getFullYear(), d.getMonth(), 1)),
      toISO(new Date(d.getFullYear(), d.getMonth() + 1, 0))
    ];
  }
  if (period === 'year') {
    return [`${d.getFullYear()}-01-01`, `${d.getFullYear()}-12-31`];
  }
  return [ref, ref];
}

export const within = (d: string, a: string, b: string) => !!d && d >= a && d <= b;

export function eachDay(a: string, b: string): string[] {
  const out: string[] = [];
  for (let d = parseISO(a), e = parseISO(b); d <= e; d.setDate(d.getDate() + 1)) {
    out.push(toISO(d));
  }
  return out;
}

/* Whole-rupee rule */
export const rupee = (n: any) => {
  n = Number(n) || 0;
  return n >= 0 ? Math.floor(n + 0.5 + 1e-9) : -Math.floor(-n + 0.5 + 1e-9);
};

export function calcFee(amount: any, S: AppSettings): number {
  amount = Number(amount) || 0;
  let f =
    S.feeMode === 'percent'
      ? (amount * S.feePercent) / 100
      : amount > S.feeThreshold
      ? S.feeHigh
      : S.feeStandard;
  if (S.feeMin > 0) f = Math.max(f, S.feeMin);
  if (S.feeMax > 0) f = Math.min(f, S.feeMax);
  return rupee(f);
}

/* Income split: Appraiser 1 37.5%, Appraiser 2 37.5%, Helper 25%.
   Helper's share is borne entirely by Appraiser 1 (payA1 = helper, payA2 = 0). */
export function splitCharge(charge: any, S: AppSettings) {
  const total = Math.max(0, rupee(charge));
  const raw = [S.split1, S.split2, S.splitHelper].map(p => (total * (Number(p) || 0)) / 100);
  const part = raw.map(Math.floor);
  let rest = total - part.reduce((a, b) => a + b, 0);

  [0, 1, 2]
    .sort(
      (i, j) =>
        Math.round((raw[j] - part[j]) * 1e6) - Math.round((raw[i] - part[i]) * 1e6) || i - j
    )
    .forEach(i => {
      if (rest > 0) {
        part[i]++;
        rest--;
      }
    });

  const [a1, a2, helper] = part;
  const payA1 = helper;
  const payA2 = 0;
  return { charge: total, a1, a2, helper, payA1, payA2 };
}

export const loanA1Income = (x: Loan, S: AppSettings) => splitCharge(x.charge, S).a1;

export function inspectionBankPart(x: Inspection, S: AppSettings) {
  const r = Number(x.received) || 0;
  return S.bankMode === 'fixed'
    ? Math.min(r, Number(S.bankShareValue) || 0)
    : rupee((r * (Number(S.bankShareValue) || 0)) / 100);
}

export const inspectionA1Income = (x: Inspection, S: AppSettings) =>
  Math.max(0, round2((Number(x.received) || 0) - inspectionBankPart(x, S)));

export const inspectionCharge = (packets: any, rate: any) =>
  round2((Number(packets) || 0) * (Number(rate) || 0));

export const balance = (x: { charge: number; received?: number }) =>
  Math.max(0, round2((Number(x.charge) || 0) - (Number(x.received) || 0)));

export const payStatus = (x: { charge: number; received?: number }) =>
  (Number(x.received) || 0) <= 0
    ? 'Unpaid'
    : Number(x.received) >= Number(x.charge)
    ? 'Paid'
    : 'Partially Paid';

/* Income events */
export interface IncomeEvent {
  date: string;
  amount: number;
  type: string;
  ref: string;
  kind: 'loan' | 'inspection' | 'adjust';
}

export function incomeEvents(DB: DatabaseState): IncomeEvent[] {
  const S = DB.settings;
  const e: IncomeEvent[] = [];

  DB.loans.forEach(x => {
    const v = loanA1Income(x, S);
    if (v) e.push({ date: x.date, amount: v, type: 'Loan income', ref: x.ledger, kind: 'loan' });
  });

  DB.inspections.forEach(x => {
    const v = inspectionA1Income(x, S);
    if (v)
      e.push({
        date: x.date,
        amount: v,
        type: 'Inspection income',
        ref: x.branch,
        kind: 'inspection'
      });
  });

  (DB.receivables || []).forEach(r => {
    e.push({
      date: r.sourceDate,
      amount: -Number(r.amount || 0),
      type: 'Pending adjustment',
      ref: r.description || r.id,
      kind: 'adjust'
    });
    (r.payments || []).forEach(p =>
      e.push({
        date: p.date,
        amount: Number(p.amount || 0),
        type: 'Pending received',
        ref: r.description || r.id,
        kind: 'adjust'
      })
    );
  });

  return e;
}

export const sumEvents = (
  ev: IncomeEvent[],
  a: string,
  b: string,
  kind?: 'loan' | 'inspection' | 'adjust'
) =>
  round2(
    ev
      .filter(e => within(e.date, a, b) && (!kind || e.kind === kind))
      .reduce((n, e) => n + e.amount, 0)
  );

export const incomeBetween = (DB: DatabaseState, a: string, b: string) =>
  sumEvents(incomeEvents(DB), a, b);

/* Settlement running accounts */
export const ACCTS: Array<'a2' | 'hA1' | 'hA2'> = ['a2', 'hA1', 'hA2'];

export interface AccountSummary {
  accrued: number;
  paid: number;
  pending: number;
  advance: number;
}

export interface AccountsResult {
  a2: AccountSummary;
  hA1: AccountSummary;
  hA2: AccountSummary;
  helperPending: number;
}

export function accounts(DB: DatabaseState): AccountsResult {
  const A: Record<'a2' | 'hA1' | 'hA2', { accrued: number; paid: number; pending?: number; advance?: number }> = {
    a2: { accrued: 0, paid: 0 },
    hA1: { accrued: 0, paid: 0 },
    hA2: { accrued: 0, paid: 0 }
  };

  DB.loans.forEach(l => {
    const a = l.alloc || splitCharge(l.charge, DB.settings);
    A.a2.accrued += a.a2;
    A.hA1.accrued += a.helper;
  });

  (DB.payments || []).forEach(p => {
    if (p.status !== 'reversed' && A[p.acct]) {
      A[p.acct === 'hA2' ? 'hA1' : p.acct].paid += Number(p.amount) || 0;
    }
  });

  ACCTS.forEach(k => {
    const x = A[k];
    x.accrued = round2(x.accrued);
    x.paid = round2(x.paid);
    x.pending = Math.max(0, round2(x.accrued - x.paid));
    x.advance = Math.max(0, round2(x.paid - x.accrued));
  });

  const helperPending = round2((A.hA1.pending || 0) + (A.hA2.pending || 0));
  return {
    a2: A.a2 as AccountSummary,
    hA1: A.hA1 as AccountSummary,
    hA2: A.hA2 as AccountSummary,
    helperPending
  };
}

export function totals(DB: DatabaseState, today: string) {
  const S = DB.settings;
  const ev = incomeEvents(DB);
  const W = bounds('week', today);
  const M = bounds('month', today);
  const Y = bounds('year', today);
  const all = ['0000-01-01', '9999-12-31'];

  const loanPool = round2(DB.loans.reduce((n, x) => n + (Number(x.charge) || 0), 0));
  const parts = DB.loans.reduce(
    (n, x) => {
      const s = splitCharge(x.charge, S);
      n.a1 += s.a1;
      n.a2 += s.a2;
      n.helper += s.helper;
      return n;
    },
    { a1: 0, a2: 0, helper: 0 }
  );

  const months = new Set(ev.filter(e => e.date).map(e => e.date.slice(0, 7)));
  let avgMonthly = 0;
  if (months.size) {
    const first = [...months].sort()[0];
    const [fy, fm] = first.split('-').map(Number);
    const [ty, tm] = today.split('-').map(Number);
    const n = (ty - fy) * 12 + (tm - fm) + 1;
    avgMonthly = round2(sumEvents(ev, all[0], all[1]) / Math.max(1, n));
  }

  const inspAll = sumEvents(ev, all[0], all[1], 'inspection');
  const AC = accounts(DB);
  const helperPending = AC.helperPending;
  const WS = addDays(W[0], 6);
  const helperPaidWeek = round2(
    (DB.payments || [])
      .filter(p => p.status !== 'reversed' && p.acct !== 'a2' && within(p.date, W[0], WS))
      .reduce((n, p) => n + p.amount, 0)
  );

  const pendLoans = round2(DB.loans.reduce((n, x) => n + balance(x), 0));
  const a2Unpaid = AC.a2.pending;
  const pendInsp = round2(DB.inspections.reduce((n, x) => n + balance(x), 0));
  const pendRec = round2(
    (DB.receivables || []).reduce((n, r) => n + Math.max(0, r.amount - (r.paid || 0)), 0)
  );

  return {
    week: sumEvents(ev, W[0], W[1]),
    month: sumEvents(ev, M[0], M[1]),
    year: sumEvents(ev, Y[0], Y[1]),
    total: sumEvents(ev, all[0], all[1]),
    inspectionMonth: sumEvents(ev, M[0], M[1], 'inspection'),
    inspectionTotal: inspAll,
    avgMonthly,
    loanPool,
    a1Loan: round2(parts.a1),
    a2Share: round2(parts.a2),
    helperAllocation: round2(parts.helper),
    a2Unpaid,
    helperPending,
    helperPaidWeek,
    pendLoans,
    pendInsp,
    pendRec,
    pendingToReceive: round2(pendLoans + pendInsp + pendRec),
    sundayIncome: round2(
      ev.filter(e => e.date && isSunday(e.date)).reduce((n, e) => n + e.amount, 0)
    ),
    weekRange: W
  };
}

export function series(DB: DatabaseState, period: 'day' | 'week' | 'month' | 'year', ref: string) {
  const ev = incomeEvents(DB);
  if (period === 'year') {
    const y = parseISO(ref).getFullYear();
    const monthNames = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return Array.from({ length: 12 }, (_, i) => {
      const a = `${y}-${pad(i + 1)}-01`;
      const b = toISO(new Date(y, i + 1, 0));
      return {
        key: a,
        label: monthNames[i],
        value: sumEvents(ev, a, b),
        sunday: false
      };
    });
  }

  const [a, b] = bounds(period, ref);
  const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return eachDay(a, b).map(d => ({
    key: d,
    label: period === 'week' ? names[parseISO(d).getDay()] : String(parseISO(d).getDate()),
    value: sumEvents(ev, d, d),
    sunday: isSunday(d)
  }));
}

/* Renewals */
export const ARCHIVED = ['Renewed', 'Closed Loan', 'Sent off / completed'];
export const normalizeRenewalStatus = (s?: string) =>
  !s || s === 'Active' ? 'Active' : s === 'Closed' ? 'Closed Loan' : s;
export const isArchived = (x: Loan) => ARCHIVED.includes(normalizeRenewalStatus(x.renewalStatus));

export function renewalState(x: Loan, today: string) {
  if (isArchived(x)) return normalizeRenewalStatus(x.renewalStatus);
  if (!x.renewal) return 'No date';
  return x.renewal < today ? 'Overdue' : x.renewal === today ? 'Due Today' : 'Upcoming';
}

export function renewalList(DB: DatabaseState, today: string) {
  const lim = addDays(today, Number(DB.settings.reminderDays) || 0);
  return DB.loans
    .filter(x => !isArchived(x) && x.renewal && x.renewal <= lim)
    .sort((a, b) => (a.renewal || '').localeCompare(b.renewal || ''));
}

export const renewalArchive = (DB: DatabaseState) => DB.loans.filter(isArchived);

/* Backup Validation */
export function validateBackup(data: any): {
  ok: boolean;
  errors: string[];
  warnings: string[];
  db?: DatabaseState;
  images?: Record<string, string>;
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return { ok: false, errors: ['The file is not a GoldDesk backup (expected JSON object).'], warnings };
  }

  if (data.format !== 'golddesk-backup') {
    return { ok: false, errors: ['This is not a valid GoldDesk backup file.'], warnings };
  }

  const src = data.data || {};
  const db = emptyDB();
  db.settings = mergeSettings(src.settings);
  db.customers = Array.isArray(src.customers) ? src.customers : [];
  db.loans = Array.isArray(src.loans) ? src.loans : [];
  db.inspections = Array.isArray(src.inspections) ? src.inspections : [];
  db.payments = Array.isArray(src.payments) ? src.payments : [];
  db.settlements = Array.isArray(src.settlements) ? src.settlements : [];
  db.receivables = Array.isArray(src.receivables) ? src.receivables : [];
  db.holidays = Array.isArray(src.holidays) ? src.holidays : [];
  db.photos = Array.isArray(src.photos) ? src.photos : [];

  return { ok: true, errors, warnings, db, images: data.images || {} };
}

export function exportBackup(DB: DatabaseState, images: Record<string, string> = {}) {
  return {
    format: 'golddesk-backup',
    schema: SCHEMA,
    exportedAt: new Date().toISOString(),
    app: 'GoldDesk Professional',
    data: {
      customers: DB.customers,
      loans: DB.loans,
      inspections: DB.inspections,
      payments: DB.payments,
      settlements: DB.settlements,
      receivables: DB.receivables,
      holidays: DB.holidays,
      settings: DB.settings,
      photos: DB.photos
    },
    images
  };
}
