/* GoldDesk Renewal Reminder Card & WhatsApp Sharing */

const MAROON = '#800020';
const K = 3; // 420 css px -> 1260 px wide PNG
const CARD_W = 420;
const BORDER = 3;
const PAD = 12;
const INNER_W = CARD_W - 2 * (BORDER + PAD);
const LATIN = 'Arial, "Liberation Sans", Helvetica, sans-serif';

let cardAssetsPromise: Promise<{ logo: HTMLImageElement }> | null = null;

export async function loadCardAssets(): Promise<{ logo: HTMLImageElement }> {
  if (!cardAssetsPromise) {
    cardAssetsPromise = (async () => {
      try {
        const f = new FontFace('GDTamil', 'url(/fonts/NotoSansTamil.ttf)', { weight: '100 900' });
        await f.load();
        document.fonts.add(f);
      } catch (e) {
        console.warn('Tamil font load fallback:', e);
      }

      const logo = new Image();
      logo.src = '/assets/pnb.png';
      await logo.decode();
      return { logo };
    })();
  }
  return cardAssetsPromise;
}

export const indian = (n: any) => {
  const v = Number(String(n).replace(/[^\d.]/g, ''));
  return isFinite(v) && String(n).trim() !== ''
    ? v.toLocaleString('en-IN', { maximumFractionDigits: 2 })
    : '';
};

export const dmy = (iso: string) => {
  const p = String(iso || '').split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : iso || '';
};

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const lines: string[] = [];
  String(text)
    .split('\n')
    .forEach(para => {
      if (!para.trim()) {
        lines.push('');
        return;
      }
      let line = '';
      para.split(/\s+/).forEach(w => {
        const t = line ? line + ' ' + w : w;
        if (ctx.measureText(t).width > maxW && line) {
          lines.push(line);
          line = w;
        } else {
          line = t;
        }
      });
      if (line) lines.push(line);
    });
  return lines;
}

export interface CardOptions {
  ref?: string;
  name: string;
  account: string;
  amount: number | string;
  loanDate: string;
  dueDate: string;
  gross?: string;
  nett?: string;
  items?: string;
  notice: string;
  branch: string;
  fontScale?: number;
  rows?: {
    due?: boolean;
    gross?: boolean;
    nett?: boolean;
    items?: boolean;
  };
}

export async function renderCard(
  o: CardOptions
): Promise<{ blob: Blob; canvas: HTMLCanvasElement; width: number; height: number }> {
  const { logo } = await loadCardAssets();
  const fs = Number(o.fontScale) || 1;
  const rows = o.rows || {};
  const ctxM = document.createElement('canvas').getContext('2d')!;
  const fam = '"GDTamil", ' + LATIN;

  const trs: Array<[string, string]> = [
    ['Name of the Borrower', o.name || ''],
    ['Loan A/c No.', o.account || ''],
    ['Loan Amount', indian(o.amount)],
    ['Date of Loan', dmy(o.loanDate)]
  ];

  if (rows.due !== false) trs.push(['Due Date', dmy(o.dueDate)]);
  if (rows.gross && o.gross) trs.push(['Gross Weight', o.gross]);
  if (rows.nett && o.nett) trs.push(['Nett Weight', o.nett]);
  if (rows.items && o.items) trs.push(['No. of Items', o.items]);

  const rowH = Math.max(38, Math.ceil(14 * fs * 1.2 + 12));
  const tableH = trs.length * rowH + 1.5;

  ctxM.font = 'bold ' + 12 * fs + 'px ' + fam;
  const noticeW = INNER_W - 16 - 2;
  const lines = wrapText(ctxM, o.notice || '', noticeW);
  const lh = 12 * fs * 1.62;
  const noticeH = 16 + 2 + Math.max(1, lines.length) * lh;
  const titleSize = 16 * fs;
  const titleH = Math.ceil(titleSize * 1.15);
  const logoH = (INNER_W * logo.naturalHeight) / logo.naturalWidth;
  const refH = 19;
  const H =
    BORDER + PAD + refH + 6 + logoH + 10 + titleH + 10 + tableH + 15 + noticeH + PAD + BORDER;

  const c = document.createElement('canvas');
  c.width = CARD_W * K;
  c.height = Math.ceil(H * K);
  const g = c.getContext('2d')!;
  g.scale(K, K);
  g.imageSmoothingQuality = 'high';

  g.fillStyle = '#fff';
  g.fillRect(0, 0, CARD_W, H + 1);

  g.strokeStyle = MAROON;
  g.lineWidth = BORDER;
  g.strokeRect(BORDER / 2, BORDER / 2, CARD_W - BORDER, H - BORDER);

  const x0 = BORDER + PAD;
  let y = BORDER + PAD;

  if (o.ref) {
    g.fillStyle = '#000';
    g.font = 'bold ' + 13 * fs + 'px ' + LATIN;
    g.textAlign = 'right';
    g.textBaseline = 'middle';
    g.fillText(o.ref, x0 + INNER_W, y + refH / 2);
  }
  y += refH + 6;

  g.drawImage(logo, x0, y, INNER_W, logoH);
  y += logoH + 10;

  g.fillStyle = MAROON;
  g.font = 'bold ' + titleSize + 'px ' + LATIN;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText((o.branch || '').trim(), CARD_W / 2, y + titleH / 2);
  y += titleH + 10;

  const labelW = INNER_W * 0.45;
  const tx = x0;
  const ty = y;
  g.strokeStyle = '#000';
  g.lineWidth = 1.5;
  g.textAlign = 'left';
  g.fillStyle = '#000';

  trs.forEach(([lab, val], i) => {
    const ry = ty + i * rowH + 0.75;
    g.font = 'bold ' + 14 * fs + 'px ' + LATIN;
    g.fillText(lab, tx + 6, ry + rowH / 2);
    g.font = 14 * fs + 'px ' + fam;
    let v = String(val);
    const maxW = INNER_W - labelW - 12;
    while (g.measureText(v).width > maxW && v.length > 1) {
      v = v.slice(0, -1);
    }
    g.fillText(v, tx + labelW + 6, ry + rowH / 2);
  });

  g.beginPath();
  for (let i = 0; i <= trs.length; i++) {
    const ly = ty + i * rowH + 0.75;
    g.moveTo(tx, ly);
    g.lineTo(tx + INNER_W, ly);
  }
  g.moveTo(tx + 0.75, ty);
  g.lineTo(tx + 0.75, ty + tableH - 0.75);
  g.moveTo(tx + labelW, ty);
  g.lineTo(tx + labelW, ty + tableH - 0.75);
  g.moveTo(tx + INNER_W - 0.75, ty);
  g.lineTo(tx + INNER_W - 0.75, ty + tableH - 0.75);
  g.stroke();
  y += tableH + 15;

  // Notice box
  g.fillStyle = '#fdf8f8';
  g.fillRect(x0, y, INNER_W, noticeH);
  g.strokeStyle = MAROON;
  g.lineWidth = 1;
  g.setLineDash([4, 3]);
  g.strokeRect(x0 + 0.5, y + 0.5, INNER_W - 1, noticeH - 1);
  g.setLineDash([]);

  g.fillStyle = MAROON;
  g.font = 'bold ' + 12 * fs + 'px ' + fam;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  lines.forEach((ln, i) => {
    g.fillText(ln, CARD_W / 2, y + 9 + (i + 0.5) * lh);
  });

  const blob = await new Promise<Blob>((res, rej) =>
    c.toBlob(b => (b ? res(b) : rej(new Error('Browser could not encode image'))), 'image/png')
  );

  return { blob, canvas: c, width: c.width, height: c.height };
}

export const waNumber = (m: string | undefined): string => {
  const d = String(m || '').replace(/\D/g, '');
  if (d.length === 10) return '91' + d;
  if (d.length === 11 && d[0] === '0') return '91' + d.slice(1);
  return d;
};

export function downloadFile(blob: Blob, name: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export interface ShareOptions {
  filename: string;
  mobile?: string;
  text?: string;
  title?: string;
  chatOnly?: boolean;
}

export async function shareToWhatsApp(
  blob: Blob,
  o: ShareOptions
): Promise<'shared' | 'fallback' | 'cancelled'> {
  const file = new File([blob], o.filename, { type: 'image/png' });
  const num = waNumber(o.mobile);

  // Check if Web Share API with files is available and not in chatOnly mode
  const canFile =
    !o.chatOnly &&
    typeof navigator.share === 'function' &&
    typeof navigator.canShare === 'function' &&
    navigator.canShare({ files: [file] });

  if (canFile) {
    try {
      await navigator.share({
        files: [file],
        title: o.title || 'PNB Gold Loan Reminder',
        text: o.text || ''
      });
      return 'shared';
    } catch (e: any) {
      if (e?.name === 'AbortError') {
        return 'cancelled';
      }
      console.warn('Web Share API failed, falling back:', e);
    }
  }

  // Fallback: Copy PNG to clipboard if supported, open wa.me chat directly, and download PNG
  let copied = false;
  try {
    if (navigator.clipboard && (window as any).ClipboardItem) {
      await navigator.clipboard.write([
        new (window as any).ClipboardItem({ 'image/png': blob })
      ]);
      copied = true;
    }
  } catch (err) {
    console.warn('Clipboard write fallback:', err);
  }

  if (num) {
    const waUrl =
      'https://wa.me/' +
      num +
      (o.text ? '?text=' + encodeURIComponent(o.text) : '');
    window.open(waUrl, '_blank', 'noopener');
  }

  if (!copied) {
    downloadFile(blob, o.filename);
  }

  return 'fallback';
}
