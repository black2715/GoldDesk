import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Loan } from '../types';
import { renewalState, toISO } from '../lib/core';

interface LoansProps {
  onOpenNewLoan: () => void;
  onViewLoan: (loan: Loan) => void;
}

export const Loans: React.FC<LoansProps> = ({ onOpenNewLoan, onViewLoan }) => {
  const { dbState, deleteLoan } = useData();
  const [search, setSearch] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const todayStr = toISO(new Date());
  const query = search.toLowerCase().trim();

  const getCustomer = (cid: string) =>
    dbState.customers.find(c => c.id === cid) || {
      name: 'Unknown Customer',
      mobile: ''
    };

  const filtered = dbState.loans
    .filter(l => {
      const cust = getCustomer(l.cid);
      return [l.ledger, cust.name, cust.mobile, l.date].some(val =>
        String(val || '').toLowerCase().includes(query)
      );
    })
    .sort((a, b) => b.date.localeCompare(a.date));

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  const handleDelete = async (l: Loan, e: React.MouseEvent) => {
    e.stopPropagation();
    if (
      window.confirm(
        `Delete gold loan "${l.ledger}"? Appraiser charge ${formatMoney(
          l.charge
        )} will be removed from pending balances. Photos remain permanently preserved in archive. This cannot be undone.`
      )
    ) {
      setDeletingId(l.id);
      try {
        await deleteLoan(l.id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Loan Register
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Gold Loans
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Registered gold loans and appraiser charges. Settlements are managed exclusively in the Settlement page.
          </p>
        </div>
        <button
          onClick={onOpenNewLoan}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto cursor-pointer"
        >
          ＋ New Gold Loan
        </button>
      </div>

      {/* Toolbar */}
      <div className="relative">
        <input
          type="search"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search ledger number, customer name, mobile..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#e7ebf2] rounded-xl text-xs text-[#19243a] placeholder-[#78839a] focus:outline-hidden focus:border-teal-500 shadow-xs"
        />
        <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm">
          🔍
        </span>
      </div>

      {/* Loans Table */}
      <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Ledger / Customer</th>
                <th className="py-3 px-4">Loan Amount</th>
                <th className="py-3 px-4">Appraiser Charge</th>
                <th className="py-3 px-4">Loan Date</th>
                <th className="py-3 px-4">Renewal Due</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Photos</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length > 0 ? (
                filtered.map(l => {
                  const cust = getCustomer(l.cid);
                  const state = renewalState(l, todayStr);
                  const photoCount = (l.imageIds || []).length;

                  let statusColor = 'bg-blue-50 text-blue-700 border-blue-200';
                  if (state === 'Overdue') {
                    statusColor = 'bg-rose-50 text-rose-700 border-rose-200';
                  } else if (state === 'Due Today') {
                    statusColor = 'bg-amber-50 text-amber-700 border-amber-200';
                  } else if (state === 'Renewed' || state === 'Closed Loan') {
                    statusColor = 'bg-slate-100 text-slate-600 border-slate-200';
                  }

                  return (
                    <tr
                      key={l.id}
                      onClick={() => onViewLoan(l)}
                      className="hover:bg-slate-50/80 transition cursor-pointer"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 font-extrabold grid place-items-center text-xs shrink-0">
                            GL
                          </div>
                          <div>
                            <strong className="block font-bold text-[#19243a] text-xs">
                              {l.ledger}
                            </strong>
                            <small className="text-[10px] text-[#78839a] font-medium">
                              {cust.name} {cust.mobile ? `· ${cust.mobile}` : ''}
                            </small>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">
                        {formatMoney(l.amount)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-600">
                        {formatMoney(l.charge)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {formatDate(l.date)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {formatDate(l.renewal || '')}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColor}`}
                        >
                          {state}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-semibold">
                          📷 {photoCount}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onViewLoan(l)}
                            className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                          >
                            View
                          </button>
                          <button
                            onClick={e => handleDelete(l, e)}
                            disabled={deletingId === l.id}
                            className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg font-semibold text-[11px] transition cursor-pointer disabled:opacity-50"
                          >
                            {deletingId === l.id ? '...' : 'Delete'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#78839a]">
                    <div className="text-sm font-bold text-slate-700">
                      {search ? 'No loans match your search.' : 'No gold loans recorded yet.'}
                    </div>
                    <div className="text-xs mt-1">
                      {search ? 'Try adjusting your search criteria.' : 'Click "New Gold Loan" to record your first loan.'}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
