import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Loan, Customer } from '../types';
import { renewalList, renewalState, renewalArchive, toISO } from '../lib/core';

interface RenewalsProps {
  onOpenRenewModal: (loan: Loan) => void;
  onOpenReminderModal: (loan: Loan) => void;
  onViewLoan: (loan: Loan) => void;
}

export const Renewals: React.FC<RenewalsProps> = ({
  onOpenRenewModal,
  onOpenReminderModal,
  onViewLoan
}) => {
  const { dbState } = useData();
  const [search, setSearch] = useState('');
  const [filterState, setFilterState] = useState<string>('');

  const todayStr = toISO(new Date());
  const reminderDays = dbState.settings.reminderDays || 10;

  const allActive = renewalList(dbState, todayStr);
  const archived = renewalArchive(dbState);

  const getCustomer = (cid: string): Customer =>
    dbState.customers.find(c => c.id === cid) || {
      id: cid,
      userId: '',
      name: 'Unknown Customer',
      mobile: '',
      address: ''
    };

  const query = search.toLowerCase().trim();
  const filteredActive = allActive.filter(l => {
    const cust = getCustomer(l.cid);
    const matchesSearch = [l.ledger, cust.name, cust.mobile].some(val =>
      String(val || '').toLowerCase().includes(query)
    );
    const state = renewalState(l, todayStr);
    const matchesFilter = !filterState || state === filterState;
    return matchesSearch && matchesFilter;
  });

  const dueTodayCount = allActive.filter(l => renewalState(l, todayStr) === 'Due Today').length;
  const upcomingCount = allActive.filter(l => renewalState(l, todayStr) === 'Upcoming').length;
  const overdueCount = allActive.filter(l => renewalState(l, todayStr) === 'Overdue').length;

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Customer Retention &amp; Alerts
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Gold Loan Renewals
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Loans overdue and due within {reminderDays} days. Send WhatsApp borrower cards directly to customers.
          </p>
        </div>
        <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 self-start sm:self-auto">
          Reminder window: {reminderDays} days
        </span>
      </div>

      {/* Top Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-amber-200 bg-amber-50/20 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-amber-700">Due Today</div>
            <div className="text-2xl font-black text-amber-700 mt-1">{dueTodayCount}</div>
          </div>
          <span className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 grid place-items-center text-lg font-bold">
            !
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-blue-200 bg-blue-50/20 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-blue-700">Upcoming (Within {reminderDays}d)</div>
            <div className="text-2xl font-black text-blue-700 mt-1">{upcomingCount}</div>
          </div>
          <span className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 grid place-items-center text-lg font-bold">
            ◷
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-rose-200 bg-rose-50/20 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-rose-700">Overdue</div>
            <div className="text-2xl font-black text-rose-700 mt-1">{overdueCount}</div>
          </div>
          <span className="w-10 h-10 rounded-xl bg-rose-100 text-rose-800 grid place-items-center text-lg font-bold">
            ⚠
          </span>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <input
            type="search"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search ledger, borrower name, mobile..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#e7ebf2] rounded-xl text-xs text-[#19243a] placeholder-[#78839a] focus:outline-hidden focus:border-teal-500 shadow-xs"
          />
          <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm">
            🔍
          </span>
        </div>

        <select
          value={filterState}
          onChange={e => setFilterState(e.target.value)}
          className="text-xs p-2.5 bg-white border border-[#e7ebf2] rounded-xl font-medium focus:outline-hidden focus:border-teal-500"
        >
          <option value="">All Active Loans ({allActive.length})</option>
          <option value="Due Today">Due Today ({dueTodayCount})</option>
          <option value="Upcoming">Upcoming ({upcomingCount})</option>
          <option value="Overdue">Overdue ({overdueCount})</option>
        </select>
      </div>

      {/* Active Renewals Table */}
      <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-[#e7ebf2] bg-slate-50 flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#19243a]">Active Renewal Queue</h2>
          <span className="text-xs text-[#78839a]">
            {filteredActive.length} loan(s) pending action
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Ledger / Customer</th>
                <th className="py-3 px-4">Customer WhatsApp</th>
                <th className="py-3 px-4">Loan Amount</th>
                <th className="py-3 px-4">Renewal Date</th>
                <th className="py-3 px-4">State</th>
                <th className="py-3 px-4 text-center">Manage Choice</th>
                <th className="py-3 px-4 text-right">Reminder Card</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredActive.length > 0 ? (
                filteredActive.map(l => {
                  const cust = getCustomer(l.cid);
                  const state = renewalState(l, todayStr);

                  let badgeColor = 'bg-blue-50 text-blue-700 border-blue-200';
                  if (state === 'Overdue') {
                    badgeColor = 'bg-rose-50 text-rose-700 border-rose-200';
                  } else if (state === 'Due Today') {
                    badgeColor = 'bg-amber-50 text-amber-700 border-amber-200';
                  }

                  return (
                    <tr key={l.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <strong className="block font-bold text-[#19243a] text-xs">
                          {l.ledger}
                        </strong>
                        <small className="text-[10px] text-[#78839a] font-medium">
                          {cust.name}
                        </small>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        {cust.mobile || 'No mobile saved'}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">
                        {formatMoney(l.amount)}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        {formatDate(l.renewal || '')}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${badgeColor}`}>
                          {state}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {/* Requirement 7: Renewal choices: Renew and Close only */}
                        <button
                          onClick={() => onOpenRenewModal(l)}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold text-xs transition cursor-pointer"
                        >
                          Renew / Close
                        </button>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        {/* Requirement 6: Reminder modal with WhatsApp and Download */}
                        <button
                          onClick={() => onOpenReminderModal(l)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs transition shadow-xs cursor-pointer"
                        >
                          <span>💬</span> Reminder
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#78839a]">
                    <div className="text-sm font-bold text-slate-700">
                      No loans currently due or overdue.
                    </div>
                    <div className="text-xs mt-1">
                      Loans due within {reminderDays} days appear in this queue automatically.
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Archived Renewed & Closed Loans */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-[#19243a]">Renewed &amp; Closed Loans Archive</h2>
        <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Ledger / Customer</th>
                  <th className="py-3 px-4">Loan Amount</th>
                  <th className="py-3 px-4">Renewal Date</th>
                  <th className="py-3 px-4">Archive State</th>
                  <th className="py-3 px-4 text-right">History / Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {archived.length > 0 ? (
                  archived.map(l => {
                    const cust = getCustomer(l.cid);
                    const renewedToLoan = dbState.loans.find(x => x.id === l.renewedTo);
                    const renewedFromLoan = dbState.loans.find(x => x.id === l.renewedFrom);

                    return (
                      <tr key={l.id} className="hover:bg-slate-50/80 transition text-slate-600">
                        <td className="py-3.5 px-4">
                          <strong className="block font-bold text-[#19243a] text-xs">
                            {l.ledger}
                          </strong>
                          <small className="text-[10px] text-[#78839a] font-medium">
                            {cust.name}
                          </small>
                        </td>
                        <td className="py-3.5 px-4 font-bold text-slate-700">
                          {formatMoney(l.amount)}
                        </td>
                        <td className="py-3.5 px-4">
                          {formatDate(l.renewal || '')}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            {l.renewalStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {renewedToLoan && (
                              <span className="text-[10px] text-teal-600 font-semibold">
                                Renewed as: {renewedToLoan.ledger}
                              </span>
                            )}
                            {renewedFromLoan && (
                              <span className="text-[10px] text-indigo-600 font-semibold">
                                Renewed from: {renewedFromLoan.ledger}
                              </span>
                            )}
                            <button
                              onClick={() => onViewLoan(l)}
                              className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                            >
                              View
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#78839a]">
                      No loans have been renewed or closed yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
