import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Payment } from '../types';
import { accounts, toISO, weekBounds, parseISO, addDays } from '../lib/core';

interface SettlementsProps {
  onOpenPaymentModal: (acct: 'a2' | 'hA1' | 'hA2', paymentToEdit?: Payment, presetAmount?: number) => void;
  onOpenLogModal: (payment: Payment) => void;
}

export const Settlements: React.FC<SettlementsProps> = ({
  onOpenPaymentModal,
  onOpenLogModal
}) => {
  const { dbState, reversePayment } = useData();
  const settings = dbState.settings;

  const a1Name = settings.appraiser1Name || 'Appraiser 1';
  const a2Name = settings.appraiser2Name || 'Appraiser 2';
  const helperName = settings.helperName || 'Helper';

  const [filterAcct, setFilterAcct] = useState<string>('');
  const [filterYear, setFilterYear] = useState<string>('');
  const [filterMonth, setFilterMonth] = useState<string>('');
  const [filterWeek, setFilterWeek] = useState<string>('');
  const [filterDay, setFilterDay] = useState<string>('');
  const [reversingId, setReversingId] = useState<string | null>(null);

  const acctData = accounts(dbState);

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  const accName = (k: string) => {
    if (k === 'a2') return `${a2Name} (Appraiser 2 Share)`;
    if (k === 'hA1') return `${helperName} (Helper Share — borne by ${a1Name})`;
    return `${helperName} (Legacy entry)`;
  };

  // Filter payment records
  const allPayments = dbState.payments
    .filter(p => {
      if (filterAcct) {
        if (filterAcct === 'hA1') {
          if (p.acct !== 'hA1' && p.acct !== 'hA2') return false;
        } else if (p.acct !== filterAcct) {
          return false;
        }
      }
      return true;
    })
    .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));

  const years = Array.from(new Set(allPayments.map(p => p.date.slice(0, 4)))).sort().reverse();

  const inYear = allPayments.filter(p => !filterYear || p.date.slice(0, 4) === filterYear);
  const months = filterYear
    ? Array.from(new Set(inYear.map(p => p.date.slice(5, 7)))).sort()
    : [];

  const inMonth = inYear.filter(p => !filterMonth || p.date.slice(5, 7) === filterMonth);
  const weeks = filterMonth
    ? Array.from(new Set(inMonth.map(p => weekBounds(p.date)[0]))).sort().reverse()
    : [];

  const inWeek = inMonth.filter(p => !filterWeek || weekBounds(p.date)[0] === filterWeek);
  const days = filterWeek
    ? Array.from(new Set(inWeek.map(p => p.date))).sort().reverse()
    : [];

  const displayedPayments = inWeek.filter(p => !filterDay || p.date === filterDay);

  const totalPaidInFilter = displayedPayments
    .filter(p => p.status !== 'reversed')
    .reduce((sum, p) => sum + p.amount, 0);

  const handleReverse = async (p: Payment) => {
    if (
      window.confirm(
        `Reverse settlement payment of ${formatMoney(p.amount)} recorded on ${formatDate(
          p.date
        )}? The amount will be added back to the pending balance. The record stays in history marked Reversed.`
      )
    ) {
      setReversingId(p.id);
      try {
        await reversePayment(p.id);
      } finally {
        setReversingId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
          Running Account &amp; Payouts
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
          Settlement
        </h1>
        <p className="text-xs text-[#78839a] mt-0.5">
          Income split shares: Appraiser 1 (37.5%), Appraiser 2 (37.5%), Helper (25%). {a1Name} alone pays the Helper's share. Record partial or full payments directly below.
        </p>
      </div>

      {/* Running Accounts Summary Table */}
      <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-[#e7ebf2] bg-slate-50 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-[#19243a]">Active Running Balances</h2>
            <p className="text-[11px] text-[#78839a]">
              Calculated automatically from gold loans registered.
            </p>
          </div>
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
            Real-time Balance
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Account</th>
                <th className="py-3 px-4">Accrued from Loans</th>
                <th className="py-3 px-4">Paid so Far</th>
                <th className="py-3 px-4">Pending Balance</th>
                <th className="py-3 px-4 text-right">Settlement Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {/* Appraiser 2 */}
              <tr className="hover:bg-slate-50/80 transition">
                <td className="py-4 px-4">
                  <strong className="block font-bold text-[#19243a] text-xs">
                    {accName('a2')}
                  </strong>
                  <small className="text-[10px] text-[#78839a]">
                    Separate 37.5% share · independent settlements
                  </small>
                </td>
                <td className="py-4 px-4 font-bold text-slate-700">
                  {formatMoney(acctData.a2.accrued)}
                </td>
                <td className="py-4 px-4 text-slate-600">
                  {formatMoney(acctData.a2.paid)}
                </td>
                <td className="py-4 px-4">
                  <span className="font-extrabold text-base text-rose-600">
                    {formatMoney(acctData.a2.pending)}
                  </span>
                  {acctData.a2.advance > 0 && (
                    <span className="block text-[10px] text-teal-600 font-semibold">
                      Advance: {formatMoney(acctData.a2.advance)}
                    </span>
                  )}
                </td>
                <td className="py-4 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => onOpenPaymentModal('a2')}
                      className="px-3 py-1.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      Record Payment
                    </button>
                    <button
                      onClick={() => onOpenPaymentModal('a2', undefined, acctData.a2.pending)}
                      disabled={acctData.a2.pending <= 0}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition cursor-pointer disabled:opacity-40"
                    >
                      Settle Full
                    </button>
                  </div>
                </td>
              </tr>

              {/* Helper */}
              <tr className="hover:bg-slate-50/80 transition">
                <td className="py-4 px-4">
                  <strong className="block font-bold text-[#19243a] text-xs">
                    {accName('hA1')}
                  </strong>
                  <small className="text-[10px] text-amber-700 font-medium">
                    25% allocation · borne exclusively by {a1Name}
                  </small>
                </td>
                <td className="py-4 px-4 font-bold text-slate-700">
                  {formatMoney(acctData.hA1.accrued)}
                </td>
                <td className="py-4 px-4 text-slate-600">
                  {formatMoney(acctData.hA1.paid)}
                </td>
                <td className="py-4 px-4">
                  <span className="font-extrabold text-base text-amber-700">
                    {formatMoney(acctData.hA1.pending)}
                  </span>
                  {acctData.hA1.advance > 0 && (
                    <span className="block text-[10px] text-teal-600 font-semibold">
                      Advance: {formatMoney(acctData.hA1.advance)}
                    </span>
                  )}
                </td>
                <td className="py-4 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => onOpenPaymentModal('hA1')}
                      className="px-3 py-1.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      Record Payment
                    </button>
                    <button
                      onClick={() => onOpenPaymentModal('hA1', undefined, acctData.hA1.pending)}
                      disabled={acctData.hA1.pending <= 0}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition cursor-pointer disabled:opacity-40"
                    >
                      Settle Full
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Settlement History with Cascading Filters */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">Settlement Payment History</h2>
            <p className="text-xs text-[#78839a]">
              Cascading drilldown: Account → Year → Month → Week → Day
            </p>
          </div>
          <div className="text-xs font-bold text-[#19243a]">
            Filtered Total Paid: <span className="text-emerald-600">{formatMoney(totalPaidInFilter)}</span>
          </div>
        </div>

        {/* Cascading Filter Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-white p-3 rounded-2xl border border-[#e7ebf2] shadow-xs">
          <div>
            <label className="block text-[10px] font-bold text-[#78839a] uppercase mb-1">
              Account
            </label>
            <select
              value={filterAcct}
              onChange={e => {
                setFilterAcct(e.target.value);
                setFilterYear('');
                setFilterMonth('');
                setFilterWeek('');
                setFilterDay('');
              }}
              className="w-full text-xs p-2 bg-slate-50 border border-[#e7ebf2] rounded-lg focus:outline-hidden focus:border-teal-500 font-medium"
            >
              <option value="">All Accounts</option>
              <option value="a2">{a2Name}</option>
              <option value="hA1">{helperName}</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-[#78839a] uppercase mb-1">
              Year
            </label>
            <select
              value={filterYear}
              onChange={e => {
                setFilterYear(e.target.value);
                setFilterMonth('');
                setFilterWeek('');
                setFilterDay('');
              }}
              className="w-full text-xs p-2 bg-slate-50 border border-[#e7ebf2] rounded-lg focus:outline-hidden focus:border-teal-500 font-medium"
            >
              <option value="">All Years</option>
              {years.map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-[#78839a] uppercase mb-1">
              Month
            </label>
            <select
              value={filterMonth}
              disabled={!filterYear}
              onChange={e => {
                setFilterMonth(e.target.value);
                setFilterWeek('');
                setFilterDay('');
              }}
              className="w-full text-xs p-2 bg-slate-50 border border-[#e7ebf2] rounded-lg focus:outline-hidden focus:border-teal-500 font-medium disabled:opacity-40"
            >
              <option value="">All Months</option>
              {months.map(m => {
                const monthName = new Date(2026, parseInt(m, 10) - 1, 1).toLocaleString('en-IN', {
                  month: 'long'
                });
                return <option key={m} value={m}>{monthName}</option>;
              })}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-[#78839a] uppercase mb-1">
              Week
            </label>
            <select
              value={filterWeek}
              disabled={!filterMonth}
              onChange={e => {
                setFilterWeek(e.target.value);
                setFilterDay('');
              }}
              className="w-full text-xs p-2 bg-slate-50 border border-[#e7ebf2] rounded-lg focus:outline-hidden focus:border-teal-500 font-medium disabled:opacity-40"
            >
              <option value="">All Weeks</option>
              {weeks.map(w => (
                <option key={w} value={w}>
                  {formatDate(w)} – {formatDate(addDays(w, 5))}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-[#78839a] uppercase mb-1">
              Day
            </label>
            <select
              value={filterDay}
              disabled={!filterWeek}
              onChange={e => setFilterDay(e.target.value)}
              className="w-full text-xs p-2 bg-slate-50 border border-[#e7ebf2] rounded-lg focus:outline-hidden focus:border-teal-500 font-medium disabled:opacity-40"
            >
              <option value="">All Days</option>
              {days.map(d => (
                <option key={d} value={d}>{formatDate(d)}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Payments Table */}
        <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Payment Date</th>
                  <th className="py-3 px-4">Account</th>
                  <th className="py-3 px-4">Amount Paid</th>
                  <th className="py-3 px-4">Note / Reference</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {displayedPayments.length > 0 ? (
                  displayedPayments.map(p => {
                    const isReversed = p.status === 'reversed';
                    return (
                      <tr
                        key={p.id}
                        className={`hover:bg-slate-50/80 transition ${
                          isReversed ? 'opacity-50 bg-slate-50/40' : ''
                        }`}
                      >
                        <td className="py-3.5 px-4 font-medium text-slate-700">
                          {formatDate(p.date)}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-[#19243a]">
                          {accName(p.acct)}
                        </td>
                        <td className="py-3.5 px-4">
                          <strong
                            className={`font-black text-xs ${
                              isReversed
                                ? 'line-through text-slate-400'
                                : 'text-emerald-600'
                            }`}
                          >
                            {formatMoney(p.amount)}
                          </strong>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 max-w-[220px] truncate" title={p.note}>
                          {p.note || '—'}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isReversed
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            }`}
                          >
                            {isReversed ? 'Reversed' : 'Recorded'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {!isReversed && (
                              <>
                                <button
                                  onClick={() => onOpenPaymentModal(p.acct, p)}
                                  className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                                >
                                  Correct
                                </button>
                                <button
                                  onClick={() => handleReverse(p)}
                                  disabled={reversingId === p.id}
                                  className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg font-semibold text-[11px] transition cursor-pointer disabled:opacity-50"
                                >
                                  {reversingId === p.id ? '...' : 'Reverse'}
                                </button>
                              </>
                            )}
                            <button
                              onClick={() => onOpenLogModal(p)}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                            >
                              Log ({p.history?.length || 1})
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-[#78839a]">
                      <div className="text-sm font-bold text-slate-700">
                        No settlement payments found for the selected filters.
                      </div>
                      <div className="text-xs mt-1">
                        Use "Record Payment" to record a payout to Appraiser 2 or Helper.
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
