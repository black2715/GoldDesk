import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { AppSettings } from '../types';
import { testCloudStorageConnection } from '../lib/cloudStorage';

export const Settings: React.FC = () => {
  const { dbState, saveSettings, saveHoliday, deleteHoliday, exportJsonBackup, importJsonBackup } = useData();
  const currentSettings = dbState.settings;

  const [form, setForm] = useState<AppSettings>(currentSettings);
  const [dirty, setDirty] = useState(false);
  const [cloudTesting, setCloudTesting] = useState<string | null>(null);
  const [cloudStatus, setCloudStatus] = useState<Record<string, { ok?: boolean; msg?: string }>>({});
  const [newHolDate, setNewHolDate] = useState('');
  const [newHolName, setNewHolName] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (!dirty) {
      setForm(currentSettings);
    }
  }, [currentSettings, dirty]);

  const updateForm = (patch: Partial<AppSettings>) => {
    setDirty(true);
    setSaveMessage(null);
    setForm(prev => ({ ...prev, ...patch }));
  };

  const totalSplit =
    Math.round(
      ((Number(form.split1) || 0) + (Number(form.split2) || 0) + (Number(form.splitHelper) || 0)) *
        100
    ) / 100;
  const splitValid = Math.abs(totalSplit - 100) < 0.01;

  const handleSave = async () => {
    setSaveMessage(null);
    if (!form.appraiser1Name.trim() || !form.appraiser2Name.trim() || !form.helperName.trim()) {
      setSaveMessage({ ok: false, text: 'Appraiser 1, Appraiser 2, and Helper names cannot be empty.' });
      return;
    }
    if (!splitValid) {
      setSaveMessage({ ok: false, text: `Income splits must total exactly 100%. Current sum: ${totalSplit}%` });
      return;
    }
    const packetRate = Number(form.packetRate);
    if (!Number.isFinite(packetRate) || packetRate < 0) {
      setSaveMessage({ ok: false, text: 'Inspection amount per packet must be 0 or higher.' });
      return;
    }
    const waDigits = (form.rateWhatsapp || '').replace(/\D/g, '');
    if (waDigits && waDigits.length < 10) {
      setSaveMessage({ ok: false, text: 'Enter a valid Gold-Rate WhatsApp number (at least 10 digits).' });
      return;
    }

    setSaving(true);
    try {
      await saveSettings({
        ...form,
        appraiser1Name: form.appraiser1Name.trim(),
        appraiser2Name: form.appraiser2Name.trim(),
        helperName: form.helperName.trim(),
        branchName: (form.branchName || '').trim(),
        branchCode: (form.branchCode || '').trim(),
        rateWhatsapp: (form.rateWhatsapp || '').trim(),
        packetRate,
        bankShareValue: Number(form.bankShareValue) || 0,
        feeStandard: Number(form.feeStandard) || 0,
        feeHigh: Number(form.feeHigh) || 0,
        feeThreshold: Number(form.feeThreshold) || 0,
        feePercent: Number(form.feePercent) || 0,
        feeMin: Number(form.feeMin) || 0,
        feeMax: Number(form.feeMax) || 0,
        reminderDays: Math.max(0, Math.min(365, Number(form.reminderDays) || 0))
      });
      setDirty(false);
      setSaveMessage({ ok: true, text: 'Settings saved and synced successfully!' });
    } catch (e: any) {
      setSaveMessage({ ok: false, text: `Save failed: ${e.message}` });
    } finally {
      setSaving(false);
    }
  };

  const handleTestCloud = async (provider: 'gdrive' | 'onedrive' | 'dropbox') => {
    const token =
      provider === 'gdrive'
        ? form.cloudStorage?.googleDriveAccessToken
        : provider === 'onedrive'
        ? form.cloudStorage?.oneDriveAccessToken
        : form.cloudStorage?.dropboxAccessToken;

    if (!token) {
      setCloudStatus(prev => ({
        ...prev,
        [provider]: { ok: false, msg: `Please enter an access token for ${provider.toUpperCase()} first.` }
      }));
      return;
    }

    setCloudTesting(provider);
    try {
      const res = await testCloudStorageConnection(provider, token);
      if (res.ok) {
        setCloudStatus(prev => ({
          ...prev,
          [provider]: { ok: true, msg: `Connected successfully (${res.user || provider})` }
        }));
      } else {
        setCloudStatus(prev => ({
          ...prev,
          [provider]: { ok: false, msg: res.error || 'Connection failed' }
        }));
      }
    } finally {
      setCloudTesting(null);
    }
  };

  const handleAddHoliday = async () => {
    if (!newHolDate) {
      setSaveMessage({ ok: false, text: 'Please select a holiday date first.' });
      return;
    }
    await saveHoliday(newHolDate, newHolName || 'Bank Holiday');
    setNewHolDate('');
    setNewHolName('');
  };

  const handleExportBackup = async () => {
    try {
      const data = await exportJsonBackup();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `golddesk-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      a.remove();
    } catch (err: any) {
      setSaveMessage({ ok: false, text: `Export failed: ${err.message}` });
    }
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    try {
      const text = await file.text();
      const json = JSON.parse(text);
      if (
        window.confirm(
          'Import this backup? Existing data will be updated with the records from the backup file.'
        )
      ) {
        const res = await importJsonBackup(json);
        if (res.ok) {
          setSaveMessage({ ok: true, text: 'Backup imported successfully!' });
        } else {
          setSaveMessage({ ok: false, text: `Import errors: ${res.errors.join(', ')}` });
        }
      }
    } catch (err: any) {
      setSaveMessage({ ok: false, text: `Import failed: ${err.message}` });
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Configuration &amp; Integrations
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Settings
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Names, income split formulas, inspection packet rate, charges, WhatsApp numbers, and Cloud photo storage.
          </p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-5 py-2.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto cursor-pointer disabled:opacity-50"
        >
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      {saveMessage && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs font-semibold flex items-center justify-between ${
            saveMessage.ok
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <span>{saveMessage.text}</span>
          <button
            type="button"
            onClick={() => setSaveMessage(null)}
            className="text-xs font-bold opacity-70 hover:opacity-100 ml-4"
          >
            ✕
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Names & Income Split */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#e7ebf2]">
            <div>
              <h2 className="text-sm font-bold text-[#19243a]">Names &amp; Income Split</h2>
              <p className="text-xs text-[#78839a]">Shares must total exactly 100%</p>
            </div>
            <span
              className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full border ${
                splitValid
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : 'bg-rose-50 text-rose-700 border-rose-200'
              }`}
            >
              Total {totalSplit}%
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Appraiser 1 (Lead Appraiser)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={form.appraiser1Name}
                  onChange={e => updateForm({ appraiser1Name: e.target.value })}
                  placeholder="Appraiser 1 Name"
                  className="flex-1 p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-medium focus:outline-hidden focus:border-teal-500"
                />
                <div className="relative w-24">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={form.split1}
                    onChange={e => updateForm({ split1: Number(e.target.value) })}
                    className="w-full p-2 pr-6 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                  />
                  <span className="absolute right-2.5 top-2 text-slate-400 font-bold text-xs">%</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Appraiser 2 (Separate Settlements)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={form.appraiser2Name}
                  onChange={e => updateForm({ appraiser2Name: e.target.value })}
                  placeholder="Appraiser 2 Name"
                  className="flex-1 p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-medium focus:outline-hidden focus:border-teal-500"
                />
                <div className="relative w-24">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={form.split2}
                    onChange={e => updateForm({ split2: Number(e.target.value) })}
                    className="w-full p-2 pr-6 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                  />
                  <span className="absolute right-2.5 top-2 text-slate-400 font-bold text-xs">%</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Helper (Borne Wholly by Appraiser 1)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={form.helperName}
                  onChange={e => updateForm({ helperName: e.target.value })}
                  placeholder="Helper Name"
                  className="flex-1 p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-medium focus:outline-hidden focus:border-teal-500"
                />
                <div className="relative w-24">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={form.splitHelper}
                    onChange={e => updateForm({ splitHelper: Number(e.target.value) })}
                    className="w-full p-2 pr-6 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                  />
                  <span className="absolute right-2.5 top-2 text-slate-400 font-bold text-xs">%</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Bank Share of Inspection
                </label>
                <select
                  value={form.bankMode}
                  onChange={e => updateForm({ bankMode: e.target.value as 'percent' | 'fixed' })}
                  className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                >
                  <option value="percent">Percent (%)</option>
                  <option value="fixed">Fixed (₹)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Bank Share Value ({form.bankMode === 'percent' ? '%' : '₹'})
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.bankShareValue}
                  onChange={e => updateForm({ bankShareValue: Number(e.target.value) })}
                  className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Loan Charge Rules */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
          <div className="pb-2 border-b border-[#e7ebf2]">
            <h2 className="text-sm font-bold text-[#19243a]">Loan Appraisal Charge Rules</h2>
            <p className="text-xs text-[#78839a]">Fixed fee or percentage mode with optional floor/cap</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Standard Fee (₹)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feeStandard}
                onChange={e => updateForm({ feeStandard: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Fee Above Threshold (₹)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feeHigh}
                onChange={e => updateForm({ feeHigh: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Threshold Amount (₹)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feeThreshold}
                onChange={e => updateForm({ feeThreshold: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Calculation Mode
              </label>
              <select
                value={form.feeMode}
                onChange={e => updateForm({ feeMode: e.target.value as 'fixed' | 'percent' })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              >
                <option value="fixed">Fixed Fee Mode</option>
                <option value="percent">Percentage Mode</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Percentage (%)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feePercent}
                onChange={e => updateForm({ feePercent: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Minimum Fee (₹)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feeMin}
                onChange={e => updateForm({ feeMin: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Maximum Fee (₹) <span className="font-normal text-slate-400">(0 = no cap)</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.feeMax}
                onChange={e => updateForm({ feeMax: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Inspection, Branch & WhatsApp Settings */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
          <div className="pb-2 border-b border-[#e7ebf2]">
            <h2 className="text-sm font-bold text-[#19243a]">Inspection, Branch &amp; WhatsApp</h2>
            <p className="text-xs text-[#78839a]">
              Inspection packet rate, reminder window, borrower card branch, and Gold-rate WhatsApp
            </p>
          </div>

          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Inspection Amount per Packet (₹) *
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.packetRate}
                  onChange={e => updateForm({ packetRate: Number(e.target.value) })}
                  placeholder="e.g. 100"
                  className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                />
                <small className="block text-[10px] text-slate-500 mt-1">
                  Default rate per packet used in Inspections
                </small>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Renewal Reminder Days
                </label>
                <input
                  type="number"
                  min="0"
                  max="365"
                  value={form.reminderDays}
                  onChange={e => updateForm({ reminderDays: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
                />
                <small className="block text-[10px] text-slate-500 mt-1">
                  Show loans due within these days
                </small>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Gold-Rate WhatsApp Number (Settings Target)
              </label>
              <input
                type="tel"
                value={form.rateWhatsapp}
                onChange={e => updateForm({ rateWhatsapp: e.target.value })}
                placeholder="e.g. 9876543210 (10 digits)"
                className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold focus:outline-hidden focus:border-teal-500"
              />
              <small className="block text-[10px] text-slate-500 mt-1">
                Share Gold Rate poster opens this exact saved WhatsApp number.
              </small>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Branch Name
                </label>
                <input
                  type="text"
                  value={form.branchName}
                  onChange={e => updateForm({ branchName: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-medium focus:outline-hidden focus:border-teal-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Branch Code
                </label>
                <input
                  type="text"
                  value={form.branchCode}
                  onChange={e => updateForm({ branchCode: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-medium focus:outline-hidden focus:border-teal-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Cloud Photo Storage (Requirement 4) */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
          <div className="pb-2 border-b border-[#e7ebf2]">
            <h2 className="text-sm font-bold text-[#19243a]">Cloud Photo Storage (Retention)</h2>
            <p className="text-xs text-[#78839a]">
              Connect Google Drive, OneDrive, and Dropbox. Photos are never automatically deleted.
            </p>
          </div>

          <div className="space-y-4">
            {/* Google Drive */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.cloudStorage?.googleDriveEnabled || false}
                    onChange={e =>
                      updateForm({
                        cloudStorage: { ...form.cloudStorage, googleDriveEnabled: e.target.checked }
                      })
                    }
                    className="rounded"
                  />
                  Google Drive Backup
                </label>
                <button
                  type="button"
                  onClick={() => handleTestCloud('gdrive')}
                  disabled={cloudTesting === 'gdrive'}
                  className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition"
                >
                  {cloudTesting === 'gdrive' ? 'Testing...' : 'Test Connection'}
                </button>
              </div>
              <input
                type="text"
                placeholder="Google Drive OAuth / Access Token"
                value={form.cloudStorage?.googleDriveAccessToken || ''}
                onChange={e =>
                  updateForm({
                    cloudStorage: { ...form.cloudStorage, googleDriveAccessToken: e.target.value }
                  })
                }
                className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
              {cloudStatus.gdrive && (
                <div
                  className={`text-[10px] font-semibold ${
                    cloudStatus.gdrive.ok ? 'text-teal-600' : 'text-rose-600'
                  }`}
                >
                  {cloudStatus.gdrive.msg}
                </div>
              )}
            </div>

            {/* Microsoft OneDrive */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.cloudStorage?.oneDriveEnabled || false}
                    onChange={e =>
                      updateForm({
                        cloudStorage: { ...form.cloudStorage, oneDriveEnabled: e.target.checked }
                      })
                    }
                    className="rounded"
                  />
                  Microsoft OneDrive Backup
                </label>
                <button
                  type="button"
                  onClick={() => handleTestCloud('onedrive')}
                  disabled={cloudTesting === 'onedrive'}
                  className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition"
                >
                  {cloudTesting === 'onedrive' ? 'Testing...' : 'Test Connection'}
                </button>
              </div>
              <input
                type="text"
                placeholder="OneDrive Access Token"
                value={form.cloudStorage?.oneDriveAccessToken || ''}
                onChange={e =>
                  updateForm({
                    cloudStorage: { ...form.cloudStorage, oneDriveAccessToken: e.target.value }
                  })
                }
                className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
              {cloudStatus.onedrive && (
                <div
                  className={`text-[10px] font-semibold ${
                    cloudStatus.onedrive.ok ? 'text-teal-600' : 'text-rose-600'
                  }`}
                >
                  {cloudStatus.onedrive.msg}
                </div>
              )}
            </div>

            {/* Dropbox */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.cloudStorage?.dropboxEnabled || false}
                    onChange={e =>
                      updateForm({
                        cloudStorage: { ...form.cloudStorage, dropboxEnabled: e.target.checked }
                      })
                    }
                    className="rounded"
                  />
                  Dropbox Photo Backup
                </label>
                <button
                  type="button"
                  onClick={() => handleTestCloud('dropbox')}
                  disabled={cloudTesting === 'dropbox'}
                  className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition"
                >
                  {cloudTesting === 'dropbox' ? 'Testing...' : 'Test Connection'}
                </button>
              </div>
              <input
                type="text"
                placeholder="Dropbox Access Token"
                value={form.cloudStorage?.dropboxAccessToken || ''}
                onChange={e =>
                  updateForm({
                    cloudStorage: { ...form.cloudStorage, dropboxAccessToken: e.target.value }
                  })
                }
                className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
              {cloudStatus.dropbox && (
                <div
                  className={`text-[10px] font-semibold ${
                    cloudStatus.dropbox.ok ? 'text-teal-600' : 'text-rose-600'
                  }`}
                >
                  {cloudStatus.dropbox.msg}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Holiday Calendar & Computer Backup (Requirement 5) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Holidays */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-[#19243a]">Non-Working Holiday Calendar</h2>
          <div className="flex gap-2">
            <input
              type="date"
              value={newHolDate}
              onChange={e => setNewHolDate(e.target.value)}
              className="p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs"
            />
            <input
              type="text"
              placeholder="Reason e.g. Diwali"
              value={newHolName}
              onChange={e => setNewHolName(e.target.value)}
              className="flex-1 p-2 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs"
            />
            <button
              onClick={handleAddHoliday}
              className="px-3 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
            >
              Add
            </button>
          </div>
          <div className="divide-y divide-slate-100 max-h-40 overflow-y-auto">
            {dbState.holidays.map(h => (
              <div key={h.id} className="flex items-center justify-between py-2 text-xs">
                <div>
                  <strong className="text-slate-800">{h.date}</strong> · {h.name}
                </div>
                <button
                  onClick={() => deleteHoliday(h.id)}
                  className="text-rose-600 hover:text-rose-800 font-bold"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Computer Backup and Restore (Requirement 5) */}
        <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-[#19243a]">Computer Backup &amp; Restore</h2>
          <p className="text-xs text-[#78839a]">
            Export all customers, loans, inspections, settlements, and photos to a local file, or restore.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={handleExportBackup}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
            >
              ↓ Export Computer Backup
            </button>
            <label className="px-4 py-2.5 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer">
              ↑ Import Backup File
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleImportBackup}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
