import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Customer } from '../types';

interface CustomersProps {
  onOpenNewCustomer: () => void;
  onEditCustomer: (c: Customer) => void;
  onViewCustomer: (c: Customer) => void;
}

export const Customers: React.FC<CustomersProps> = ({
  onOpenNewCustomer,
  onEditCustomer,
  onViewCustomer
}) => {
  const { dbState, deleteCustomer } = useData();
  const [search, setSearch] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const query = search.toLowerCase().trim();
  const filtered = dbState.customers.filter(c =>
    [c.name, c.mobile, c.id, c.address, c.aadhaar, c.otherId, c.account, c.ifsc].some(val =>
      String(val || '').toLowerCase().includes(query)
    )
  );

  const handleDelete = async (c: Customer) => {
    const linkedCount = dbState.loans.filter(l => l.cid === c.id).length;
    const confirmMsg = linkedCount > 0
      ? `Delete customer "${c.name}"? This customer has ${linkedCount} linked loan(s). All linked loans will also be removed.`
      : `Delete customer "${c.name}"? This cannot be undone.`;

    if (window.confirm(confirmMsg)) {
      setDeletingId(c.id);
      try {
        await deleteCustomer(c.id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Customer Database
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Customers
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            One profile per borrower, with all gold loans and appraisal photos linked. ({filtered.length} customers)
          </p>
        </div>
        <button
          onClick={onOpenNewCustomer}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto cursor-pointer"
        >
          ＋ Add Customer
        </button>
      </div>

      {/* Search Toolbar */}
      <div className="relative">
        <input
          type="search"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search name, mobile, address, ID, account number..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#e7ebf2] rounded-xl text-xs text-[#19243a] placeholder-[#78839a] focus:outline-hidden focus:border-teal-500 shadow-xs"
        />
        <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm">
          🔍
        </span>
      </div>

      {/* Customer Table */}
      <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Mobile</th>
                <th className="py-3 px-4">Address</th>
                <th className="py-3 px-4">ID Number</th>
                <th className="py-3 px-4">Account No.</th>
                <th className="py-3 px-4 text-center">Loans</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length > 0 ? (
                filtered.map(c => {
                  const initials = c.name
                    .split(' ')
                    .map(x => x[0])
                    .join('')
                    .slice(0, 2)
                    .toUpperCase();
                  const loanCount = dbState.loans.filter(l => l.cid === c.id).length;

                  return (
                    <tr key={c.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 font-extrabold grid place-items-center text-xs shrink-0">
                            {initials || 'C'}
                          </div>
                          <div>
                            <strong className="block font-bold text-[#19243a] text-xs">
                              {c.name}
                            </strong>
                            <small className="text-[10px] text-[#78839a] font-medium">
                              {c.id}
                            </small>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        {c.mobile || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 max-w-[200px] truncate" title={c.address}>
                        {c.address || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {c.aadhaar || c.otherId || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {c.account || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span className="inline-block px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">
                          {loanCount}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onViewCustomer(c)}
                            className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                          >
                            View
                          </button>
                          <button
                            onClick={() => onEditCustomer(c)}
                            className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(c)}
                            disabled={deletingId === c.id}
                            className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg font-semibold text-[11px] transition cursor-pointer disabled:opacity-50"
                          >
                            {deletingId === c.id ? '...' : 'Delete'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#78839a]">
                    <div className="text-sm font-bold text-slate-700">
                      {search ? 'No customers match your search.' : 'No customers yet.'}
                    </div>
                    <div className="text-xs mt-1">
                      {search ? 'Try clearing or changing your search terms.' : 'Click "Add Customer" to register your first customer.'}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
