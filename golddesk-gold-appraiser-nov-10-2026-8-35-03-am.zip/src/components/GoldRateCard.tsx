import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import { renderPoster, inr } from '../lib/poster';
import { rateDate } from '../lib/core';
import { shareToWhatsApp, downloadFile } from '../lib/card';

export const GoldRateCard: React.FC = () => {
  const { dbState, saveSettings } = useData();
  const settings = dbState.settings;

  const [rate, setRate] = useState<number>(settings.rate || 0);
  const [agriPct, setAgriPct] = useState<number>(settings.agriPercent || 85);
  const [nonAgriPct, setNonAgriPct] = useState<number>(settings.nonAgriPercent || 68);
  const [loadingRate, setLoadingRate] = useState(false);
  const [fetchInfo, setFetchInfo] = useState<string>('');
  const [fetchError, setFetchError] = useState<string>('');
  const [posterBlob, setPosterBlob] = useState<Blob | null>(null);
  const [posterUrl, setPosterUrl] = useState<string>('');
  const [renderingPoster, setRenderingPoster] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const posterDateStr = rateDate(new Date());

  // Keep state in sync with settings when settings load
  useEffect(() => {
    if (settings.rate && !rate) setRate(settings.rate);
    if (settings.agriPercent) setAgriPct(settings.agriPercent);
    if (settings.nonAgriPercent) setNonAgriPct(settings.nonAgriPercent);
  }, [settings]);

  // Render poster whenever rate, percentages, or date change
  useEffect(() => {
    let active = true;

    const generatePoster = async () => {
      setRenderingPoster(true);
      try {
        const canvas = await renderPoster({
          date: posterDateStr,
          rate: rate || 0,
          agriPct: agriPct || 85,
          nonAgriPct: nonAgriPct || 68
        });

        if (!active) return;
        canvasRef.current = canvas;

        canvas.toBlob(blob => {
          if (!active || !blob) return;
          if (posterUrl) URL.revokeObjectURL(posterUrl);
          const url = URL.createObjectURL(blob);
          setPosterBlob(blob);
          setPosterUrl(url);
          setRenderingPoster(false);
        }, 'image/png');
      } catch (err: any) {
        if (!active) return;
        console.error('Poster rendering error:', err);
        setRenderingPoster(false);
      }
    };

    generatePoster();

    return () => {
      active = false;
    };
  }, [rate, agriPct, nonAgriPct, posterDateStr]);

  // Requirement 11: Fetch actual PNB gold rates from https://digigoldloan.pnb.bank.in/. Never invent rates.
  const handleRefreshFromPNB = async () => {
    setLoadingRate(true);
    setFetchError('');
    setFetchInfo('Fetching actual rates from https://digigoldloan.pnb.bank.in/ ...');

    try {
      const response = await fetch('/api/rates/pnb');
      const data = await response.json();

      if (!data.ok || !data.rate) {
        throw new Error(data.error || 'Could not parse gold rate from PNB');
      }

      const fetchedRate = Number(data.rate);
      setRate(fetchedRate);
      setAgriPct(data.agriPercent || 85);
      setNonAgriPct(data.nonAgriPercent || 68);

      const infoText = `Retrieved actual PNB 22K rate: ₹${fetchedRate.toLocaleString('en-IN')}/gm (source: ${data.sourceUrl}) on ${new Date(data.fetchedAt).toLocaleTimeString('en-IN')}`;
      setFetchInfo(infoText);

      // Persist to settings
      await saveSettings({
        rate: fetchedRate,
        agriPercent: data.agriPercent || 85,
        nonAgriPercent: data.nonAgriPercent || 68,
        rateFetchedAt: data.fetchedAt,
        rateVia: 'PNB Live Website Scraper',
        rateSavedFor: posterDateStr
      });
    } catch (err: any) {
      setFetchError(err.message || 'Failed to fetch live rate');
    } finally {
      setLoadingRate(false);
    }
  };

  const handleSaveRate = async () => {
    if (!(rate > 0)) {
      alert('Enter a valid market rate per gram.');
      return;
    }
    await saveSettings({
      rate,
      agriPercent: agriPct,
      nonAgriPercent: nonAgriPct,
      rateSavedFor: posterDateStr
    });
    alert('Gold rate and percentages saved successfully!');
  };

  const handleDownload = () => {
    if (!posterBlob) {
      alert('Generating poster, please wait a moment...');
      return;
    }
    downloadFile(posterBlob, `PNB-Gold-Loan-Rates-${posterDateStr}.png`);
  };

  // Requirement 6: Gold-rate posters must open the number saved in Settings.
  const handleShareToWhatsApp = async (chatOnly: boolean = false) => {
    if (!posterBlob) {
      alert('Generating poster, please wait...');
      return;
    }
    const settingsNumber = settings.rateWhatsapp;
    const formattedDate = posterDateStr.split('-').reverse().join('.');
    const caption = `PNB Gold Loan Rates ${formattedDate}\nMarket Rate: ₹${inr(rate)}/-\nAgri (85%): ₹${inr((rate * agriPct) / 100)}/-\nNon-Agri (68%): ₹${inr((rate * nonAgriPct) / 100)}/-`;

    try {
      await shareToWhatsApp(posterBlob, {
        filename: `PNB-Gold-Loan-Rates-${posterDateStr}.png`,
        text: caption,
        mobile: settingsNumber,
        title: 'PNB Gold Loan Rates Poster',
        chatOnly
      });
    } catch (err: any) {
      alert(`Sharing failed: ${err.message}`);
    }
  };

  const agriVal = Math.round((rate * agriPct) / 100);
  const nonAgriVal = Math.round((rate * nonAgriPct) / 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
          Daily Reference &amp; Poster
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
          Gold Rate Card &amp; Poster
        </h1>
        <p className="text-xs text-[#78839a] mt-0.5">
          Live 22K PNB gold rates fetched from <span className="font-semibold text-slate-700">https://digigoldloan.pnb.bank.in/</span>. Agri advance = 85%, Non-Agri advance = 68%.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Poster Live Preview */}
        <div className="lg:col-span-5 bg-white p-4 rounded-2xl border border-[#e7ebf2] shadow-sm flex flex-col items-center">
          <div className="relative w-full max-w-[360px] aspect-[1086/1448] bg-slate-100 rounded-xl overflow-hidden shadow-md border border-slate-200">
            {posterUrl ? (
              <img
                src={posterUrl}
                alt="PNB Gold Rate Poster"
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="w-full h-full grid place-items-center text-xs text-slate-400 font-bold">
                Rendering PNB Poster...
              </div>
            )}
            {renderingPoster && (
              <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-2xs grid place-items-center text-white text-xs font-bold">
                Updating live poster...
              </div>
            )}
          </div>
          <div className="text-[11px] text-[#78839a] font-medium mt-3 text-center">
            Poster Resolution: 1086 × 1448 px PNG (Lining Figures &amp; Tamil Font)
          </div>
        </div>

        {/* Right: Controls & Rates */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#e7ebf2]">
            <div>
              <h2 className="text-sm font-bold text-[#19243a]">Rate Details &amp; Calculations</h2>
              <p className="text-xs text-[#78839a]">
                Poster Date: <strong className="text-slate-800">{posterDateStr.split('-').reverse().join('.')}</strong> (rolls to next day after 7:00 PM)
              </p>
            </div>
            <button
              onClick={handleRefreshFromPNB}
              disabled={loadingRate}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer disabled:opacity-50"
            >
              <span>{loadingRate ? '⏳' : '↻'}</span> {loadingRate ? 'Fetching PNB...' : 'Refresh from PNB'}
            </button>
          </div>

          {/* Fetch Info Banner */}
          {fetchInfo && (
            <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-800 font-medium">
              {fetchInfo}
            </div>
          )}
          {fetchError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
              {fetchError}
            </div>
          )}

          {/* Market Rate Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">
              Market Rate per Gram (₹) — 22 Karat *
            </label>
            <div className="relative">
              <input
                type="number"
                min="0"
                step="1"
                value={rate || ''}
                onChange={e => setRate(Number(e.target.value))}
                placeholder="e.g. 12309"
                className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-sm font-bold text-[#19243a] focus:outline-hidden focus:border-teal-500"
              />
              <span className="absolute left-3 top-2.5 text-slate-400 font-bold text-sm">
                ₹
              </span>
            </div>
          </div>

          {/* Advance Percentages */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">
                Agri Advance (%)
              </label>
              <input
                type="number"
                min="1"
                max="100"
                step="0.1"
                value={agriPct}
                onChange={e => setAgriPct(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold text-[#19243a] focus:outline-hidden focus:border-teal-500"
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">
                Non-Agri Advance (%)
              </label>
              <input
                type="number"
                min="1"
                max="100"
                step="0.1"
                value={nonAgriPct}
                onChange={e => setNonAgriPct(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-bold text-[#19243a] focus:outline-hidden focus:border-teal-500"
              />
            </div>
          </div>

          {/* Computed Advance Values */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-xs font-bold text-slate-700">Agri Advance per Gram ({agriPct}%):</span>
              <span className="text-base font-extrabold text-[#19243a]">₹ {inr(agriVal)}/-</span>
            </div>
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-xs font-bold text-slate-700">Non-Agri Advance per Gram ({nonAgriPct}%):</span>
              <span className="text-base font-extrabold text-[#19243a]">₹ {inr(nonAgriVal)}/-</span>
            </div>
          </div>

          {/* Settings WhatsApp Target Info */}
          <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-center justify-between">
            <div>
              <span className="font-bold">Settings WhatsApp Target: </span>
              {settings.rateWhatsapp ? (
                <span className="font-semibold text-slate-800">{settings.rateWhatsapp}</span>
              ) : (
                <span className="italic text-amber-600">No number saved in Settings</span>
              )}
            </div>
          </div>

          {/* Action Buttons: Save, Download, WhatsApp (Requirement 6) */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={handleSaveRate}
              className="px-4 py-2.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
            >
              Save Rate
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-2.5 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
            >
              ↓ Download Image
            </button>
            <button
              onClick={() => handleShareToWhatsApp(false)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm flex items-center gap-1.5"
            >
              <span>💬</span> Share on WhatsApp
            </button>
            <button
              onClick={() => handleShareToWhatsApp(true)}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition cursor-pointer"
            >
              Open WhatsApp Chat
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
