import React, { useState } from 'react';
import { Payment } from '../../types';
import { useData } from '../../context/DataContext';
import { accounts, toISO } from '../../lib/core';

interface PaymentModalProps {
  acct: 'a2' | 'hA1' | 'hA2';
  payment?: Payment | null;
  presetAmount?: number;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  acct,
  payment,
  presetAmount,
  onClose
}) => {
  const { dbState, recordPayment } = useData();
  const settings = dbState.settings;

  const acctData = accounts(dbState);
  const accountSummary = acctData[acct];

  const todayStr = toISO(new Date());

  const [amount, setAmount] = useState<number>(
    payment ? payment.amount : presetAmount ? presetAmount : accountSummary.pending || 0
  );
  const [date, setDate] = useState<string>(payment ? payment.date : todayStr);
  const [note, setNote] = useState<string>(payment ? payment.note : '');
  const [allowOver, setAllowOver] = useState<boolean>(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const a1Name = settings.appraiser1Name || 'Appraiser 1';
  const a2Name = settings.appraiser2Name || 'Appraiser 2';
  const helperName = settings.helperName || 'Helper';

  const accountTitle =
    acct === 'a2'
      ? `${a2Name} (Appraiser 2)`
      : `${helperName} (Helper — borne by ${a1Name})`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!(amount > 0)) {
      setError('Enter an amount greater than zero');
      return;
    }

    // Room calculation
    const existingOwnAmount = payment ? payment.amount : 0;
    const room = accountSummary.accrued - (accountSummary.paid - existingOwnAmount);

    if (amount > room + 0.01 && !allowOver) {
      setError(
        `₹${Math.max(0, room).toLocaleString('en-IN')} is pending. To pay more as advance, check "Allow advance" and provide an explanatory note.`
      );
      return;
    }

    if (amount > room + 0.01 && !note.trim()) {
      setError('Please add a note explaining the payment above the pending balance.');
      return;
    }

    setSaving(true);
    setError('');

    try {
      await recordPayment({
        id: payment?.id,
        acct,
        amount: Number(amount),
        date,
        note: note.trim()
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to record payment');
    } finally {
      setSaving(false);
    }
  };

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">
              {payment ? 'Correct Settlement Payment' : 'Record Settlement Payment'}
            </h2>
            <p className="text-xs text-slate-500 font-medium">{accountTitle}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Current Balances Header */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex justify-between items-center">
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">Accrued</span>
            <strong className="text-slate-700">{formatMoney(accountSummary.accrued)}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">Paid</span>
            <strong className="text-slate-700">{formatMoney(accountSummary.paid)}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 font-bold uppercase">Pending</span>
            <strong className="text-rose-600 font-extrabold">{formatMoney(accountSummary.pending)}</strong>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Amount Actually Paid (₹) *
            </label>
            <input
              type="number"
              min="1"
              step="1"
              required
              value={amount || ''}
              onChange={e => setAmount(Number(e.target.value))}
              placeholder="e.g. 500"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-base text-[#19243a] focus:outline-hidden focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Payment Date *</label>
            <input
              type="date"
              required
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Note / Reference</label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="e.g. UPI transfer, Cash payout, Week 45"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <label className="flex items-start gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={allowOver}
              onChange={e => setAllowOver(e.target.checked)}
              className="mt-0.5 rounded"
            />
            <span className="text-[11px] text-slate-700">
              <strong className="block text-slate-900">Allow more than pending (Advance)</strong>
              Enable if making an advance payment exceeding current accrued balance.
            </span>
          </label>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Recording...' : payment ? 'Save Correction' : 'Record Payment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
