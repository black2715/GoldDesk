import React from 'react';
import { Customer, Loan } from '../../types';
import { useData } from '../../context/DataContext';
import { renewalState, toISO } from '../../lib/core';

interface CustomerViewModalProps {
  customer: Customer;
  onClose: () => void;
  onOpenLoan: (loan: Loan) => void;
}

export const CustomerViewModal: React.FC<CustomerViewModalProps> = ({
  customer,
  onClose,
  onOpenLoan
}) => {
  const { dbState } = useData();
  const linkedLoans = dbState.loans.filter(l => l.cid === customer.id);
  const todayStr = toISO(new Date());

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  // Collect photos linked to any of this customer's loans
  const loanIds = new Set(linkedLoans.map(l => l.id));
  const customerPhotos = dbState.photos.filter(p => p.loanId && loanIds.has(p.loanId));

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-[#19243a]">{customer.name}</h2>
            <p className="text-xs text-slate-500 font-medium">Customer ID: {customer.id}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Profile Details Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl text-xs">
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Mobile</span>
            <strong className="text-slate-800">{customer.mobile || '—'}</strong>
          </div>
          <div className="sm:col-span-2">
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Address</span>
            <strong className="text-slate-800">{customer.address || '—'}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Aadhaar</span>
            <strong className="text-slate-800">{customer.aadhaar || '—'}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Other ID</span>
            <strong className="text-slate-800">{customer.otherId || '—'}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Account Number</span>
            <strong className="text-slate-800">{customer.account || '—'}</strong>
          </div>
        </div>

        {/* Linked Loans Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Linked Gold Loans ({linkedLoans.length})
          </h3>
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold text-[10px] uppercase">
                <tr>
                  <th className="py-2.5 px-3">Ledger</th>
                  <th className="py-2.5 px-3">Amount</th>
                  <th className="py-2.5 px-3">Loan Date</th>
                  <th className="py-2.5 px-3">Renewal</th>
                  <th className="py-2.5 px-3">State</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {linkedLoans.length > 0 ? (
                  linkedLoans.map(l => (
                    <tr key={l.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-bold text-slate-900">{l.ledger}</td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">{formatMoney(l.amount)}</td>
                      <td className="py-2.5 px-3 text-slate-600">{formatDate(l.date)}</td>
                      <td className="py-2.5 px-3 text-slate-600">{formatDate(l.renewal || '')}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                          {renewalState(l, todayStr)}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => {
                            onClose();
                            onOpenLoan(l);
                          }}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px]"
                        >
                          Open Loan
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-4 text-center text-slate-400">
                      No loans linked to this borrower yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Uploaded Appraisal Photos Gallery */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Preserved Appraisal Photographs ({customerPhotos.length})
          </h3>
          {customerPhotos.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {customerPhotos.map(p => (
                <div key={p.id} className="group relative border border-slate-200 rounded-xl overflow-hidden bg-slate-50 aspect-square">
                  {p.dataUrl ? (
                    <img
                      src={p.dataUrl}
                      alt={p.type}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                  ) : (
                    <div className="w-full h-full grid place-items-center text-xs text-slate-400">
                      Cloud Photo
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 bg-slate-900/70 backdrop-blur-2xs p-1.5 text-white flex items-center justify-between text-[10px]">
                    <span className="capitalize truncate">{p.type}</span>
                    {p.dataUrl && (
                      <a
                        href={p.dataUrl}
                        download={`photo-${customer.name}-${p.type}.jpg`}
                        className="text-teal-300 hover:underline"
                        title="Download photo"
                      >
                        ↓
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              No photos attached to linked loans.
            </div>
          )}
        </div>

        <div className="flex justify-end pt-3 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
