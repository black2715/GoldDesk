import React, { useState } from 'react';
import { Loan } from '../../types';
import { useData } from '../../context/DataContext';
import { toISO, addDays } from '../../lib/core';

interface RenewalModalProps {
  loan: Loan;
  onClose: () => void;
}

export const RenewalModal: React.FC<RenewalModalProps> = ({ loan, onClose }) => {
  const { renewLoan, closeLoan } = useData();

  const todayStr = toISO(new Date());

  // Requirement 7: Renewal choices: Renew and Close only.
  const [action, setAction] = useState<'renew' | 'closed'>('renew');

  const [newLedger, setNewLedger] = useState('');
  const [newAmount, setNewAmount] = useState<number>(loan.amount);
  const [renewalDate, setRenewalDate] = useState(todayStr);
  const [nextRenewal, setNextRenewal] = useState(addDays(todayStr, 365));
  const [applyCharge, setApplyCharge] = useState(true);
  const [note, setNote] = useState('');

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      if (action === 'renew') {
        if (!newLedger.trim()) {
          throw new Error('Enter the new ledger / application number');
        }
        if (!(newAmount > 0)) {
          throw new Error('Enter a valid new loan amount');
        }

        await renewLoan(loan.id, {
          ledger: newLedger.trim(),
          amount: Number(newAmount),
          date: renewalDate,
          renewal: nextRenewal,
          applyCharge,
          note: note.trim()
        });
      } else {
        await closeLoan(loan.id, note.trim());
      }

      onClose();
    } catch (err: any) {
      setError(err.message || 'Action failed');
    } finally {
      setSaving(false);
    }
  };

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">
              Manage Loan Renewal
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Ledger: {loan.ledger} · Due Date: {formatDate(loan.renewal || '')}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Requirement 7: Renewal choices: Renew and Close only */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-700">
              Select Action (Renew or Close Only) *
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAction('renew')}
                className={`py-2.5 px-3 rounded-xl font-bold border transition text-center ${
                  action === 'renew'
                    ? 'bg-[#111b30] text-white border-[#111b30] shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                🔄 Renew Loan
              </button>
              <button
                type="button"
                onClick={() => setAction('closed')}
                className={`py-2.5 px-3 rounded-xl font-bold border transition text-center ${
                  action === 'closed'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                🔒 Close Loan
              </button>
            </div>
          </div>

          {action === 'renew' ? (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    New Ledger Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={newLedger}
                    onChange={e => setNewLedger(e.target.value)}
                    placeholder="e.g. GL-3042"
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold text-[#19243a]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    New Loan Amount (₹) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={newAmount}
                    onChange={e => setNewAmount(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-bold text-[#19243a]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Renewal Date (New Date)
                  </label>
                  <input
                    type="date"
                    required
                    value={renewalDate}
                    onChange={e => setRenewalDate(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Next Renewal Due Date
                  </label>
                  <input
                    type="date"
                    required
                    value={nextRenewal}
                    onChange={e => setNextRenewal(e.target.value)}
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg font-medium"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={applyCharge}
                  onChange={e => setApplyCharge(e.target.checked)}
                  className="rounded"
                />
                <span className="font-semibold text-slate-800">
                  Appraiser charge applies to this renewal (creates income &amp; helper settlement)
                </span>
              </label>

              <div className="text-[11px] text-slate-500 pt-1">
                Renewing archives the previous loan and creates the new linked loan for the same customer.
              </div>
            </div>
          ) : (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-2 text-rose-800">
              <strong className="block font-bold text-rose-900">Closing Gold Loan</strong>
              <p className="text-xs">
                This marks the loan as Closed Loan. It will be archived with its full history, and removed from the active renewals queue.
              </p>
            </div>
          )}

          <div>
            <label className="block font-bold text-slate-700 mb-1">Notes (Optional)</label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="e.g. Loan repaid in full, or renewal notes"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Processing...' : action === 'renew' ? 'Renew Loan' : 'Close Loan'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
