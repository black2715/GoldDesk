import React, { useState, useEffect } from 'react';
import { Inspection } from '../../types';
import { useData } from '../../context/DataContext';
import { inspectionCharge, toISO } from '../../lib/core';

interface InspectionModalProps {
  inspection?: Inspection | null;
  onClose: () => void;
}

export const InspectionModal: React.FC<InspectionModalProps> = ({
  inspection,
  onClose
}) => {
  const { dbState, saveInspection } = useData();
  const settings = dbState.settings;

  const [date, setDate] = useState(inspection?.date || toISO(new Date()));
  const [branch, setBranch] = useState(inspection?.branch || settings.branchName || '');
  const [packets, setPackets] = useState<number>(inspection?.packets || 1);
  const [rate, setRate] = useState<number>(
    inspection ? (inspection.rate ?? settings.packetRate ?? 100) : (settings.packetRate ?? 100)
  );
  const [charge, setCharge] = useState<number>(
    inspection?.charge ?? inspectionCharge(1, settings.packetRate ?? 100)
  );
  const [received, setReceived] = useState<number>(
    inspection?.received ?? inspectionCharge(1, settings.packetRate ?? 100)
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Dynamically update charge when packets or rate change
  useEffect(() => {
    const calc = inspectionCharge(packets, rate);
    setCharge(calc);
    if (!inspection) {
      setReceived(calc);
    }
  }, [packets, rate, inspection]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!branch.trim()) {
      setError('Enter branch name');
      return;
    }
    if (!(packets >= 1)) {
      setError('Packets must be 1 or more');
      return;
    }

    setSaving(true);
    setError('');

    try {
      await saveInspection({
        id: inspection?.id,
        date,
        branch: branch.trim(),
        packets: Number(packets),
        rate: Number(rate),
        charge: Number(charge),
        received: Number(received),
        createdAt: inspection?.createdAt
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save inspection');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">
              {inspection ? 'Edit Inspection' : 'Record Branch Inspection'}
            </h2>
            <p className="text-xs text-slate-500">
              Charge is calculated from packet rate setting.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Inspection Date</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Branch Name *</label>
            <input
              type="text"
              required
              value={branch}
              onChange={e => setBranch(e.target.value)}
              placeholder="e.g. Cuddalore Main Branch"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Gold Packets *</label>
              <input
                type="number"
                min="1"
                step="1"
                required
                value={packets}
                onChange={e => setPackets(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Rate per Packet (₹)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                required
                value={rate}
                onChange={e => setRate(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <span className="block text-[10px] text-slate-500 font-bold uppercase">
                Total Charge
              </span>
              <strong className="text-base font-extrabold text-[#19243a]">
                ₹{charge.toLocaleString('en-IN')}
              </strong>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-0.5">
                Received (₹)
              </label>
              <input
                type="number"
                value={received}
                onChange={e => setReceived(Number(e.target.value))}
                className="w-full p-1.5 bg-white border border-slate-200 rounded-lg font-bold text-teal-700 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Inspection'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
