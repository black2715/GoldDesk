import React from 'react';
import { Payment } from '../../types';

interface PaymentLogModalProps {
  payment: Payment;
  onClose: () => void;
}

export const PaymentLogModal: React.FC<PaymentLogModalProps> = ({ payment, onClose }) => {
  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">Payment Audit Log</h2>
            <p className="text-xs text-slate-500 font-medium">
              Payment ID: {payment.id} · Current: {formatMoney(payment.amount)} on {formatDate(payment.date)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3 max-h-72 overflow-y-auto text-xs">
          {payment.history && payment.history.length > 0 ? (
            payment.history.map((h, i) => (
              <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div className="flex items-center justify-between">
                  <strong className="font-bold text-slate-900">{h.action}</strong>
                  <span className="text-[10px] text-slate-400">
                    {new Date(h.at).toLocaleString('en-IN')}
                  </span>
                </div>
                {h.from ? (
                  <div className="text-[11px] text-slate-600">
                    <div>Changed from: {formatMoney(h.from.amount)} on {formatDate(h.from.date)} ({h.from.note || 'no note'})</div>
                    <div>Changed to: {formatMoney(h.to?.amount || 0)} on {formatDate(h.to?.date || '')} ({h.to?.note || 'no note'})</div>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-600">
                    {h.amount ? `Amount: ${formatMoney(h.amount)}` : ''} {h.date ? `· Date: ${formatDate(h.date)}` : ''}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-slate-400">
              No audit log entries for this payment.
            </div>
          )}
        </div>

        <div className="flex justify-end pt-3 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
