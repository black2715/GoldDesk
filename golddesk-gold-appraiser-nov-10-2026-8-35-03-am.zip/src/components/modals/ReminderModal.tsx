import React, { useState, useEffect, useRef } from 'react';
import { Loan, Customer } from '../../types';
import { useData } from '../../context/DataContext';
import { renderCard, shareToWhatsApp, downloadFile } from '../../lib/card';
import { TAMIL_NOTICE } from '../../lib/core';

interface ReminderModalProps {
  loan: Loan;
  onClose: () => void;
}

export const ReminderModal: React.FC<ReminderModalProps> = ({ loan, onClose }) => {
  const { dbState, saveSettings } = useData();
  const settings = dbState.settings;
  const rem = settings.reminder;

  const customer: Customer = dbState.customers.find(c => c.id === loan.cid) || {
    id: loan.cid,
    userId: '',
    name: 'Borrower',
    mobile: '',
    address: ''
  };

  const [refNo, setRefNo] = useState('');
  const [dueRow, setDueRow] = useState(rem.due !== false);
  const [grossRow, setGrossRow] = useState(rem.gross || false);
  const [nettRow, setNettRow] = useState(rem.nett || false);
  const [itemsRow, setItemsRow] = useState(rem.items || false);
  const [gross, setGross] = useState('');
  const [nett, setNett] = useState('');
  const [items, setItems] = useState('');
  const [fontScale, setFontScale] = useState(rem.fontScale || 1);
  const [notice, setNotice] = useState(rem.notice || TAMIL_NOTICE);

  const [cardBlob, setCardBlob] = useState<Blob | null>(null);
  const [cardUrl, setCardUrl] = useState<string>('');
  const [generating, setGenerating] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [shareMsg, setShareMsg] = useState('');

  // Render card preview whenever options change
  useEffect(() => {
    let active = true;

    const generate = async () => {
      setGenerating(true);
      try {
        const res = await renderCard({
          ref: refNo.trim(),
          name: customer.name,
          account: loan.ledger,
          amount: loan.amount,
          loanDate: loan.date,
          dueDate: loan.renewal || '',
          gross,
          nett,
          items,
          notice,
          branch: `${settings.branchName} ( ${settings.branchCode} )`,
          fontScale,
          rows: {
            due: dueRow,
            gross: grossRow,
            nett: nettRow,
            items: itemsRow
          }
        });

        if (!active) return;
        if (cardUrl) URL.revokeObjectURL(cardUrl);
        const url = URL.createObjectURL(res.blob);
        setCardBlob(res.blob);
        setCardUrl(url);
        setGenerating(false);
      } catch (err) {
        if (!active) return;
        console.error('Card render failed:', err);
        setGenerating(false);
      }
    };

    const timer = setTimeout(generate, 150);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [
    refNo,
    dueRow,
    grossRow,
    nettRow,
    itemsRow,
    gross,
    nett,
    items,
    fontScale,
    notice,
    loan,
    customer,
    settings
  ]);

  const handleDownload = () => {
    if (!cardBlob) {
      alert('Card is rendering, please wait...');
      return;
    }
    downloadFile(cardBlob, `renewal-${loan.ledger.replace(/[^\w-]/g, '_')}.png`);
  };

  // Requirement 6: Renewal reminders must open the customer's exact saved WhatsApp number.
  const handleShareToWhatsApp = async () => {
    if (!cardBlob) {
      alert('Card is rendering, please wait...');
      return;
    }
    setSharing(true);
    setShareMsg('');

    try {
      const result = await shareToWhatsApp(cardBlob, {
        filename: `renewal-${loan.ledger.replace(/[^\w-]/g, '_')}.png`,
        text: notice,
        mobile: customer.mobile,
        title: `PNB Gold Loan Reminder - ${loan.ledger}`
      });

      if (result === 'shared') {
        setShareMsg('Share sheet opened! Select customer chat in WhatsApp.');
      } else if (result === 'fallback') {
        setShareMsg(
          customer.mobile
            ? `Opened customer's WhatsApp chat (${customer.mobile}). Image downloaded / copied to clipboard.`
            : 'Image downloaded. (No mobile number was saved for this customer).'
        );
      }
    } catch (e: any) {
      setShareMsg(`Share failed: ${e.message}`);
    } finally {
      setSharing(false);
    }
  };

  const handleSaveDefaults = async () => {
    await saveSettings({
      reminder: {
        due: dueRow,
        gross: grossRow,
        nett: nettRow,
        items: itemsRow,
        fontScale,
        notice
      }
    });
    alert('Reminder card default options saved!');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full p-6 shadow-xl border border-slate-200 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">
              Renewal Reminder — PNB Borrower Card
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Ledger: <strong className="text-slate-800">{loan.ledger}</strong> · Customer: <strong className="text-slate-800">{customer.name}</strong> · WhatsApp:{' '}
              <strong className="text-emerald-700">{customer.mobile || 'No Mobile Saved'}</strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {shareMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-medium">
            {shareMsg}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          {/* Card Preview */}
          <div className="md:col-span-5 bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col items-center">
            <div className="relative w-full max-w-[320px] bg-white shadow-lg rounded overflow-hidden border border-slate-300">
              {cardUrl ? (
                <img
                  src={cardUrl}
                  alt="PNB Borrower Card Preview"
                  className="w-full h-auto block"
                />
              ) : (
                <div className="py-24 text-center text-xs text-slate-400 font-bold">
                  Rendering Borrower Card...
                </div>
              )}
              {generating && (
                <div className="absolute inset-0 bg-slate-900/20 backdrop-blur-2xs grid place-items-center text-xs font-bold text-slate-800">
                  Updating card...
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-500 mt-2 font-medium">
              High-resolution 1260 px PNG with Noto Sans Tamil typography
            </span>
          </div>

          {/* Options & Action Buttons */}
          <div className="md:col-span-7 space-y-4 text-xs">
            {/* Action Buttons (Requirement 6) */}
            <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleShareToWhatsApp}
                  disabled={sharing || !cardBlob}
                  className="flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>💬</span> Share on WhatsApp
                </button>
                <button
                  type="button"
                  onClick={handleDownload}
                  disabled={!cardBlob}
                  className="py-2.5 px-4 bg-white border border-emerald-300 hover:bg-emerald-50 text-emerald-800 rounded-xl font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
                >
                  ↓ Download Image
                </button>
              </div>
              <p className="text-[11px] text-emerald-900">
                Directly opens customer's exact saved WhatsApp number{' '}
                <strong className="underline">
                  {customer.mobile ? customer.mobile : '(No number saved)'}
                </strong>
                . Uses Web Share API or direct wa.me link with clipboard fallback.
              </p>
            </div>

            {/* Custom Options */}
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Reference No. (Optional)
                </label>
                <input
                  type="text"
                  value={refNo}
                  onChange={e => setRefNo(e.target.value)}
                  placeholder="e.g. REF-2026/04"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              {/* Row Toggles */}
              <div className="space-y-1">
                <span className="block font-bold text-slate-700">Display Rows on Card:</span>
                <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={dueRow}
                      onChange={e => setDueRow(e.target.checked)}
                      className="rounded"
                    />
                    <span>Due Date Row</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={grossRow}
                      onChange={e => setGrossRow(e.target.checked)}
                      className="rounded"
                    />
                    <span>Gross Weight</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={nettRow}
                      onChange={e => setNettRow(e.target.checked)}
                      className="rounded"
                    />
                    <span>Nett Weight</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={itemsRow}
                      onChange={e => setItemsRow(e.target.checked)}
                      className="rounded"
                    />
                    <span>No. of Items</span>
                  </label>
                </div>
              </div>

              {/* Weight & Item Inputs if toggled */}
              <div className="grid grid-cols-3 gap-2">
                {grossRow && (
                  <div>
                    <label className="block font-bold text-slate-700 mb-0.5">Gross Wt</label>
                    <input
                      type="text"
                      value={gross}
                      onChange={e => setGross(e.target.value)}
                      placeholder="e.g. 24.500 g"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                )}
                {nettRow && (
                  <div>
                    <label className="block font-bold text-slate-700 mb-0.5">Nett Wt</label>
                    <input
                      type="text"
                      value={nett}
                      onChange={e => setNett(e.target.value)}
                      placeholder="e.g. 22.100 g"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                )}
                {itemsRow && (
                  <div>
                    <label className="block font-bold text-slate-700 mb-0.5">Items</label>
                    <input
                      type="text"
                      value={items}
                      onChange={e => setItems(e.target.value)}
                      placeholder="e.g. 2 Bangles"
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                )}
              </div>

              {/* Font Scale */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">Card Font Size</label>
                <select
                  value={fontScale}
                  onChange={e => setFontScale(Number(e.target.value))}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value={0.85}>85% (Compact)</option>
                  <option value={1}>100% (Standard)</option>
                  <option value={1.15}>115% (Large)</option>
                </select>
              </div>

              {/* Tamil Notice Message */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Notice Message (Tamil / English)
                </label>
                <textarea
                  rows={4}
                  value={notice}
                  onChange={e => setNotice(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleSaveDefaults}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  Save as Default Layout
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
