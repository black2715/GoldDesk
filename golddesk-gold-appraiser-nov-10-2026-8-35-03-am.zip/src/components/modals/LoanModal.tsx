import React, { useState, useEffect } from 'react';
import { Customer } from '../../types';
import { useData } from '../../context/DataContext';
import { calcFee, toISO, addDays, isSunday } from '../../lib/core';

interface LoanModalProps {
  onClose: () => void;
}

export const LoanModal: React.FC<LoanModalProps> = ({ onClose }) => {
  const { dbState, saveCustomer, saveLoan } = useData();
  const settings = dbState.settings;

  const todayStr = toISO(new Date());
  const defaultRenewal = addDays(todayStr, 365);

  const [mode, setMode] = useState<'new' | 'existing'>('new');
  const [selectedCid, setSelectedCid] = useState('');
  const [custSearch, setCustSearch] = useState('');

  // New customer fields
  const [custName, setCustName] = useState('');
  const [custMobile, setCustMobile] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [custAadhaar, setCustAadhaar] = useState('');

  // Loan fields
  const [ledger, setLedger] = useState('');
  const [amount, setAmount] = useState<number>(100000);
  const [charge, setCharge] = useState<number>(settings.feeStandard || 500);
  const [date, setDate] = useState(todayStr);
  const [renewal, setRenewal] = useState(defaultRenewal);
  const [notes, setNotes] = useState('');

  const [goldFile, setGoldFile] = useState<File | null>(null);
  const [appFile, setAppFile] = useState<File | null>(null);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Calculate charge dynamically
  useEffect(() => {
    if (amount > 0) {
      setCharge(calcFee(amount, settings));
    }
  }, [amount, settings]);

  const existingMatches = dbState.customers.filter(c =>
    [c.name, c.mobile, c.id, c.aadhaar, c.account].some(v =>
      String(v || '').toLowerCase().includes(custSearch.toLowerCase())
    )
  );

  const isLoanSunday = isSunday(date);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ledger.trim()) {
      setError('Enter ledger / application number');
      return;
    }
    if (!(amount > 0)) {
      setError('Enter a valid loan amount');
      return;
    }

    let finalCid = selectedCid;

    setSaving(true);
    setError('');

    try {
      if (mode === 'new') {
        if (!custName.trim() || !custMobile.trim()) {
          throw new Error('Enter borrower name and mobile number');
        }
        const createdCust = await saveCustomer({
          name: custName,
          mobile: custMobile,
          address: custAddress,
          aadhaar: custAadhaar
        });
        finalCid = createdCust.id;
      } else {
        if (!finalCid) {
          throw new Error('Select an existing customer from the list');
        }
      }

      await saveLoan(
        {
          cid: finalCid,
          ledger: ledger.trim(),
          amount: Number(amount),
          charge: Number(charge),
          date,
          renewal,
          notes: notes.trim()
        },
        {
          gold: goldFile,
          app: appFile
        }
      );

      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save loan');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-xl border border-slate-200 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">Register Gold Loan</h2>
            <p className="text-xs text-slate-500">
              Registers appraisal charge and links photos. Settlement payments recorded in Settlement page.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Customer Selection Mode */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-700">Borrower Selection</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setMode('new')}
                className={`flex-1 py-2 rounded-xl font-bold border transition ${
                  mode === 'new'
                    ? 'bg-[#111b30] text-white border-[#111b30]'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                ＋ Add New Customer
              </button>
              <button
                type="button"
                onClick={() => setMode('existing')}
                className={`flex-1 py-2 rounded-xl font-bold border transition ${
                  mode === 'existing'
                    ? 'bg-[#111b30] text-white border-[#111b30]'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Choose Existing Customer
              </button>
            </div>
          </div>

          {/* New Customer Form */}
          {mode === 'new' ? (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    value={custName}
                    onChange={e => setCustName(e.target.value)}
                    placeholder="Full name"
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mobile *</label>
                  <input
                    type="tel"
                    required
                    value={custMobile}
                    onChange={e => setCustMobile(e.target.value)}
                    placeholder="10-digit mobile"
                    className="w-full p-2 bg-white border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Address</label>
                <input
                  type="text"
                  value={custAddress}
                  onChange={e => setCustAddress(e.target.value)}
                  placeholder="Address"
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg"
                />
              </div>
            </div>
          ) : (
            /* Existing Customer Picker */
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <input
                type="search"
                placeholder="Search existing customer by name, mobile, ID..."
                value={custSearch}
                onChange={e => setCustSearch(e.target.value)}
                className="w-full p-2 bg-white border border-slate-200 rounded-lg"
              />
              <div className="max-h-32 overflow-y-auto space-y-1">
                {existingMatches.map(c => (
                  <div
                    key={c.id}
                    onClick={() => setSelectedCid(c.id)}
                    className={`p-2 rounded-lg cursor-pointer flex justify-between items-center transition ${
                      selectedCid === c.id
                        ? 'bg-teal-600 text-white font-bold'
                        : 'bg-white hover:bg-slate-100 text-slate-800'
                    }`}
                  >
                    <div>
                      <span>{c.name}</span>
                      <small className="block text-[10px] opacity-80">{c.mobile} · {c.id}</small>
                    </div>
                    {selectedCid === c.id && <span>✓ Selected</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Loan Details Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Ledger / Application No. *
              </label>
              <input
                type="text"
                required
                value={ledger}
                onChange={e => setLedger(e.target.value)}
                placeholder="e.g. GL-10492"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-[#19243a]"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Loan Amount (₹) *</label>
              <input
                type="number"
                min="1"
                step="1"
                required
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-[#19243a]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Appraiser Charge (₹)
              </label>
              <input
                type="number"
                value={charge}
                onChange={e => setCharge(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-xl font-bold text-teal-700"
              />
              <small className="block text-[10px] text-slate-500 mt-1">
                Auto-calculated using fee rules
              </small>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Loan Date</label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
              />
              {isLoanSunday && (
                <small className="block text-[10px] text-amber-600 font-semibold mt-1">
                  Sunday: count in monthly/annual totals
                </small>
              )}
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Renewal Due Date</label>
            <input
              type="date"
              value={renewal}
              onChange={e => setRenewal(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            />
          </div>

          {/* Photo uploads (Requirement 4: never automatically deleted) */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Gold Photograph</label>
              <input
                type="file"
                accept="image/*"
                onChange={e => setGoldFile(e.target.files?.[0] || null)}
                className="text-xs w-full text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-[11px] file:font-semibold file:bg-slate-200 file:text-slate-700 hover:file:bg-slate-300"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Application Photo</label>
              <input
                type="file"
                accept="image/*"
                onChange={e => setAppFile(e.target.files?.[0] || null)}
                className="text-xs w-full text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-[11px] file:font-semibold file:bg-slate-200 file:text-slate-700 hover:file:bg-slate-300"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Notes (Optional)</label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Ornaments details, gross/net weight notes..."
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Gold Loan'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
