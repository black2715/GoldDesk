import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { toISO } from '../../lib/core';

interface ReceivableModalProps {
  onClose: () => void;
}

export const ReceivableModal: React.FC<ReceivableModalProps> = ({ onClose }) => {
  const { saveReceivable } = useData();

  const [amount, setAmount] = useState<number>(500);
  const [sourceDate, setSourceDate] = useState<string>(toISO(new Date()));
  const [description, setDescription] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!(amount > 0)) {
      setError('Enter a valid adjustment amount');
      return;
    }
    setSaving(true);
    setError('');

    try {
      await saveReceivable({
        amount: Number(amount),
        sourceDate,
        description: description.trim()
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save adjustment');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">Add Income Adjustment</h2>
            <p className="text-xs text-slate-500">
              The amount is deducted from the source date and tracked as pending receivable.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Amount to Mark Pending (₹) *
            </label>
            <input
              type="number"
              min="0.01"
              step="0.01"
              required
              value={amount || ''}
              onChange={e => setAmount(Number(e.target.value))}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-base text-[#19243a]"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Original Income Date *
            </label>
            <input
              type="date"
              required
              value={sourceDate}
              onChange={e => setSourceDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Reason / Reference
            </label>
            <input
              type="text"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="e.g. Loan GL-104 customer partial credit"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl font-bold cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Adjustment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
