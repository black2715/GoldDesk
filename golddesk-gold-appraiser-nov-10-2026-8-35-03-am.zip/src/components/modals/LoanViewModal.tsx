import React, { useState } from 'react';
import { Loan } from '../../types';
import { useData } from '../../context/DataContext';
import { splitCharge, renewalState, toISO } from '../../lib/core';

interface LoanViewModalProps {
  loan: Loan;
  onClose: () => void;
}

export const LoanViewModal: React.FC<LoanViewModalProps> = ({ loan, onClose }) => {
  const { dbState } = useData();
  const settings = dbState.settings;

  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const customer = dbState.customers.find(c => c.id === loan.cid) || {
    name: 'Unknown Customer',
    mobile: '—',
    address: '—'
  };

  const todayStr = toISO(new Date());
  const alloc = loan.alloc || splitCharge(loan.charge, settings);
  const state = renewalState(loan, todayStr);

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  // Attached photos
  const attachedPhotos = dbState.photos.filter(p =>
    (loan.imageIds || []).includes(p.id) || p.loanId === loan.id
  );

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#19243a]">Gold Loan: {loan.ledger}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                {state}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Borrower: {customer.name} · {customer.mobile}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 text-slate-500 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Loan Financial Specs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl text-xs">
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Loan Amount</span>
            <strong className="text-base font-extrabold text-[#19243a]">
              {formatMoney(loan.amount)}
            </strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Appraiser Charge</span>
            <strong className="text-base font-extrabold text-teal-600">
              {formatMoney(loan.charge)}
            </strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Loan Date</span>
            <strong className="text-slate-800">{formatDate(loan.date)}</strong>
          </div>
          <div>
            <span className="block text-[10px] text-slate-400 uppercase font-bold">Renewal Due</span>
            <strong className="text-slate-800">{formatDate(loan.renewal || '')}</strong>
          </div>
        </div>

        {/* Income Split Allocations (Requirement 8) */}
        <div className="p-4 bg-emerald-50/40 border border-emerald-200 rounded-xl text-xs space-y-2">
          <div className="font-bold text-emerald-950 flex justify-between items-center">
            <span>Income Split Calculation (100% Pool = {formatMoney(loan.charge)})</span>
            <span className="text-[10px] font-semibold text-emerald-700">
              Largest remainder integer rupee
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 pt-1 text-slate-800">
            <div className="p-2 bg-white rounded-lg border border-emerald-100">
              <span className="block text-[10px] text-slate-500">{settings.appraiser1Name} (37.5%)</span>
              <strong className="text-emerald-700 font-bold text-sm">
                {formatMoney(alloc.a1 || 0)}
              </strong>
            </div>
            <div className="p-2 bg-white rounded-lg border border-emerald-100">
              <span className="block text-[10px] text-slate-500">{settings.appraiser2Name} (37.5%)</span>
              <strong className="text-slate-800 font-bold text-sm">
                {formatMoney(alloc.a2)}
              </strong>
            </div>
            <div className="p-2 bg-white rounded-lg border border-emerald-100">
              <span className="block text-[10px] text-slate-500">{settings.helperName} (25%)</span>
              <strong className="text-amber-700 font-bold text-sm">
                {formatMoney(alloc.helper)}
              </strong>
            </div>
          </div>
          <small className="block text-[10px] text-slate-500">
            * Note: Helper's {formatMoney(alloc.helper)} is borne wholly by {settings.appraiser1Name}.
            Partial and full payouts are logged in the Settlement page.
          </small>
        </div>

        {/* Notes */}
        {loan.notes && (
          <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700">
            <span className="block font-bold text-slate-500 mb-0.5">Notes:</span>
            {loan.notes}
          </div>
        )}

        {/* Attached Photos (Requirement 4: never automatically deleted) */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Attached Appraisal Photos ({attachedPhotos.length})
          </h3>
          {attachedPhotos.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {attachedPhotos.map(p => (
                <div
                  key={p.id}
                  className="group relative border border-slate-200 rounded-xl overflow-hidden bg-slate-50 aspect-square"
                >
                  {p.dataUrl ? (
                    <img
                      src={p.dataUrl}
                      alt={p.type}
                      onClick={() => setSelectedPhoto(p.dataUrl || null)}
                      className="w-full h-full object-cover group-hover:scale-105 transition cursor-pointer"
                    />
                  ) : (
                    <div className="w-full h-full grid place-items-center text-xs text-slate-400">
                      Cloud Photo
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 bg-slate-900/70 backdrop-blur-2xs p-1.5 text-white flex items-center justify-between text-[10px]">
                    <span className="capitalize truncate font-medium">{p.type} Photo</span>
                    {p.dataUrl && (
                      <a
                        href={p.dataUrl}
                        download={`photo-${loan.ledger}-${p.type}.jpg`}
                        className="text-teal-300 hover:underline font-bold"
                        title="Download photo"
                      >
                        ↓ Download
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              No photos attached to this loan.
            </div>
          )}
        </div>

        {/* Enlarged Photo Modal if clicked */}
        {selectedPhoto && (
          <div
            className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-60"
            onClick={() => setSelectedPhoto(null)}
          >
            <div className="max-w-3xl max-h-[90vh] relative" onClick={e => e.stopPropagation()}>
              <img
                src={selectedPhoto}
                alt="Enlarged appraisal photo"
                className="max-w-full max-h-[85vh] rounded-xl object-contain shadow-2xl"
              />
              <button
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-2 right-2 px-3 py-1 bg-black/60 text-white rounded-lg text-xs font-bold"
              >
                Close ✕
              </button>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-3 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
