import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Inspection } from '../types';
import { inspectionCharge, inspectionBankPart, round2 } from '../lib/core';

interface InspectionProps {
  onOpenNewInspection: () => void;
  onEditInspection: (insp: Inspection) => void;
}

export const InspectionView: React.FC<InspectionProps> = ({
  onOpenNewInspection,
  onEditInspection
}) => {
  const { dbState, deleteInspection } = useData();
  const [search, setSearch] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const query = search.toLowerCase().trim();
  const filtered = dbState.inspections
    .filter(i =>
      [i.branch, i.date].some(val => String(val || '').toLowerCase().includes(query))
    )
    .sort((a, b) => b.date.localeCompare(a.date));

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  const handleDelete = async (i: Inspection) => {
    if (window.confirm(`Delete inspection record for branch "${i.branch}" on ${formatDate(i.date)}?`)) {
      setDeletingId(i.id);
      try {
        await deleteInspection(i.id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  const totalPackets = filtered.reduce((sum, i) => sum + i.packets, 0);
  const totalCharge = filtered.reduce((sum, i) => sum + i.charge, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Branch Audits
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Gold Packet Inspections
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Audit logs for gold packet branch inspections. Appraiser charge computed per packet rate.
          </p>
        </div>
        <button
          onClick={onOpenNewInspection}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto cursor-pointer"
        >
          ＋ Add Inspection
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Total Packets Inspected</div>
          <div className="text-2xl font-black text-[#19243a] mt-1">{totalPackets}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Total Inspection Charges</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">{formatMoney(totalCharge)}</div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Inspection Rate Setting</div>
          <div className="text-2xl font-black text-slate-700 mt-1">{formatMoney(dbState.settings.packetRate)}/packet</div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="relative">
        <input
          type="search"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search branch name, date..."
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#e7ebf2] rounded-xl text-xs text-[#19243a] placeholder-[#78839a] focus:outline-hidden focus:border-teal-500 shadow-xs"
        />
        <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm">
          🔍
        </span>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#e7ebf2] rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Date / Branch</th>
                <th className="py-3 px-4">Packets</th>
                <th className="py-3 px-4">Rate / Pkt</th>
                <th className="py-3 px-4">Gross Charge</th>
                <th className="py-3 px-4">Bank Share</th>
                <th className="py-3 px-4">Appraiser Net</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length > 0 ? (
                filtered.map(insp => {
                  const bankPart = inspectionBankPart(insp, dbState.settings);
                  const netPart = Math.max(0, round2(insp.charge - bankPart));

                  return (
                    <tr key={insp.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <strong className="block font-bold text-[#19243a] text-xs">
                          {formatDate(insp.date)}
                        </strong>
                        <small className="text-[10px] text-[#78839a] font-medium">
                          {insp.branch}
                        </small>
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-700">
                        {insp.packets}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {formatMoney(insp.rate)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">
                        {formatMoney(insp.charge)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {formatMoney(bankPart)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-emerald-600">
                        {formatMoney(netPart)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onEditInspection(insp)}
                            className="px-2.5 py-1 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-700 rounded-lg font-semibold text-[11px] transition cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(insp)}
                            disabled={deletingId === insp.id}
                            className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg font-semibold text-[11px] transition cursor-pointer disabled:opacity-50"
                          >
                            {deletingId === insp.id ? '...' : 'Delete'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#78839a]">
                    <div className="text-sm font-bold text-slate-700">
                      {search ? 'No inspection records match your search.' : 'No branch inspections recorded yet.'}
                    </div>
                    <div className="text-xs mt-1">
                      Click "Add Inspection" to record an inspection.
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
