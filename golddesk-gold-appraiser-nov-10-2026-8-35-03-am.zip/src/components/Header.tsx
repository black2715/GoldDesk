import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

interface HeaderProps {
  currentTab: string;
  onOpenMobileMenu: () => void;
}

const TAB_TITLES: Record<string, string> = {
  dashboard: 'Dashboard',
  customers: 'Customers',
  loans: 'Gold Loans',
  inspection: 'Inspection',
  settlements: 'Settlement',
  renewals: 'Renewals',
  rates: 'Gold Rate Card',
  analytics: 'Analytics & Reports',
  settings: 'Settings'
};

export const Header: React.FC<HeaderProps> = ({ currentTab, onOpenMobileMenu }) => {
  const { user, login, logout } = useAuth();
  const { online } = useData();

  const todayStr = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  return (
    <header className="top flex items-center justify-between px-4 sm:px-8 bg-white/90 backdrop-blur-md border-b border-[#e7ebf2] sticky top-0 z-20 h-16 sm:h-[72px]">
      <div className="flex items-center gap-3">
        <button
          className="lg:hidden w-10 h-10 border border-[#e7ebf2] bg-white rounded-xl grid place-items-center text-lg text-[#19243a] hover:bg-gray-50"
          onClick={onOpenMobileMenu}
          aria-label="Open navigation menu"
        >
          ☰
        </button>
        <div className="crumb text-xs text-[#78839a]">
          GoldDesk <span className="text-[#19243a] font-bold text-sm ml-1">/ {TAB_TITLES[currentTab] || 'Dashboard'}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* Sync/Online pill */}
        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-[#e7ebf2] bg-white text-[#68748b]">
          <span className={`w-2 h-2 rounded-full ${online ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          {online ? 'Real-time Sync Active' : 'Offline Mode (Local)'}
        </div>

        {/* Date */}
        <div className="hidden md:block date border border-[#e7ebf2] rounded-xl bg-white px-3 py-1.5 text-xs text-[#68748b] font-medium">
          {todayStr}
        </div>

        {/* Google User Profile */}
        {user ? (
          <div className="flex items-center gap-2 pl-2 border-l border-[#e7ebf2]">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-8 h-8 rounded-full border border-[#e7ebf2]"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-[#111b30] text-white text-xs font-bold grid place-items-center">
                {(user.displayName || user.email || 'A').slice(0, 1).toUpperCase()}
              </div>
            )}
            <button
              onClick={() => logout()}
              className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 rounded hover:bg-rose-50"
              title="Sign out of Google"
            >
              Sign out
            </button>
          </div>
        ) : (
          <button
            onClick={() => login()}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            Google Sign In
          </button>
        )}
      </div>
    </header>
  );
};
