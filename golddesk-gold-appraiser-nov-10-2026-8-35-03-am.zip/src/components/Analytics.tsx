import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import {
  bounds,
  incomeEvents,
  series,
  totals,
  within,
  toISO,
  parseISO,
  weekBounds,
  addDays,
  splitCharge,
  inspectionA1Income,
  balance,
  payStatus,
  accounts
} from '../lib/core';

interface AnalyticsProps {
  onOpenReceivableModal: () => void;
}

export const Analytics: React.FC<AnalyticsProps> = ({ onOpenReceivableModal }) => {
  const { dbState, exportJsonBackup } = useData();
  const settings = dbState.settings;

  const a1Name = settings.appraiser1Name || 'Appraiser 1';
  const a2Name = settings.appraiser2Name || 'Appraiser 2';
  const helperName = settings.helperName || 'Helper';

  const todayStr = toISO(new Date());
  const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'year'>('month');
  const [refDate, setRefDate] = useState<string>(todayStr);
  const [historySearch, setHistorySearch] = useState<string>('');

  const [a, b] = bounds(period, refDate);
  const allEvents = incomeEvents(dbState);
  const periodEvents = allEvents
    .filter(e => within(e.date, a, b))
    .sort((x, y) => y.date.localeCompare(x.date));

  const periodIncomeTotal = periodEvents.reduce((sum, e) => sum + e.amount, 0);
  const chartSeries = series(dbState, period === 'day' ? 'week' : period, refDate);
  const maxBarValue = Math.max(1, ...chartSeries.map(s => Math.abs(s.value)));

  const t = totals(dbState, todayStr);
  const acct = accounts(dbState);

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  // Transactions list for financial history tree
  const getTransactions = () => {
    const list: Array<{
      date: string;
      type: string;
      ref: string;
      who: string;
      gross: number;
      a1?: number;
      a2?: number;
      h?: number;
      recv?: number;
      due?: number;
      st?: string;
    }> = [];

    const getCustomerName = (cid: string) =>
      dbState.customers.find(c => c.id === cid)?.name || 'Unknown Borrower';

    dbState.loans.forEach(x => {
      const p = splitCharge(x.charge, settings);
      list.push({
        date: x.date,
        type: 'Loan charge',
        ref: x.ledger,
        who: getCustomerName(x.cid),
        gross: p.charge,
        a1: p.a1,
        a2: p.a2,
        h: p.helper,
        recv: x.received || 0,
        due: balance(x),
        st: payStatus(x)
      });
    });

    dbState.inspections.forEach(x => {
      list.push({
        date: x.date,
        type: 'Inspection',
        ref: x.branch,
        who: '',
        gross: x.charge,
        a1: inspectionA1Income(x, settings),
        recv: x.received || 0,
        due: balance(x),
        st: payStatus(x)
      });
    });

    dbState.payments
      .filter(p => p.status !== 'reversed')
      .forEach(p => {
        list.push({
          date: p.date,
          type: 'Settlement payment',
          ref: p.acct === 'a2' ? a2Name : helperName,
          who: p.note || '',
          gross: p.amount,
          st: 'Paid'
        });
      });

    (dbState.receivables || []).forEach(r => {
      list.push({
        date: r.sourceDate,
        type: 'Income adjustment',
        ref: r.description || r.id,
        who: '',
        gross: -Number(r.amount || 0),
        st: ''
      });
      (r.payments || []).forEach(p => {
        list.push({
          date: p.date,
          type: 'Adjustment received',
          ref: r.description || r.id,
          who: '',
          gross: Number(p.amount || 0),
          st: 'Paid'
        });
      });
    });

    return list.sort((x, y) => y.date.localeCompare(x.date));
  };

  const q = historySearch.toLowerCase().trim();
  const filteredTxns = getTransactions().filter(x =>
    !q || [x.type, x.ref, x.who, x.st, x.date, formatDate(x.date)].join(' ').toLowerCase().includes(q)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Performance &amp; Ledger
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            Analytics &amp; Reports
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Actual income by calendar period, pending receivables, and settlement figures.
          </p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={onOpenReceivableModal}
            className="px-3 py-2 bg-white border border-[#e7ebf2] hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
          >
            ＋ Income Adjustment
          </button>
          <button
            onClick={async () => {
              const data = await exportJsonBackup();
              const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `golddesk-backup-${todayStr}.json`;
              a.click();
              a.remove();
            }}
            className="px-3.5 py-2 bg-[#111b30] hover:bg-[#1d2c49] text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
          >
            ↓ Export Backup
          </button>
        </div>
      </div>

      {/* Summary 4-Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Income this Week</div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1">{formatMoney(t.week)}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Income this Month</div>
          <div className="text-xl sm:text-2xl font-black text-teal-600 mt-1">{formatMoney(t.month)}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Income this Year</div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1">{formatMoney(t.year)}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-[#e7ebf2] shadow-xs">
          <div className="text-[11px] font-bold text-[#78839a]">Average Monthly Income</div>
          <div className="text-xl sm:text-2xl font-black text-indigo-600 mt-1">{formatMoney(t.avgMonthly)}</div>
        </div>
      </div>

      {/* Period Analysis Card */}
      <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e7ebf2]">
          <div>
            <h2 className="text-sm font-bold text-[#19243a]">Period Analysis</h2>
            <p className="text-xs text-[#78839a]">
              Day · Week (Mon–Sat) · Month (Calendar) · Year (Jan–Dec)
            </p>
          </div>
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700">
            {a === b ? formatDate(a) : `${formatDate(a)} – ${formatDate(b)}`}
          </span>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700">Period Type</label>
            <select
              value={period}
              onChange={e => setPeriod(e.target.value as any)}
              className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-semibold focus:outline-hidden focus:border-teal-500"
            >
              <option value="day">Daily</option>
              <option value="week">Weekly (Mon–Sat)</option>
              <option value="month">Monthly</option>
              <option value="year">Yearly</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700">Reference Date</label>
            <input
              type="date"
              value={refDate}
              onChange={e => setRefDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs font-semibold focus:outline-hidden focus:border-teal-500"
            >
            </input>
          </div>
        </div>

        {/* Selected Period Total */}
        <div className="flex items-baseline gap-3 pt-2">
          <div className="text-xs font-bold text-[#78839a]">{a1Name} — Actual Income:</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-teal-600">
            {formatMoney(periodIncomeTotal)}
          </div>
        </div>

        {/* Bar Chart */}
        <div className="h-44 flex items-end gap-2 pt-6 pb-2 border-b border-[#e7ebf2]">
          {chartSeries.map((item, idx) => {
            const barHeight = Math.max(4, (Math.abs(item.value) / maxBarValue) * 120);
            return (
              <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full group">
                <span className="text-[10px] font-bold text-slate-600 mb-1 opacity-0 group-hover:opacity-100 transition whitespace-nowrap">
                  {item.value ? formatMoney(item.value) : ''}
                </span>
                <div
                  style={{ height: `${barHeight}px` }}
                  className={`w-full max-w-[40px] rounded-t-md transition-all duration-300 ${
                    item.value > 0
                      ? 'bg-gradient-to-t from-teal-600 to-teal-400'
                      : 'bg-slate-100'
                  }`}
                  title={`${item.label} (${item.key}): ${formatMoney(item.value)}`}
                />
              </div>
            );
          })}
        </div>

        <div className="flex justify-between text-[11px] font-semibold text-slate-500 overflow-x-auto">
          {chartSeries.map((item, idx) => (
            <div key={idx} className="flex-1 text-center min-w-[24px]">
              {item.label}
            </div>
          ))}
        </div>
      </div>

      {/* Receivables & Shares Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Receivables */}
        <div className="bg-white p-5 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-[#19243a]">Receivables (Pending Receipts)</h2>
          <div className="divide-y divide-slate-100 text-xs">
            <div className="flex justify-between py-2">
              <span className="text-slate-600">Loan charges pending</span>
              <span className="font-bold text-slate-800">{formatMoney(t.pendLoans)}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-600">Inspection pending</span>
              <span className="font-bold text-slate-800">{formatMoney(t.pendInsp)}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-600">Adjustments pending</span>
              <span className="font-bold text-slate-800">{formatMoney(t.pendRec)}</span>
            </div>
            <div className="flex justify-between py-2 font-bold text-slate-900 border-t border-slate-200">
              <span>Total pending to receive</span>
              <span className="text-rose-600 font-extrabold">{formatMoney(t.pendingToReceive)}</span>
            </div>
          </div>
        </div>

        {/* Shares & Settlements */}
        <div className="bg-white p-5 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-3">
          <h2 className="text-sm font-bold text-[#19243a]">Income Shares (Loan Pool)</h2>
          <div className="divide-y divide-slate-100 text-xs">
            <div className="flex justify-between py-2">
              <span className="text-slate-600">Total loan charges (100% pool)</span>
              <span className="font-bold text-slate-800">{formatMoney(t.loanPool)}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-600">{a2Name} share (37.5%)</span>
              <span className="font-bold text-slate-800">{formatMoney(t.a2Share)}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-600">{helperName} allocation (25%)</span>
              <span className="font-bold text-slate-800">{formatMoney(t.helperAllocation)}</span>
            </div>
            <div className="flex justify-between py-2 font-bold text-slate-900 border-t border-slate-200">
              <span>Helper pending ({a1Name} unpaid share)</span>
              <span className="text-amber-700 font-extrabold">{formatMoney(t.helperPending)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Financial History Transactions Tree */}
      <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-[#19243a]">Financial Audit &amp; Transactions History</h2>
            <p className="text-xs text-[#78839a]">
              Complete chronological ledger of all loan charges, inspections, and settlements.
            </p>
          </div>
          <div className="relative min-w-[220px]">
            <input
              type="search"
              value={historySearch}
              onChange={e => setHistorySearch(e.target.value)}
              placeholder="Search history..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-[#e7ebf2] rounded-xl text-xs focus:outline-hidden focus:border-teal-500"
            />
            <span className="absolute left-2.5 top-1.5 text-slate-400 text-xs">
              🔍
            </span>
          </div>
        </div>

        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-[#e7ebf2] text-[#78839a] font-bold uppercase text-[10px] tracking-wider sticky top-0">
              <tr>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Reference / Person</th>
                <th className="py-2.5 px-3 text-right">Gross Amount</th>
                <th className="py-2.5 px-3 text-right">{a1Name} Net</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTxns.length > 0 ? (
                filteredTxns.map((tx, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition">
                    <td className="py-2.5 px-3 font-medium text-slate-700">
                      {formatDate(tx.date)}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {tx.type}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      <span className="font-bold text-slate-800">{tx.ref}</span>
                      {tx.who ? ` · ${tx.who}` : ''}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-800">
                      {formatMoney(tx.gross)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-teal-600">
                      {tx.a1 != null ? formatMoney(tx.a1) : '—'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {tx.st || '—'}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No transactions match the search filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
