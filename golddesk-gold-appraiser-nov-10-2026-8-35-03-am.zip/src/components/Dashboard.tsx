import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import {
  totals,
  series,
  weekBounds,
  addDays,
  toISO,
  accounts
} from '../lib/core';

interface DashboardProps {
  onNavigate: (tab: string) => void;
  onOpenNewLoan: () => void;
  onOpenNewCustomer: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  onNavigate,
  onOpenNewLoan,
  onOpenNewCustomer
}) => {
  const { dbState } = useData();
  const [weekOffset, setWeekOffset] = useState(0);

  const todayStr = toISO(new Date());
  const t = totals(dbState, todayStr);
  const acct = accounts(dbState);

  const refDate = addDays(todayStr, weekOffset * 7);
  const weekSeries = series(dbState, 'week', refDate).filter(x => !x.sunday);
  const [w0, w1] = weekBounds(refDate);

  const formatMoney = (n: number) =>
    '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

  const formatDate = (iso: string) => (iso ? iso.split('-').reverse().join('/') : '—');

  const a1Name = dbState.settings.appraiser1Name || 'Appraiser 1';
  const a2Name = dbState.settings.appraiser2Name || 'Appraiser 2';
  const helperName = dbState.settings.helperName || 'Helper';

  const weekIncomeTotal = weekSeries.reduce((sum, item) => sum + item.value, 0);
  const maxBarValue = Math.max(1, ...weekSeries.map(s => Math.abs(s.value)));

  const shortcuts = [
    { label: 'Add Gold Loan', icon: '＋', color: 'bg-blue-50 text-blue-600', action: onOpenNewLoan },
    { label: 'Add Customer', icon: '♙', color: 'bg-indigo-50 text-indigo-600', action: onOpenNewCustomer },
    { label: 'Inspection', icon: '◇', color: 'bg-emerald-50 text-emerald-600', action: () => onNavigate('inspection') },
    { label: 'Settlement', icon: '⇄', color: 'bg-rose-50 text-rose-600', action: () => onNavigate('settlements') },
    { label: 'Gold Rate Poster', icon: '₹', color: 'bg-amber-50 text-amber-600', action: () => onNavigate('rates') },
    { label: 'Loan Renewal', icon: '◷', color: 'bg-purple-50 text-purple-600', action: () => onNavigate('renewals') }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome & Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold text-teal-600 tracking-wider uppercase">
            Financial Overview
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#19243a] tracking-tight mt-1">
            GoldDesk Dashboard
          </h1>
          <p className="text-xs text-[#78839a] mt-0.5">
            Real-time appraisal charges, settlements, and PNB rate operations
          </p>
        </div>
      </div>

      {/* Quick Access Grid */}
      <div className="space-y-2">
        <div className="text-[11px] font-bold text-[#78839a] tracking-wider uppercase">
          Quick Access
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {shortcuts.map((sc, i) => (
            <button
              key={i}
              onClick={sc.action}
              className="flex flex-col items-center gap-2.5 p-3.5 bg-white border border-[#e7ebf2] rounded-2xl font-bold text-xs text-[#19243a] hover:shadow-md hover:-translate-y-0.5 transition duration-150 group text-center cursor-pointer"
            >
              <span className={`w-10 h-10 rounded-xl grid place-items-center text-lg font-black ${sc.color} group-hover:scale-105 transition`}>
                {sc.icon}
              </span>
              <span className="truncate w-full">{sc.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Hero Financial Metrics (Requirement 10) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Appraiser 1 Monthly Income */}
        <div className="lg:col-span-5 bg-gradient-to-br from-[#111b30] to-[#1c2e50] text-white p-6 rounded-2xl shadow-sm border border-slate-800 relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 tracking-wide">
                {a1Name} — Monthly Income
              </span>
              <span className="w-9 h-9 rounded-xl bg-white/10 text-emerald-300 grid place-items-center font-bold text-base">
                ₹
              </span>
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-4">
              {formatMoney(t.month)}
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-700/60 text-[11px] text-slate-400 flex items-center justify-between">
            <span>
              {new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' })}
            </span>
            <span className="text-emerald-400 font-semibold">Calendar Month</span>
          </div>
        </div>

        {/* Pending Amounts: Appraiser 2 and Helper */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Appraiser 2 Pending */}
          <div className="bg-white p-5 rounded-2xl border border-[#e7ebf2] shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#78839a]">
                {a2Name} — Total Pending
              </span>
              <button
                onClick={() => onNavigate('settlements')}
                className="text-xs font-bold px-2.5 py-1 bg-rose-50 text-rose-600 rounded-lg hover:bg-rose-100 transition"
              >
                Settle
              </button>
            </div>
            <div className="text-2xl font-black text-[#19243a] mt-3">
              {formatMoney(t.a2Unpaid)}
            </div>
            <div className="mt-3 pt-2 border-t border-slate-100 text-[10px] text-[#78839a]">
              Accrued: {formatMoney(acct.a2.accrued)} · Paid: {formatMoney(acct.a2.paid)}
            </div>
          </div>

          {/* Helper Pending */}
          <div className="bg-white p-5 rounded-2xl border border-[#e7ebf2] shadow-sm flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#78839a]">
                {helperName} — Total Pending
              </span>
              <button
                onClick={() => onNavigate('settlements')}
                className="text-xs font-bold px-2.5 py-1 bg-amber-50 text-amber-700 rounded-lg hover:bg-amber-100 transition"
              >
                Settle
              </button>
            </div>
            <div className="text-2xl font-black text-[#19243a] mt-3">
              {formatMoney(t.helperPending)}
            </div>
            <div className="mt-3 pt-2 border-t border-slate-100 text-[10px] text-amber-700 font-medium">
              Borne wholly by {a1Name} · Accrued {formatMoney(acct.hA1.accrued)}
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Analytics Chart (Monday - Saturday) */}
      <div className="bg-white p-6 rounded-2xl border border-[#e7ebf2] shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-base font-bold text-[#19243a]">Weekly Income</h2>
            <p className="text-xs text-[#78839a]">
              {a1Name} · Monday – Saturday · <span className="font-semibold text-slate-700">{formatDate(w0)} – {formatDate(addDays(w0, 5))}</span>
            </p>
          </div>
          <div className="flex items-center gap-1.5 self-start sm:self-auto">
            <button
              onClick={() => setWeekOffset(w => w - 1)}
              className="px-2.5 py-1.5 border border-[#e7ebf2] bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
              title="Previous week"
            >
              ‹ Prev
            </button>
            <button
              onClick={() => setWeekOffset(0)}
              className={`px-3 py-1.5 border border-[#e7ebf2] rounded-lg text-xs font-bold transition ${
                weekOffset === 0 ? 'bg-slate-900 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              This week
            </button>
            <button
              onClick={() => setWeekOffset(w => w + 1)}
              className="px-2.5 py-1.5 border border-[#e7ebf2] bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
              title="Next week"
            >
              Next ›
            </button>
          </div>
        </div>

        <div className="flex items-baseline gap-3 mb-4">
          <div className="text-xs font-bold text-[#78839a]">Week Total:</div>
          <div className="text-2xl font-black text-emerald-600">
            {formatMoney(weekIncomeTotal)}
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="h-44 flex items-end gap-3 pt-6 pb-2 border-b border-[#e7ebf2]">
          {weekSeries.map((item, idx) => {
            const barHeight = Math.max(6, (Math.abs(item.value) / maxBarValue) * 120);
            return (
              <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full group">
                <span className="text-[10px] font-bold text-slate-600 mb-1 opacity-0 group-hover:opacity-100 transition whitespace-nowrap">
                  {item.value ? formatMoney(item.value) : ''}
                </span>
                <div
                  style={{ height: `${barHeight}px` }}
                  className={`w-full max-w-[48px] rounded-t-lg transition-all duration-300 ${
                    item.value > 0
                      ? 'bg-gradient-to-t from-teal-600 to-teal-400 group-hover:brightness-110'
                      : 'bg-slate-100'
                  }`}
                  title={`${item.label} (${item.key}): ${formatMoney(item.value)}`}
                />
              </div>
            );
          })}
        </div>

        <div className="flex justify-between mt-2 text-xs font-semibold text-slate-500">
          {weekSeries.map((item, idx) => (
            <div key={idx} className="flex-1 text-center">
              {item.label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
