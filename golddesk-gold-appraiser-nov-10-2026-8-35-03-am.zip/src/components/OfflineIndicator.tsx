import React from 'react';
import { useData } from '../context/DataContext';

export const OfflineIndicator: React.FC = () => {
  const { online } = useData();

  if (online) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-bold text-white shadow-xl border border-amber-400 animate-in fade-in slide-in-from-bottom-2">
      <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
      <span>Offline Mode — Changes saved locally &amp; will sync when reconnected</span>
    </div>
  );
};
