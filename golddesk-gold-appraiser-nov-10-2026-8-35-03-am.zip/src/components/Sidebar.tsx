import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { accounts, renewalList, renewalState, toISO } from '../lib/core';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose
}) => {
  const { user } = useAuth();
  const { dbState, online } = useData();
  const settings = dbState.settings;

  const todayStr = toISO(new Date());
  const acctSummary = accounts(dbState);
  const pendingAccountsCount = [acctSummary.a2, acctSummary.hA1].filter(x => x.pending > 0).length;
  const activeRenewals = renewalList(dbState, todayStr).filter(
    x => renewalState(x, todayStr) !== 'Upcoming'
  ).length;

  const appraiserName = settings.appraiser1Name || 'Appraiser';
  const initial = appraiserName.charAt(0).toUpperCase();

  const handleNav = (tab: string) => {
    onSelectTab(tab);
    onClose();
  };

  const navClass = (tab: string) =>
    `w-full flex items-center justify-between px-3 py-2.5 rounded-xl font-bold text-xs transition text-left ${
      currentTab === tab
        ? 'bg-[#1d2c49] text-white shadow-sm'
        : 'text-slate-300 hover:bg-[#1d2c49]/60 hover:text-white'
    }`;

  return (
    <>
      {/* Overlay for mobile drawer */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-[#111b30] text-white flex flex-col justify-between z-40 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div>
          {/* Brand header */}
          <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-800">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black text-xl grid place-items-center shadow-md">
              G
            </div>
            <div>
              <strong className="block text-base tracking-tight font-extrabold text-white">
                GoldDesk
              </strong>
              <small className="block text-[10px] text-slate-400 font-medium">
                Gold Appraiser Management
              </small>
            </div>
          </div>

          {/* Work Navigation */}
          <div className="px-3 py-4 space-y-1">
            <button className={navClass('dashboard')} onClick={() => handleNav('dashboard')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">▦</span> Dashboard
              </span>
            </button>
            <button className={navClass('customers')} onClick={() => handleNav('customers')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">♙</span> Customers
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {dbState.customers.length}
              </span>
            </button>
            <button className={navClass('loans')} onClick={() => handleNav('loans')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">▤</span> Gold Loans
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {dbState.loans.length}
              </span>
            </button>
            <button className={navClass('inspection')} onClick={() => handleNav('inspection')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">◇</span> Inspection
              </span>
            </button>
            <button className={navClass('settlements')} onClick={() => handleNav('settlements')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">⇄</span> Settlement
              </span>
              {pendingAccountsCount > 0 && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {pendingAccountsCount} due
                </span>
              )}
            </button>
            <button className={navClass('renewals')} onClick={() => handleNav('renewals')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">◷</span> Renewals
              </span>
              {activeRenewals > 0 && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500 text-white font-bold">
                  {activeRenewals}
                </span>
              )}
            </button>
            <button className={navClass('rates')} onClick={() => handleNav('rates')}>
              <span className="flex items-center gap-2.5">
                <span className="text-base">✧</span> Gold Rate Card
              </span>
              <span className="text-[10px] text-amber-400 font-bold">22K PNB</span>
            </button>
          </div>

          {/* Manage Navigation */}
          <div className="px-3 pt-2">
            <div className="px-3 pb-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Manage
            </div>
            <div className="space-y-1">
              <button className={navClass('analytics')} onClick={() => handleNav('analytics')}>
                <span className="flex items-center gap-2.5">
                  <span className="text-base">▥</span> Analytics &amp; Reports
                </span>
              </button>
              <button className={navClass('settings')} onClick={() => handleNav('settings')}>
                <span className="flex items-center gap-2.5">
                  <span className="text-base">⚙</span> Settings
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer profile & sync indicator */}
        <div className="p-4 border-t border-slate-800/80 bg-[#0e1628]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 grid place-items-center font-bold text-sm">
              {initial}
            </div>
            <div className="min-w-0 flex-1">
              <strong className="block text-xs font-bold truncate text-white">
                {appraiserName}
              </strong>
              <small className="flex items-center gap-1.5 text-[10px] text-slate-400">
                <span className={`w-2 h-2 rounded-full ${online ? 'bg-teal-400' : 'bg-amber-400'}`} />
                {online ? 'Synced · Realtime' : 'Offline Storage'}
              </small>
            </div>
          </div>
          {user?.email && (
            <div className="mt-2 text-[10px] text-slate-500 truncate" title={user.email}>
              {user.email}
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
