export interface Customer {
  id: string;
  userId: string;
  name: string;
  mobile: string;
  address: string;
  aadhaar?: string;
  otherId?: string;
  account?: string;
  ifsc?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface LoanAllocation {
  charge: number;
  a1?: number;
  a2: number;
  helper: number;
  payA1: number;
  payA2: number;
}

export interface LoanRenewalHistoryEntry {
  date: string;
  previousDate?: string;
  action: string;
  note?: string;
}

export interface Loan {
  id: string;
  userId: string;
  cid: string;
  ledger: string;
  amount: number;
  charge: number;
  received?: number;
  date: string;
  renewal?: string;
  renewalStatus?: 'Active' | 'Renewed' | 'Closed Loan' | 'Sent off / completed';
  renewedFrom?: string;
  renewedTo?: string;
  imageIds?: string[];
  previousImageIds?: string[];
  notes?: string;
  alloc?: LoanAllocation;
  renewalHistory?: LoanRenewalHistoryEntry[];
  receipts?: Array<{ id: string; date: string; amount: number; note?: string }>;
  createdAt?: string;
  updatedAt?: string;
}

export interface Inspection {
  id: string;
  userId: string;
  date: string;
  branch: string;
  packets: number;
  rate: number;
  charge: number;
  received: number;
  receipts?: Array<{ id: string; date: string; amount: number }>;
  createdAt?: string;
  updatedAt?: string;
}

export interface PaymentHistoryEntry {
  at: string;
  action: string;
  amount?: number;
  date?: string;
  from?: { amount: number; date: string; note: string };
  to?: { amount: number; date: string; note: string };
  previousDate?: string;
  previousAmount?: number;
  reason?: string;
}

export interface Payment {
  id: string;
  userId: string;
  acct: 'a2' | 'hA1' | 'hA2';
  date: string;
  amount: number;
  note: string;
  status: 'active' | 'reversed';
  createdAt: string;
  updatedAt: string;
  history: PaymentHistoryEntry[];
}

export interface Settlement {
  id: string;
  userId: string;
  loanId: string;
  ledger: string;
  cid: string;
  date: string;
  helperAllocation: number;
  payableA1: number;
  payableA2: number;
  status: 'paid' | 'unpaid';
  paidDate?: string;
  paidAmount?: number;
  a2Amount?: number;
  a2Status?: 'paid' | 'unpaid';
  a2PaidDate?: string;
  a2PaidAmount?: number;
  history?: any[];
  a2History?: any[];
  createdAt?: string;
  updatedAt?: string;
}

export interface Receivable {
  id: string;
  userId: string;
  sourceDate: string;
  amount: number;
  description: string;
  paid: number;
  payments: Array<{ id: string; amount: number; date: string; reference?: string }>;
  createdAt?: string;
  updatedAt?: string;
}

export interface Holiday {
  id: string;
  userId: string;
  date: string;
  name: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface CloudStorageConfig {
  googleDriveEnabled?: boolean;
  googleDriveAccessToken?: string;
  googleDriveFolderId?: string;
  googleDriveAccountName?: string;

  oneDriveEnabled?: boolean;
  oneDriveAccessToken?: string;
  oneDriveAccountName?: string;

  dropboxEnabled?: boolean;
  dropboxAccessToken?: string;
  dropboxAccountName?: string;
}

export interface AppSettings {
  appraiser1Name: string;
  appraiser2Name: string;
  helperName: string;
  split1: number;
  split2: number;
  splitHelper: number;
  bankMode: 'percent' | 'fixed';
  bankShareValue: number;
  feeMode: 'fixed' | 'percent';
  feeStandard: number;
  feeHigh: number;
  feeThreshold: number;
  feePercent: number;
  feeMin: number;
  feeMax: number;
  packetRate: number;
  reminderDays: number;
  rateWhatsapp: string;
  rateProxy: string;
  rateFetchedAt: string;
  rateVia: string;
  agriPercent: number;
  nonAgriPercent: number;
  rate: number;
  rateSavedFor: string;
  branchName: string;
  branchCode: string;
  reminder: {
    gross: boolean;
    nett: boolean;
    items: boolean;
    due: boolean;
    fontScale: number;
    notice: string;
  };
  cloudStorage?: CloudStorageConfig;
  updatedAt?: string;
}

export interface PhotoRecord {
  id: string;
  userId: string;
  loanId?: string;
  ledger?: string;
  type: string;
  dataUrl?: string;
  storageProvider: 'local' | 'firestore' | 'gdrive' | 'onedrive' | 'dropbox';
  cloudUrl?: string;
  filename?: string;
  createdAt: string;
}

export interface DatabaseState {
  schema: number;
  customers: Customer[];
  loans: Loan[];
  inspections: Inspection[];
  payments: Payment[];
  settlements: Settlement[];
  receivables: Receivable[];
  holidays: Holiday[];
  settings: AppSettings;
  photos: PhotoRecord[];
  audit?: Array<{ at: string; coll: string; id: string; action: string; summary: string }>;
}
