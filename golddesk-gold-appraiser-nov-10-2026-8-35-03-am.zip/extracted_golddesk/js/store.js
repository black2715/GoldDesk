/* GoldDesk Professional — local-first store.
   Records live in IndexedDB on the device (works offline) and, when the user signs in to a server,
   are synchronised through the REST API in /backend. Images are stored as separate blobs. */
(function (root) {
  'use strict';
  const C = root.GDCore;
  const listeners = new Set();
  const S = { db: C.emptyDB(), ready: false, sync: { url: '', token: '', email: '', cursor: 0, last: '', conflicts: [], status: 'local' }, tomb: [], storageError: '' };
  let idb = null, saveTimer = null, urlCache = {};
  const COLL = ['customers', 'loans', 'inspections', 'settlements', 'receivables', 'holidays', 'a2payments', 'payments'];

  /* ---------- IndexedDB helpers ---------- */
  const open = () => new Promise((res, rej) => {
    if (!root.indexedDB) return rej(new Error('This browser does not support local database storage.'));
    const r = indexedDB.open('GoldDeskPro', 1);
    r.onupgradeneeded = () => { const d = r.result; ['kv', 'images'].forEach(n => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n); }); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const tx = (store, mode, fn) => new Promise((res, rej) => { const t = idb.transaction(store, mode), q = fn(t.objectStore(store)); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
  const kvGet = k => tx('kv', 'readonly', s => s.get(k));
  const kvSet = (k, v) => tx('kv', 'readwrite', s => s.put(v, k));
  const emit = () => listeners.forEach(f => { try { f(); } catch (e) { console.error(e); } });

  async function save() {
    try {
      await kvSet('db', JSON.parse(JSON.stringify(S.db))); await kvSet('tomb', S.tomb); await kvSet('sync', S.sync); S.storageError = '';
    } catch (e) { S.storageError = 'Could not save on this device: ' + (e && e.message || e) + '. Export a backup now.'; console.error(e); }
    emit();
  }
  const saveSoon = () => { clearTimeout(saveTimer); saveTimer = setTimeout(save, 120); };
  const flush = async () => { clearTimeout(saveTimer); await save(); };

  /* ---------- Mutation API ---------- */
  const nowISO = () => new Date().toISOString();
  function audit(coll, id, action, summary) {
    S.db.audit.push({ at: nowISO(), coll, id, action, summary: summary || '' });
    if (S.db.audit.length > 3000) S.db.audit.splice(0, S.db.audit.length - 3000); // full history is kept on the server
  }
  function touch(coll, rec, action, summary) {
    const t = nowISO(); if (!rec.createdAt) rec.createdAt = t; rec.updatedAt = t;
    audit(coll, rec.id, action || 'Updated', summary);
  }
  // Run a mutation, then reconcile derived records (helper settlements), then persist.
  function commit(fn) {
    const r = fn(S.db);
    const t = nowISO();
    C.ensureSettlements(S.db, t).forEach(s => { s.updatedAt = t; });
    saveSoon(); emit(); scheduleSync();
    return r;
  }
  function remove(coll, id, summary) {
    const i = S.db[coll].findIndex(x => x.id === id); if (i < 0) return;
    const [rec] = S.db[coll].splice(i, 1); S.tomb.push({ coll, id, version: rec.version || 0, at: nowISO() }); audit(coll, id, 'Deleted', summary);
    saveSoon(); emit(); scheduleSync();
  }
  const subscribe = f => { listeners.add(f); return () => listeners.delete(f); };

  /* ---------- Images ---------- */
  async function compress(file, max) {
    max = max || 1600;
    const bmp = await createImageBitmap(file).catch(() => null);
    if (!bmp) throw new Error('This file is not a readable image.');
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas');
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('Image could not be processed.')), 'image/jpeg', 0.88));
  }
  async function addImage(file) {
    const blob = await compress(file), id = 'img-' + C.uid('').slice(1);
    await tx('images', 'readwrite', s => s.put({ blob, type: blob.type, at: nowISO(), uploaded: false }, id));
    return id;
  }
  async function imageRecord(id) { return tx('images', 'readonly', s => s.get(id)); }
  async function imageURL(id) {
    if (urlCache[id]) return urlCache[id];
    let rec = await imageRecord(id);
    if (!rec && S.sync.token) { // fetch from server on demand
      try { const r = await api('GET', '/api/files/' + encodeURIComponent(id), null, true); if (r.ok) { const blob = await r.blob(); rec = { blob, type: blob.type, uploaded: true, at: nowISO() }; await tx('images', 'readwrite', s => s.put(rec, id)); } } catch (e) { /* offline */ }
    }
    if (!rec) return '';
    return (urlCache[id] = URL.createObjectURL(rec.blob));
  }
  const blobToDataURL = b => new Promise(res => { const f = new FileReader(); f.onload = () => res(f.result); f.onerror = () => res(''); f.readAsDataURL(b); });
  const dataURLToBlob = u => { const [h, d] = u.split(','), t = (h.match(/:(.*?);/) || [])[1] || 'image/jpeg', bin = atob(d), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: t }); };
  const referencedImageIds = db => new Set([].concat(...db.loans.map(l => [].concat(l.imageIds || [], l.previousImageIds || []))));

  /* ---------- Backup ---------- */
  async function exportAll() {
    const images = {};
    for (const id of referencedImageIds(S.db)) { const r = await imageRecord(id); if (r) images[id] = await blobToDataURL(r.blob); }
    return C.exportBackup(S.db, images, { storage: 'device' });
  }
  // Replace everything with a validated backup. A safety copy of the current data is kept first.
  async function importValidated(v) {
    const safety = await exportAll(); await kvSet('preImportBackup', safety);
    S.db = v.db; S.tomb = []; urlCache = {};
    await tx('images', 'readwrite', s => s.clear());
    for (const [id, url] of Object.entries(v.images || {})) { try { await tx('images', 'readwrite', s => s.put({ blob: dataURLToBlob(url), type: 'image/jpeg', at: nowISO(), uploaded: false }, id)); } catch (e) { console.warn('image skipped', id); } }
    const t = nowISO(); COLL.forEach(c => S.db[c].forEach(r => { r.updatedAt = t; r.createdAt = r.createdAt || t; delete r.syncedAt; r.version = 0; }));
    if (S.sync.token) S.sync.replaceNext = true;
    audit('system', 'import', 'Backup imported', S.db.loans.length + ' loans, ' + S.db.customers.length + ' customers');
    await flush(); emit(); scheduleSync();
  }
  async function restorePreImport() { const b = await kvGet('preImportBackup'); if (!b) throw new Error('No earlier copy is available.'); const v = C.validateBackup(b); if (!v.ok) throw new Error(v.errors.join(' ')); await importValidated(v); }

  /* ---------- Server sync ---------- */
  async function api(method, path, body, raw) {
    const h = {}; if (S.sync.token) h.Authorization = 'Bearer ' + S.sync.token;
    let b = body; if (body && !raw && !(body instanceof Blob)) { h['Content-Type'] = 'application/json'; b = JSON.stringify(body); } else if (body instanceof Blob) h['Content-Type'] = body.type || 'application/octet-stream';
    const r = await fetch((S.sync.url || '') + path, { method, headers: h, body: method === 'GET' ? undefined : b });
    if (raw) return r;
    const j = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error(j.error || ('Server error ' + r.status)); e.status = r.status; throw e; }
    return j;
  }
  const recKey = (c, id) => c + '/' + id;
  function allRecords() {
    const out = []; COLL.forEach(c => S.db[c].forEach(r => out.push([c, r]))); out.push(['settings', Object.assign({ id: 'main' }, S.db.settings, { updatedAt: S.db.settingsUpdatedAt || '' })]); return out;
  }
  const strip = r => { const d = Object.assign({}, r); delete d.syncedAt; delete d.version; return d; };
  async function login(url, email, password, register) {
    S.sync.url = (url || '').replace(/\/+$/, ''); const r = await api('POST', '/api/auth/' + (register ? 'register' : 'login'), { email, password });
    Object.assign(S.sync, { token: r.token, email: r.user.email, status: 'signed-in' }); await flush(); return syncNow();
  }
  async function logout() { Object.assign(S.sync, { token: '', status: 'local' }); await flush(); emit(); }
  let syncing = false, syncTimer = null;
  function scheduleSync() { if (!S.sync.token) return; clearTimeout(syncTimer); syncTimer = setTimeout(() => syncNow().catch(() => {}), 1500); }
  async function syncNow() {
    if (!S.sync.token) throw new Error('Sign in to a server first.');
    if (syncing) return; syncing = true; S.sync.status = 'syncing'; emit();
    try {
      // 1) push local changes
      const changes = [], replace = !!S.sync.replaceNext;
      allRecords().forEach(([c, r]) => { if (replace || (c === 'settings' ? (S.db.settingsUpdatedAt && S.db.settingsUpdatedAt > (S.sync.settingsSyncedAt || '')) : (!r.syncedAt || r.updatedAt > r.syncedAt))) changes.push({ coll: c, id: r.id, baseVersion: c === 'settings' ? (S.sync.settingsVersion || 0) : (r.version || 0), data: strip(r) }); });
      S.tomb.forEach(t => changes.push({ coll: t.coll, id: t.id, baseVersion: t.version, deleted: true }));
      if (changes.length) {
        const res = await api('POST', '/api/sync/push', replace ? { changes, replace: true } : { changes });
        if (replace) { S.sync.replaceNext = false; S.sync.cursor = 0; }
        const stamp = nowISO();
        res.results.forEach(x => {
          if (x.status === 'ok') {
            if (x.coll === 'settings') { S.sync.settingsVersion = x.version; S.sync.settingsSyncedAt = stamp; }
            else { const r = (S.db[x.coll] || []).find(z => z.id === x.id); if (r) { r.version = x.version; r.syncedAt = stamp; } }
            S.tomb = S.tomb.filter(t => !(t.coll === x.coll && t.id === x.id));
          } else if (x.status === 'conflict') {
            const local = x.coll === 'settings' ? S.db.settings : (S.db[x.coll] || []).find(z => z.id === x.id);
            S.sync.conflicts.push({ coll: x.coll, id: x.id, at: stamp, local: local ? JSON.parse(JSON.stringify(local)) : null, server: x.server });
            applyRemote(x.coll, x.id, x.server); // server copy wins by default; the local copy is kept in Conflicts
          }
        });
      }
      // 2) pull remote changes
      const pull = await api('GET', '/api/sync/pull?since=' + (S.sync.cursor || 0));
      pull.records.forEach(x => { if (x.seq > (S.sync.cursor || 0)) { const loc = x.coll === 'settings' ? null : (S.db[x.coll] || []).find(z => z.id === x.id); if (!(loc && loc.updatedAt > (loc.syncedAt || '') && (loc.version || 0) >= x.version)) applyRemote(x.coll, x.id, x); } });
      S.sync.cursor = pull.cursor;
      // 3) upload images that have not reached the server
      for (const id of referencedImageIds(S.db)) { const rec = await imageRecord(id); if (rec && !rec.uploaded) { const r = await api('PUT', '/api/files/' + encodeURIComponent(id), rec.blob, true); if (r.ok) { rec.uploaded = true; await tx('images', 'readwrite', s => s.put(rec, id)); } } }
      S.sync.last = nowISO(); S.sync.status = 'synced'; C.ensureSettlements(S.db, nowISO()); await flush();
    } catch (e) { S.sync.status = e.status === 401 ? 'signed-out' : 'error'; if (e.status === 401) S.sync.token = ''; S.sync.error = e.message; await flush(); throw e; }
    finally { syncing = false; emit(); }
  }
  function applyRemote(coll, id, x) {
    if (!x) return; const t = nowISO();
    if (coll === 'settings') { if (!x.deleted) { S.db.settings = C.mergeSettings(x.data); S.sync.settingsVersion = x.version; S.sync.settingsSyncedAt = t; S.db.settingsUpdatedAt = x.data.updatedAt || t; } return; }
    const list = S.db[coll]; if (!list) return; const i = list.findIndex(z => z.id === id);
    if (x.deleted) { if (i >= 0) list.splice(i, 1); return; }
    const rec = Object.assign({}, x.data, { version: x.version, syncedAt: t });
    if (i >= 0) list[i] = rec; else list.push(rec);
  }
  async function resolveConflict(i, useMine) {
    const c = S.sync.conflicts[i]; if (!c) return;
    if (useMine && c.local) { const list = S.db[c.coll]; if (c.coll === 'settings') { S.db.settings = C.mergeSettings(c.local); S.db.settingsUpdatedAt = nowISO(); } else { const r = Object.assign({}, c.local, { version: c.server ? c.server.version : 0, updatedAt: nowISO() }); delete r.syncedAt; const k = list.findIndex(z => z.id === c.id); if (k >= 0) list[k] = r; else list.push(r); audit(c.coll, c.id, 'Conflict resolved', 'Kept this device\u2019s version'); } }
    S.sync.conflicts.splice(i, 1); await flush(); scheduleSync();
  }
  async function serverHistory(coll, id) { return api('GET', '/api/audit?coll=' + encodeURIComponent(coll) + '&id=' + encodeURIComponent(id)); }
  function touchSettings() { S.db.settingsUpdatedAt = nowISO(); audit('settings', 'main', 'Settings changed'); saveSoon(); emit(); scheduleSync(); }

  /* ---------- Startup ---------- */
  async function init() {
    idb = await open();
    let db = await kvGet('db'), legacyMigrated = false;
    if (!db) { // one-time migration from the earlier single-file GoldDesk
      const old = await new Promise(res => { const r = indexedDB.open('GoldDeskRecords'); r.onupgradeneeded = () => { r.transaction.abort(); res(null); }; r.onerror = () => res(null); r.onsuccess = () => { const d = r.result; if (!d.objectStoreNames.contains('state')) { d.close(); return res(null); } const g = d.transaction('state').objectStore('state').get('current'); g.onsuccess = () => { d.close(); res(g.result || null); }; g.onerror = () => { d.close(); res(null); }; }; });
      if (old && (old.L || old.C)) { const m = C.validateBackup(old); if (m.ok) { db = m.db; for (const [id, u] of Object.entries(m.images || {})) await tx('images', 'readwrite', s => s.put({ blob: dataURLToBlob(u), type: 'image/jpeg', at: nowISO(), uploaded: false }, id)); legacyMigrated = true; } }
    }
    S.db = db ? Object.assign(C.emptyDB(), db, { settings: C.mergeSettings(db.settings) }) : C.emptyDB();
    S.db.loans.forEach(l => { l.imageIds = l.imageIds || []; l.receipts = l.receipts || []; l.renewalHistory = l.renewalHistory || []; l.renewalStatus = C.normalizeRenewalStatus(l.renewalStatus); });
    S.tomb = (await kvGet('tomb')) || []; Object.assign(S.sync, (await kvGet('sync')) || {}, { status: 'local' }); if (S.sync.token) S.sync.status = 'signed-in';
    C.ensureSettlements(S.db, nowISO()); S.ready = true; if (legacyMigrated) { audit('system', 'migrate', 'Migrated earlier GoldDesk data'); await flush(); }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    emit(); if (S.sync.token) syncNow().catch(() => {});
    addEventListener('online', () => scheduleSync());
  }
  async function wipeAll() { await tx('images', 'readwrite', s => s.clear()); S.db = C.emptyDB(); S.tomb = []; urlCache = {}; await flush(); }

  root.GDStore = { state: S, init, commit, touch, remove, audit, subscribe, flush, addImage, imageURL, imageRecord, exportAll, importValidated, restorePreImport, login, logout, syncNow, resolveConflict, serverHistory, touchSettings, wipeAll, dataURLToBlob, blobToDataURL };
})(window);
