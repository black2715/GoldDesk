/* GoldDesk Professional — record pages: customers, loans, inspection, settlements, renewals, gold rate. */
(function (root) {
  'use strict';
  const C = root.GDCore, St = root.GDStore, GD = root.GD, db = () => St.state.db;
  const { $, esc, money, today, fmt, N, sc, set } = GD;
  const F = GD.forms = {};
  const row = (id, ph, extra) => `<div class="field search"><input id="${id}" placeholder="${ph}" ${extra || ''}></div>`;
  const empty = (t, s) => `<div class="empty"><b>${t}</b>${s || ''}</div>`;
  const custName = id => GD.cust(id).name;
  const val = id => ($(id).value || '').trim();
  const needSunday = d => C.isISO(d) && C.isSunday(d) ? 'Sunday is not a working day. The record is still saved, but it counts only in monthly and yearly totals.' : '';
  const sundayHint = (inp, hint) => { const f = () => { $(hint).textContent = needSunday($(inp).value); }; $(inp).addEventListener('input', f); f(); };

  /* ================= CUSTOMERS ================= */
  GD.pages.customers = {
    mount() {
      $('page-customers').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Customer database</div><h1>Customers</h1><p>One profile per customer, with every loan linked to it. <span id="custCount"></span></p></div><button class="btn primary" id="addCust">＋ Add customer</button></div>
<div class="toolbar">${row('custSearch', 'Search name, mobile, address, ID, account…', 'type="search"')}</div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Customer</th><th>Mobile</th><th>Address</th><th>ID</th><th>Account no.</th><th>Loans</th><th></th></tr></thead><tbody id="custBody"></tbody></table></div></div>`;
      $('addCust').onclick = () => F.customer(); $('custSearch').addEventListener('input', () => this.render());
      $('custBody').addEventListener('click', e => { const d = e.target.closest('[data-del]'); if (d) return F.deleteCustomer(d.dataset.del); const b = e.target.closest('[data-v],[data-e]'); if (b) b.dataset.v ? F.customerView(b.dataset.v) : F.customer(b.dataset.e); });
    },
    render() {
      const q = val('custSearch').toLowerCase(), D = db(), a = D.customers.filter(c => [c.name, c.mobile, c.id, c.address, c.aadhaar, c.otherId, c.account, c.ifsc].some(v => String(v || '').toLowerCase().includes(q)));
      set('custCount', a.length + ' customer' + (a.length === 1 ? '' : 's'));
      $('custBody').innerHTML = a.map(c => `<tr><td><div class="person"><div class="mini">${esc(c.name.split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase())}</div><div><strong>${esc(c.name)}</strong><small>${esc(c.id)}</small></div></div></td><td>${esc(c.mobile || '—')}</td><td>${esc(c.address || '—')}</td><td>${esc(c.aadhaar || c.otherId || '—')}</td><td>${esc(c.account || '—')}</td><td>${D.loans.filter(l => l.cid === c.id).length}</td><td><div class="rowact"><button class="btn small" data-v="${c.id}">View profile</button><button class="btn small" data-e="${c.id}">Edit</button><button class="btn small danger" data-del="${c.id}">Delete</button></div></td></tr>`).join('') || `<tr><td colspan="7">${empty(q ? 'No customers match' : 'No customers yet', q ? 'Try a different search.' : 'Add a customer or register a loan.')}</td></tr>`;
    }
  };
  const custFields = (c, p) => `<div class="formgrid"><div class="field"><label for="${p}Name">Full name *</label><input id="${p}Name" value="${esc(c.name || '')}"></div><div class="field"><label for="${p}Mobile">Mobile number *</label><input id="${p}Mobile" inputmode="numeric" value="${esc(c.mobile || '')}"></div><div class="field full"><label for="${p}Address">Full address *</label><textarea id="${p}Address" rows="2">${esc(c.address || '')}</textarea></div><div class="field"><label for="${p}Aadhaar">Aadhaar number</label><input id="${p}Aadhaar" value="${esc(c.aadhaar || '')}"></div><div class="field"><label for="${p}Other">Other ID type / number</label><input id="${p}Other" value="${esc(c.otherId || '')}"></div><div class="field"><label for="${p}Account">Customer account number</label><input id="${p}Account" value="${esc(c.account || '')}"></div><div class="field"><label for="${p}Ifsc">IFSC / bank details</label><input id="${p}Ifsc" value="${esc(c.ifsc || '')}"></div></div>`;
  const readCust = p => ({ name: val(p + 'Name'), mobile: val(p + 'Mobile'), address: val(p + 'Address'), aadhaar: val(p + 'Aadhaar'), otherId: val(p + 'Other'), account: val(p + 'Account'), ifsc: val(p + 'Ifsc') });
  const checkCust = (c, needAddr) => { if (!c.name || !c.mobile) throw new Error('Enter the customer name and mobile number.'); if (!/^[+\d][\d\s-]{6,}$/.test(c.mobile)) throw new Error('Enter a valid mobile number.'); if (needAddr && !c.address) throw new Error('Enter the full address.'); };
  const nextCid = () => 'C-' + (1001 + Math.max(0, ...db().customers.map(c => Number(String(c.id).replace(/\D/g, '')) - 1000 || 0)));
  F.customer = id => {
    const c = id ? db().customers.find(x => x.id === id) : {};
    GD.openModal({ title: id ? 'Edit customer profile' : 'Add customer', sub: id ? 'Linked loans stay linked.' : 'Create one complete customer profile.', body: custFields(c, 'cf'), save: 'Save customer', onSave: () => {
      const v = readCust('cf'); checkCust(v, true);
      St.commit(D => { if (id) { Object.assign(c, v); St.touch('customers', c, 'Updated'); } else { const n = Object.assign({ id: nextCid() }, v); D.customers.unshift(n); St.touch('customers', n, 'Created'); } });
      GD.toast(id ? 'Customer updated' : 'Customer added');
    } });
  };
  F.customerView = id => {
    const c = GD.cust(id), D = db(), ls = D.loans.filter(l => l.cid === id), td = today();
    GD.openModal({ title: c.name, sub: 'Customer ID ' + id, wide: true, hideSave: true, cancel: 'Close', body: `<div class="kv"><div><small>Mobile</small><b>${esc(c.mobile || '—')}</b></div><div><small>Address</small><b>${esc(c.address || '—')}</b></div><div><small>Aadhaar</small><b>${esc(c.aadhaar || '—')}</b></div><div><small>Other ID</small><b>${esc(c.otherId || '—')}</b></div><div><small>Account number</small><b>${esc(c.account || '—')}</b></div><div><small>IFSC / bank details</small><b>${esc(c.ifsc || '—')}</b></div></div>
<h3 style="font-size:13px;margin:18px 0 8px">Linked loans</h3><div class="tablewrap"><table><thead><tr><th>Ledger</th><th>Amount</th><th>Loan date</th><th>Renewal</th><th>State</th><th></th></tr></thead><tbody>${ls.map(l => `<tr><td><b>${esc(l.ledger)}</b>${l.renewedFrom ? '<small>Renewal of ' + esc((D.loans.find(x => x.id === l.renewedFrom) || {}).ledger || '') + '</small>' : ''}</td><td>${money(l.amount)}</td><td>${fmt(l.date)}</td><td>${fmt(l.renewal)}</td><td><span class="pill">${esc(C.renewalState(l, td))}</span></td><td><button class="btn small" data-loan="${l.id}">Open</button></td></tr>`).join('') || '<tr><td colspan="6">No loans linked.</td></tr>'}</tbody></table></div>
<h3 style="font-size:13px;margin:18px 0 4px">Uploaded images</h3><div id="cvImgs"></div>`,
      onOpen: b => { b.addEventListener('click', e => { const t = e.target.closest('[data-loan]'); if (t) { GD.closeModal(); setTimeout(() => F.loanView(t.dataset.loan), 30); } });
        const host = b.querySelector('#cvImgs'); (async () => { for (const l of ls) { const ids = l.imageIds || []; if (!ids.length) continue; const h = document.createElement('div'); h.innerHTML = `<div class="sub" style="margin-top:8px">${esc(l.ledger)}</div><div class="thumbs"></div>`; host.appendChild(h); await GD.thumbs(h.querySelector('.thumbs'), ids, l.ledger); } if (!host.children.length) host.innerHTML = '<div class="empty">No images uploaded.</div>'; })(); } });
  };

  /* ================= LOANS ================= */
  GD.pages.loans = {
    mount() {
      $('page-loans').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Loan register</div><h1>Gold Loans</h1><p>Tap a loan to see details, images and history. Only the appraiser charge is tracked, not the loan itself.</p></div><button class="btn primary" id="addLoan">＋ New gold loan</button></div>
<div class="toolbar">${row('loanSearch', 'Search ledger, customer or mobile…', 'type="search"')}</div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Ledger / Customer</th><th>Loan amount</th><th>Charge</th><th>Loan date</th><th>Renewal</th><th>Images</th><th></th></tr></thead><tbody id="loanBody"></tbody></table></div></div>`;
      $('addLoan').onclick = () => F.loan(); ['loanSearch'].forEach(i => $(i).addEventListener('input', () => this.render()));
      $('loanBody').addEventListener('click', e => { const b = e.target.closest('[data-del]'); if (b) { e.stopPropagation(); return F.deleteLoan(b.dataset.del); } const r = e.target.closest('tr[data-id]'); if (r) F.loanView(r.dataset.id); });
    },
    render() {
      const q = val('loanSearch').toLowerCase(), f = '', D = db();
      const a = D.loans.filter(x => [x.ledger, custName(x.cid), GD.cust(x.cid).mobile].some(v => String(v || '').toLowerCase().includes(q)) && (!f || C.payStatus(x) === f)).sort((x, y) => y.date.localeCompare(x.date));
      $('loanBody').innerHTML = a.map(x => `<tr class="touchrow" data-id="${x.id}"><td><div class="person"><div class="mini">GL</div><div><strong>${esc(x.ledger)}</strong><small>${esc(custName(x.cid))} · ${esc(GD.cust(x.cid).mobile || 'No mobile')}</small></div></div></td><td>${money(x.amount)}</td><td><b>${money(x.charge)}</b><small>Received ${money(x.received)}</small></td><td>${fmt(x.date)}</td><td>${fmt(x.renewal)}<small>${esc(C.renewalState(x, today()))}</small></td><td><span class="pill">${(x.imageIds || []).length} image(s)</span></td><td><button class="btn small danger" data-del="${x.id}">Delete</button></td></tr>`).join('') || `<tr><td colspan="7">${empty(q || f ? 'No loans match' : 'No gold loans yet', 'Use “New gold loan” to register one.')}</td></tr>`;
    }
  };
  const imgField = (id, label, cur) => `<div class="field full"><label for="${id}">${label}</label><input id="${id}" type="file" accept="image/*"><small class="sub">${cur ? 'An image is already attached. Choose a file only to replace it; the earlier image is kept in history.' : 'JPEG/PNG photo. Large photos are resized automatically.'}</small></div>`;
  const readImgs = async (b, loan) => {
    const out = {};
    for (const [k, id] of [['goldImage', 'fGold'], ['appImage', 'fApp']]) { const f = $(id).files[0]; if (f) { try { out[k] = await St.addImage(f); } catch (e) { throw new Error(e.message); } } }
    return out;
  };
  F.loan = () => {
    const D = db(), s = D.settings;
    GD.openModal({ title: 'Register gold loan', sub: 'Every saved loan is treated as disbursed; the appraiser charge is tracked separately.', body: `
<div class="field full"><label for="fMode">Customer</label><select id="fMode"><option value="new">＋ Add a new customer</option><option value="existing">Choose existing customer</option></select></div>
<div id="fNew" style="margin-top:13px">${custFields({}, 'nc')}</div>
<div id="fOld" class="formgrid" style="display:none;margin-top:13px"><div class="field full"><label for="fSearch">Search existing customer *</label><input id="fSearch" placeholder="Name, mobile, address, ID or account"><input type="hidden" id="fCid"><div id="fRes" class="customer-results"></div></div></div>
<div class="formgrid" style="margin-top:15px"><div class="field"><label for="fLedger">Ledger / application number *</label><input id="fLedger" placeholder="e.g. GL-24082"></div><div class="field"><label for="fAmount">Loan amount (₹) *</label><input id="fAmount" type="number" min="1" step=".01"></div>
<div class="field"><label for="fCharge">Calculated appraiser charge (₹)</label><input id="fCharge" readonly value="${s.feeStandard}"></div><div class="field"><label for="fDate">Loan date</label><input id="fDate" type="date" value="${today()}"><small class="sub" id="fSun"></small></div>
<div class="field full"><label for="fRen">Renewal due date</label><input id="fRen" type="date" value="${C.addDays(today(), 365)}"></div>${imgField('fGold', 'Gold photograph', false)}${imgField('fApp', 'Loan application photograph', false)}
<div class="field full"><label for="fNotes">Notes</label><textarea id="fNotes" rows="2"></textarea></div></div>`, save: 'Save loan',
      onOpen: () => {
        $('fMode').onchange = () => { $('fNew').style.display = $('fMode').value === 'new' ? '' : 'none'; $('fOld').style.display = $('fMode').value === 'old' || $('fMode').value === 'existing' ? 'grid' : 'none'; };
        $('fAmount').addEventListener('input', () => { $('fCharge').value = C.calcFee($('fAmount').value, db().settings); });
        $('fSearch').addEventListener('input', () => { const q = val('fSearch').toLowerCase(); $('fCid').value = ''; $('fRes').innerHTML = q ? (db().customers.filter(c => [c.id, c.name, c.mobile, c.address, c.aadhaar, c.otherId, c.account].some(v => String(v || '').toLowerCase().includes(q))).slice(0, 8).map(c => `<button type="button" class="customer-result" data-c="${c.id}"><b>${esc(c.name)}</b><small>${esc(c.mobile || '')} · ${esc(c.address || '')} · ${esc(c.id)}</small></button>`).join('') || '<small class="sub">No matching customer.</small>') : ''; });
        $('fRes').addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (!b) return; const c = GD.cust(b.dataset.c); $('fCid').value = c.id; $('fSearch').value = c.name + ' · ' + (c.mobile || ''); $('fRes').innerHTML = '<small class="sub">Selected: ' + esc(c.name) + '</small>'; });
        sundayHint('fDate', 'fSun');
      },
      onSave: async () => {
        const ledger = val('fLedger'), amount = Number($('fAmount').value), mode = $('fMode').value, date = $('fDate').value, ren = $('fRen').value;
        if (!ledger) throw new Error('Enter the ledger number.'); if (!(amount > 0)) throw new Error('Enter a valid loan amount.');
        if (db().loans.some(l => l.ledger.toLowerCase() === ledger.toLowerCase())) throw new Error('Ledger number “' + ledger + '” already exists.');
        if (!C.isISO(date)) throw new Error('Enter the loan date.'); if (ren && !C.isISO(ren)) throw new Error('Enter a valid renewal date.'); if (ren && ren < date) throw new Error('The renewal date cannot be before the loan date.');
        let cid, nc; if (mode === 'new') { nc = readCust('nc'); checkCust(nc, true); } else { cid = $('fCid').value; if (!cid) throw new Error('Choose an existing customer from the search results.'); }
        if (!$('fGold').files[0] && !$('fApp').files[0]) throw new Error('Attach at least one image (gold photograph or loan application).');
        const imgs = await readImgs();
        St.commit(D => {
          if (nc) { nc.id = nextCid(); D.customers.unshift(nc); St.touch('customers', nc, 'Created'); cid = nc.id; }
          const charge = C.calcFee(amount, D.settings), l = { id: C.uid('L'), cid, ledger, amount, charge, received: charge, receipts: [{ id: C.uid('R'), date, amount: charge, note: 'Charge assumed received on entry' }], date, renewal: ren, renewalStatus: 'Active', renewalHistory: [], notes: val('fNotes'), goldImage: imgs.goldImage || '', appImage: imgs.appImage || '', imageIds: [imgs.goldImage, imgs.appImage].filter(Boolean), previousImageIds: [] };
          D.loans.unshift(l); St.touch('loans', l, 'Created', ledger + ' · ' + money(amount));
        });
        GD.toast('Loan saved. Helper settlement created.');
      } });
  };
  F.loanView = id => {
    const D = db(), l = D.loans.find(x => x.id === id); if (!l) return; const c = GD.cust(l.cid), sp = C.splitCharge(l.charge, D.settings), st = D.settlements.find(s => s.loanId === l.id), td = today(), n = N();
    const chain = D.loans.filter(x => x.cid === l.cid && x.id !== l.id);
    GD.openModal({ title: l.ledger, sub: c.name + ' · ' + (c.mobile || 'no mobile'), wide: true, save: 'Edit loan', cancel: 'Close', onSave: () => { setTimeout(() => F.loanEdit(id), 30); return true; }, body: `
<div class="detailgrid"><div class="detailtile"><small>Loan amount</small><b>${money(l.amount)}</b></div><div class="detailtile"><small>Appraiser charge</small><b>${money(l.charge)}</b></div></div>
<div class="kv"><div><small>Loan date</small><b>${fmt(l.date)}</b></div><div><small>Renewal due</small><b>${fmt(l.renewal)} · ${esc(C.renewalState(l, td))}</b></div><div><small>${esc(n.a1)} / ${esc(n.a2)} / ${esc(n.helper)}</small><b>${money(sp.a1)} / ${money(sp.a2)} / ${money(sp.helper)}</b></div>
<div><small>Customer account no.</small><b>${esc(c.account || '—')}</b></div><div><small>Notes</small><b>${esc(l.notes || '—')}</b></div></div>
<h3 class="detailsection">Images</h3><div class="thumbs" id="lvImgs"></div>
${chain.length ? '<h3 class="detailsection">Other loans of this customer</h3><div class="tablewrap"><table><tbody>' + chain.map(x => `<tr><td><b>${esc(x.ledger)}</b></td><td>${money(x.amount)}</td><td>${fmt(x.date)}</td><td>${esc(C.renewalState(x, td))}${x.renewedFrom === l.id ? ' · renewal of this loan' : x.id === l.renewedFrom ? ' · earlier loan' : ''}</td></tr>`).join('') + '</tbody></table></div>' : ''}
<h3 class="detailsection">History</h3><div class="hist" id="lvHist"></div>`,
      onOpen: b => { GD.thumbs(b.querySelector('#lvImgs'), l.imageIds || [], l.ledger);
        const h = [...(l.renewalHistory || []).map(x => ({ at: x.date, t: x.action + (x.note ? ' — ' + x.note : '') })), ...(l.receipts || []).map(x => ({ at: x.date, t: 'Charge received ' + money(x.amount) + (x.note ? ' — ' + x.note : '') })), ...D.audit.filter(a => a.id === l.id).map(a => ({ at: a.at.slice(0, 10), t: a.action + (a.summary ? ' — ' + a.summary : '') }))].sort((a, b) => b.at.localeCompare(a.at));
        b.querySelector('#lvHist').innerHTML = h.map(x => `<div>${esc(x.t)}<small>${fmt(x.at)}</small></div>`).join('') || '<div>No history yet.</div>'; } });
  };
  F.loanEdit = id => {
    const l = db().loans.find(x => x.id === id); if (!l) return;
    GD.openModal({ title: 'Edit loan ' + l.ledger, sub: 'Images and payment history are preserved.', save: 'Save changes', body: `<div class="formgrid"><div class="field"><label for="eLedger">Ledger number *</label><input id="eLedger" value="${esc(l.ledger)}"></div><div class="field"><label for="eAmount">Loan amount (₹) *</label><input id="eAmount" type="number" step=".01" value="${l.amount}"></div><div class="field"><label for="eDate">Loan date</label><input id="eDate" type="date" value="${l.date}"><small class="sub" id="eSun"></small></div><div class="field"><label for="eRen">Renewal due date</label><input id="eRen" type="date" value="${l.renewal || ''}"></div><div class="field full"><label for="eNotes">Notes</label><textarea id="eNotes" rows="2">${esc(l.notes || '')}</textarea></div>${imgField('fGold', 'Gold photograph', l.goldImage)}${imgField('fApp', 'Loan application photograph', l.appImage)}</div><div class="notice" style="margin-top:12px">Changing the loan amount recalculates the charge; the Appraiser 2 and Helper amounts are recalculated for this loan only.</div>`,
      onOpen: () => sundayHint('eDate', 'eSun'),
      onSave: async () => {
        const ledger = val('eLedger'), amount = Number($('eAmount').value), date = $('eDate').value, ren = $('eRen').value;
        if (!ledger || !(amount > 0)) throw new Error('Enter a ledger number and a valid amount.'); if (!C.isISO(date)) throw new Error('Enter the loan date.'); if (ren && !C.isISO(ren)) throw new Error('Enter a valid renewal date.');
        if (db().loans.some(x => x.id !== id && x.ledger.toLowerCase() === ledger.toLowerCase())) throw new Error('Ledger number “' + ledger + '” already exists.');
        const imgs = await readImgs();
        St.commit(D => {
          const changed = []; if (l.amount !== amount) { changed.push('amount ' + l.amount + '→' + amount); l.charge = C.calcFee(amount, D.settings); l.receipts.push({ id: C.uid('R'), date: today(), amount: 0, note: 'Charge recalculated after amount edit' }); l.received = Math.min(l.received, l.charge); }
          if (l.ledger !== ledger) changed.push('ledger ' + l.ledger + '→' + ledger); if (l.date !== date) changed.push('date'); if ((l.renewal || '') !== ren) changed.push('renewal date');
          Object.assign(l, { ledger, amount, date, renewal: ren, notes: val('eNotes') });
          ['goldImage', 'appImage'].forEach(k => { if (imgs[k]) { if (l[k]) (l.previousImageIds = l.previousImageIds || []).push(l[k]); l[k] = imgs[k]; changed.push(k === 'goldImage' ? 'gold photo' : 'application photo'); } });
          l.imageIds = [l.goldImage, l.appImage].filter(Boolean); St.touch('loans', l, 'Edited', changed.join(', '));
        });
        GD.toast('Loan updated');
      } });
  };
  F.receipt = (coll, id) => {
    const x = db()[coll === 'loans' ? 'loans' : 'inspections'].find(y => y.id === id); if (!x) return; const bal = C.balance(x), isL = coll === 'loans';
    GD.openModal({ title: 'Record ' + (isL ? 'loan-charge' : 'inspection') + ' receipt', sub: 'Outstanding balance: ' + money(bal) + '. Partial payments are supported.', save: 'Save receipt', body: `<div class="formgrid"><div class="field"><label>Total charge</label><input disabled value="${money(x.charge)}"></div><div class="field"><label>Already received</label><input disabled value="${money(x.received)}"></div><div class="field"><label for="rcAmt">New amount received (₹)</label><input id="rcAmt" type="number" min="0.01" step=".01" value="${bal}"></div><div class="field"><label for="rcDate">Receipt date</label><input id="rcDate" type="date" value="${today()}"></div></div>`,
      onSave: () => { const a = Number($('rcAmt').value), d = $('rcDate').value; if (!(a > 0)) throw new Error('Enter an amount greater than zero.'); if (a > bal + 0.005) throw new Error('That is more than the outstanding balance of ' + money(bal) + '.'); if (!C.isISO(d)) throw new Error('Enter the receipt date.');
        St.commit(() => { x.received = C.round2(x.received + a); (x.receipts = x.receipts || []).push({ id: C.uid('R'), date: d, amount: a }); St.touch(isL ? 'loans' : 'inspections', x, 'Receipt', money(a) + ' on ' + d); }); GD.toast('Receipt recorded'); } });
  };

  /* ================= INSPECTION ================= */
  GD.pages.inspection = {
    mount() {
      $('page-inspection').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Packet-based charges</div><h1>Inspection</h1><p>Inspection charge = packets × rate. Payment status is tracked for each record.</p></div><button class="btn primary" id="addInsp">＋ Add Inspection</button></div>
<div class="grid stats3"><div class="card"><div class="label">Inspection income this month</div><div class="value" id="iMonth">₹0</div></div><div class="card"><div class="label">Pending inspection amount</div><div class="value" id="iPend">₹0</div></div><div class="card"><div class="label">Packets assessed</div><div class="value" id="iPk">0</div></div></div>
<div class="toolbar" style="margin-top:15px">${row('iSearch', 'Search branch or date…', 'type="search"')}<select id="iFilter" class="btn" aria-label="Payment status"><option value="">All payment status</option><option>Paid</option><option>Partially Paid</option><option>Unpaid</option></select></div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Date / Branch</th><th>Packets</th><th>Charge</th><th>Received</th><th>Pending</th><th>Status</th><th></th></tr></thead><tbody id="iBody"></tbody></table></div></div>`;
      $('addInsp').onclick = () => F.inspection(); ['iSearch', 'iFilter'].forEach(i => $(i).addEventListener('input', () => this.render()));
      $('iBody').addEventListener('click', e => { const b = e.target.closest('[data-p],[data-e]'); if (b) b.dataset.p ? F.receipt('inspections', b.dataset.p) : F.inspection(b.dataset.e); });
    },
    render() {
      const q = val('iSearch').toLowerCase(), f = $('iFilter').value, D = db(), t = C.totals(D, today());
      set('iMonth', money(t.inspectionMonth)); set('iPend', money(t.pendInsp)); set('iPk', D.inspections.reduce((n, x) => n + x.packets, 0));
      const a = D.inspections.filter(x => (String(x.branch).toLowerCase().includes(q) || x.date.includes(q)) && (!f || C.payStatus(x) === f)).sort((x, y) => y.date.localeCompare(x.date));
      $('iBody').innerHTML = a.map(x => `<tr><td><b>${fmt(x.date)}</b><small>${esc(x.branch)}</small></td><td>${x.packets}</td><td>${money(x.charge)}</td><td>${money(x.received)}</td><td><b>${money(C.balance(x))}</b></td><td><span class="status ${sc(C.payStatus(x))}">${C.payStatus(x)}</span></td><td><div class="rowact"><button class="btn small" data-p="${x.id}" ${C.balance(x) ? '' : 'disabled'}>Payment</button><button class="btn small" data-e="${x.id}">Edit</button></div></td></tr>`).join('') || `<tr><td colspan="7">${empty('No inspections found', 'Use “Add Inspection” to record one.')}</td></tr>`;
    }
  };
  F.inspection = id => {
    const s = db().settings, x = id ? db().inspections.find(i => i.id === id) : null;
    GD.openModal({ title: x ? 'Edit inspection' : 'Record inspection', sub: 'Charge is calculated from packets assessed.', save: 'Save inspection', body: `<div class="formgrid"><div class="field"><label for="iDate">Inspection date</label><input id="iDate" type="date" value="${x ? x.date : today()}"><small class="sub" id="iSun"></small></div><div class="field"><label for="iBranch">Branch *</label><input id="iBranch" value="${esc(x ? x.branch : '')}" placeholder="Bank / branch name"></div><div class="field"><label for="iPackets">Gold packets *</label><input id="iPackets" type="number" min="1" step="1" value="${x ? x.packets : 1}"></div><div class="field"><label for="iRate">Rate per packet (₹)</label><input id="iRate" type="number" min="0" step=".01" value="${x ? (x.rate != null ? x.rate : C.round2(x.charge / (x.packets || 1))) : s.packetRate}"></div><div class="field"><label for="iCharge">Inspection amount (₹)</label><input id="iCharge" readonly></div><div class="field"><label for="iRecv">Amount received (₹)</label><input id="iRecv" type="number" min="0" step=".01" value="${x ? x.received : 0}"></div></div>`,
      onOpen: () => { const f = () => { $('iCharge').value = C.inspectionCharge($('iPackets').value, $('iRate').value); }; f(); ['iPackets', 'iRate'].forEach(i => $(i).addEventListener('input', f)); sundayHint('iDate', 'iSun'); },
      onSave: () => { const branch = val('iBranch'), packets = Number($('iPackets').value), rate = Number($('iRate').value), date = $('iDate').value, charge = C.inspectionCharge(packets, rate), recv = Number($('iRecv').value) || 0;
        if (!branch) throw new Error('Enter the branch.'); if (!(packets >= 1) || !Number.isInteger(packets)) throw new Error('Enter a whole number of packets (1 or more).'); if (!(rate >= 0)) throw new Error('Enter a valid rate.'); if (!C.isISO(date)) throw new Error('Enter the inspection date.'); if (recv < 0 || recv > charge + .005) throw new Error('Amount received must be between 0 and ' + money(charge) + '.');
        St.commit(D => { if (x) { Object.assign(x, { date, branch, packets, rate, charge, received: Math.min(charge, recv) }); St.touch('inspections', x, 'Edited', branch + ' · ' + money(charge)); } else { const n = { id: C.uid('IN'), date, branch, packets, rate, charge, received: recv, receipts: recv ? [{ id: C.uid('R'), date, amount: recv }] : [] }; D.inspections.unshift(n); St.touch('inspections', n, 'Created', branch + ' · ' + money(charge)); } }); GD.toast('Inspection saved'); } });
  };

  /* ================= HELPER SETTLEMENTS ================= */
  let hF = { acct: '', y: '', m: '', w: '', d: '' };
  const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const accName = k => k === 'a2' ? N().a2 + ' (payable to)' : k === 'hA1' ? N().helper + ' (Helper — borne by ' + N().a1 + ')' : N().helper + ' (earlier entry)';
  const optHtml = (arr, all, cur) => '<option value="">' + all + '</option>' + arr.map(([v, l]) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${l}</option>`).join('');
  GD.pages.settlements = {
    mount() {
      $('page-settlements').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Running account</div><h1>Settlement</h1><p>Every loan adds to what you owe <span data-name="a2"></span>, and to the Helper's share (borne by Appraiser 1 only). Record what you actually pay, whenever you pay it.</p></div></div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Account</th><th>Accrued from loans</th><th>Paid so far</th><th>Pending</th><th></th></tr></thead><tbody id="sAcc"></tbody></table></div></div>
<div class="titleline" style="margin-top:22px"><div><h2>Settlement history</h2><p>Choose Year, then Month, Week and Day. Corrections and reversals keep a log.</p></div></div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:12px"><div class="field"><label for="hAcct">Account</label><select id="hAcct"></select></div><div class="field"><label for="hY">Year</label><select id="hY"></select></div><div class="field"><label for="hM">Month</label><select id="hM"></select></div><div class="field"><label for="hW">Week</label><select id="hW"></select></div><div class="field"><label for="hD">Day</label><select id="hD"></select></div></div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Date</th><th>Account</th><th>Amount</th><th>Note</th><th>Status</th><th></th></tr></thead><tbody id="sHist"></tbody></table></div><div class="sub" style="padding:8px 4px" id="sSum"></div></div>`;
      [['hAcct', 'acct'], ['hY', 'y'], ['hM', 'm'], ['hW', 'w'], ['hD', 'd']].forEach(([id, k], i, all) => $(id).addEventListener('change', () => { hF[k] = $(id).value; all.slice(i + 1).forEach(([, kk]) => { if (k !== 'acct') hF[kk] = ''; }); this.render(); }));
      $('sAcc').addEventListener('click', e => { const b = e.target.closest('[data-pay],[data-full]'); if (b) F.payment(b.dataset.pay || b.dataset.full, null, b.dataset.full ? Number(b.dataset.amt) : 0); });
      $('sHist').addEventListener('click', e => { const b = e.target.closest('[data-ed],[data-rv],[data-lg]'); if (!b) return; if (b.dataset.ed) { const p = db().payments.find(x => x.id === b.dataset.ed); F.payment(p.acct, p.id); } else if (b.dataset.rv) F.payReverse(b.dataset.rv); else F.payLog(b.dataset.lg); });
    },
    render() {
      const D = db(), A = C.accounts(D), n = N();
      const row = k => `<tr><td><b>${esc(accName(k))}</b></td><td>${money(A[k].accrued)}</td><td>${money(A[k].paid)}</td><td><b>${money(A[k].pending)}</b>${A[k].advance ? '<small>Advance ' + money(A[k].advance) + '</small>' : ''}</td><td><div class="rowact"><button class="btn small teal" data-pay="${k}">Record payment</button><button class="btn small" data-full="${k}" data-amt="${A[k].pending}" ${A[k].pending ? '' : 'disabled'}>Settle full</button></div></td></tr>`;
      $('sAcc').innerHTML = row('a2') + row('hA1');
      const all = D.payments.filter(p => !hF.acct || p.acct === hF.acct || (hF.acct === 'hA1' && p.acct === 'hA2')).sort((x, y) => y.date.localeCompare(x.date) || (y.createdAt || '').localeCompare(x.createdAt || ''));
      const uniq = (l, f) => [...new Set(l.map(f))].sort().reverse();
      $('hAcct').innerHTML = optHtml(['a2', 'hA1'].map(k => [k, accName(k)]), 'All accounts', hF.acct);
      $('hY').innerHTML = optHtml(uniq(all, p => p.date.slice(0, 4)).map(y => [y, y]), 'All years', hF.y);
      const inY = all.filter(p => !hF.y || p.date.slice(0, 4) === hF.y); $('hM').disabled = !hF.y;
      $('hM').innerHTML = optHtml(hF.y ? uniq(inY, p => p.date.slice(5, 7)).map(m => [m, MON[+m - 1]]) : [], hF.y ? 'All months' : 'Select a year first', hF.m);
      const inM = inY.filter(p => !hF.m || p.date.slice(5, 7) === hF.m); $('hW').disabled = !hF.m;
      $('hW').innerHTML = optHtml(hF.m ? uniq(inM, p => C.weekBounds(p.date)[0]).reverse().map(w => [w, 'Week ' + (Math.round((C.parseISO(w) - C.parseISO(C.weekBounds(hF.y + '-' + hF.m + '-01')[0])) / 6048e5) + 1) + ' · ' + fmt(w).slice(0, 5) + ' – ' + fmt(C.addDays(w, 5)).slice(0, 5)]) : [], hF.m ? 'All weeks' : 'Select a month first', hF.w);
      const inW = inM.filter(p => !hF.w || C.weekBounds(p.date)[0] === hF.w); $('hD').disabled = !hF.w;
      $('hD').innerHTML = optHtml(hF.w ? uniq(inW, p => p.date).reverse().map(d => [d, fmt(d)]) : [], hF.w ? 'All days' : 'Select a week first', hF.d);
      const a = inW.filter(p => !hF.d || p.date === hF.d);
      $('sHist').innerHTML = a.map(p => { const rv = p.status === 'reversed'; return `<tr style="${rv ? 'opacity:.55' : ''}"><td>${fmt(p.date)}</td><td>${esc(accName(p.acct))}</td><td><b style="${rv ? 'text-decoration:line-through' : ''}">${money(p.amount)}</b></td><td>${esc(p.note || '—')}</td><td><span class="status ${rv ? 'unpaid' : 'paid'}">${rv ? 'Reversed' : 'Recorded'}</span></td><td><div class="rowact">${rv ? '' : `<button class="btn small" data-ed="${p.id}">Correct</button><button class="btn small danger" data-rv="${p.id}">Reverse</button>`}<button class="btn small" data-lg="${p.id}">Log</button></div></td></tr>`; }).join('') || `<tr><td colspan="6">${empty('No settlement records', hF.y || hF.acct ? 'Nothing matches these filters.' : 'Payments you record will appear here.')}</td></tr>`;
      set('sSum', a.length + ' record(s) · paid ' + money(a.filter(p => p.status !== 'reversed').reduce((m, p) => m + p.amount, 0)));
    }
  };
  async function paySaved(msg) { await St.flush(); if (St.state.storageError) throw new Error(St.state.storageError); GD.toast(msg); GD.refresh(); }
  F.payment = (acct, id, preset) => {
    const D = db(), A = C.accounts(D)[acct], p = id ? D.payments.find(x => x.id === id) : null;
    GD.openModal({ title: (p ? 'Correct payment — ' : 'Record payment — ') + accName(acct), sub: 'Accrued ' + money(A.accrued) + ' · paid ' + money(A.paid) + ' · pending ' + money(A.pending), save: p ? 'Save correction' : 'Record payment',
      body: `<div class="formgrid"><div class="field"><label for="pyAmt">Amount actually paid (₹)</label><input id="pyAmt" type="number" min="1" step="1" value="${p ? p.amount : (preset || '')}"></div><div class="field"><label for="pyDt">Payment date</label><input id="pyDt" type="date" value="${p ? p.date : today()}"></div><div class="field full"><label for="pyNt">Note</label><input id="pyNt" maxlength="120" value="${esc(p ? p.note : '')}"></div><label class="check full"><input type="checkbox" id="pyOv"> Allow more than pending (advance — note required)</label></div>`,
      onSave: async () => { const o = { acct, amount: Number($('pyAmt').value), date: $('pyDt').value, note: $('pyNt').value, allowOver: $('pyOv').checked }, now = new Date().toISOString();
        St.commit(DB => { const r = p ? C.editPayment(DB, id, o, now) : C.addPayment(DB, o, now); St.touch('payments', r, p ? 'Corrected' : 'Recorded', money(o.amount)); }); await paySaved(p ? 'Payment corrected' : 'Payment recorded'); } });
  };
  F.payReverse = async id => { const p = db().payments.find(x => x.id === id); if (!p || !await GD.confirm({ title: 'Reverse this payment?', message: money(p.amount) + ' paid on ' + fmt(p.date) + ' will be added back to the pending balance. The entry stays in history marked Reversed.', confirm: 'Reverse', danger: true })) return;
    try { St.commit(DB => { St.touch('payments', C.reversePayment(DB, id, new Date().toISOString()), 'Reversed'); }); await paySaved('Payment reversed'); } catch (e) { GD.toast(e.message, 'err'); } };
  F.payLog = id => { const p = db().payments.find(x => x.id === id); if (!p) return; const d = h => h.from ? money(h.from.amount) + ' ' + fmt(h.from.date) + ' → ' + money(h.to.amount) + ' ' + fmt(h.to.date) : money(h.amount) + (h.date ? ' · ' + fmt(h.date) : '');
    GD.openModal({ title: 'Payment log', sub: money(p.amount) + ' · ' + fmt(p.date), hideSave: true, cancel: 'Close', body: p.history.map(h => `<div class="setting"><div><strong>${esc(h.action)}</strong><small>${new Date(h.at).toLocaleString('en-IN')}</small></div><span>${esc(d(h))}</span></div>`).join('') }); };
  F.receivable = () => GD.openModal({ title: 'Add pending amount', sub: 'The amount is removed from the original income date. Record the receipt later on its actual date.', save: 'Save pending amount', body: `<div class="formgrid"><div class="field"><label for="rcA">Amount to mark pending (₹) *</label><input id="rcA" type="number" min="0.01" step=".01"></div><div class="field"><label for="rcD">Original income date *</label><input id="rcD" type="date" value="${today()}"></div><div class="field full"><label for="rcN">Reason / reference</label><input id="rcN" placeholder="Loan ledger, inspection, reason"></div></div>`,
    onSave: () => { const a = Number($('rcA').value), d = $('rcD').value; if (!(a > 0) || !C.isISO(d)) throw new Error('Enter a valid amount and date.'); St.commit(D => { const r = { id: C.uid('REC'), amount: a, sourceDate: d, description: val('rcN'), paid: 0, payments: [] }; D.receivables.unshift(r); St.touch('receivables', r, 'Created', money(a)); }); GD.toast('Pending amount recorded'); } });
  F.receivableDetail = (id, op) => {
    const r = db().receivables.find(x => x.id === id); if (!r) return; const bal = Math.max(0, r.amount - (r.paid || 0));
    if (op === 'pay') return GD.openModal({ title: 'Record amount received', sub: 'Outstanding: ' + money(bal), save: 'Save receipt', body: `<div class="formgrid"><div class="field"><label for="rpA">Amount received (₹)</label><input id="rpA" type="number" min="0.01" step=".01" value="${bal}"></div><div class="field"><label for="rpD">Actual receipt date</label><input id="rpD" type="date" value="${today()}"></div><div class="field full"><label for="rpR">Reference / note</label><input id="rpR"></div></div>`,
      onSave: () => { const a = Number($('rpA').value), d = $('rpD').value; if (!(a > 0) || a > bal + .005 || !C.isISO(d)) throw new Error('Check the amount (max ' + money(bal) + ') and date.'); St.commit(() => { r.payments.push({ id: C.uid('RCP'), amount: a, date: d, reference: val('rpR') }); r.paid = C.round2(r.payments.reduce((n, p) => n + p.amount, 0)); St.touch('receivables', r, 'Receipt', money(a) + ' on ' + d); }); GD.toast('Receipt saved'); } });
    GD.openModal({ title: 'Adjustment history', sub: (r.description || 'Pending amount') + ' · income date ' + fmt(r.sourceDate), hideSave: true, cancel: 'Close', body: `<div class="detailgrid"><div class="detailtile"><small>Original</small><b>${money(r.amount)}</b></div><div class="detailtile"><small>Received</small><b>${money(r.paid || 0)}</b></div><div class="detailtile"><small>Outstanding</small><b>${money(bal)}</b></div></div><div class="tablewrap"><table><thead><tr><th>Date</th><th>Amount</th><th>Reference</th></tr></thead><tbody>${(r.payments || []).map(p => `<tr><td>${fmt(p.date)}</td><td>${money(p.amount)}</td><td>${esc(p.reference || '—')}</td></tr>`).join('') || '<tr><td colspan="3">No receipts yet.</td></tr>'}</tbody></table></div>` });
  };

  /* ---- delete loan / customer (no orphans: settlements removed with the loan; renewal links cleared) ---- */
  const dropLoan = id => { const D = db(); D.loans.forEach(x => { if (x.renewedFrom === id) { x.renewedFrom = ''; St.touch('loans', x, 'Updated', 'Source loan deleted'); } }); D.settlements.filter(z => z.loanId === id).forEach(z => St.remove('settlements', z.id, 'Loan deleted')); St.remove('loans', id, 'Loan deleted'); };
  F.deleteLoan = async id => {
    const l = db().loans.find(x => x.id === id); if (!l) return; 
    if (!await GD.confirm({ title: 'Delete loan ' + l.ledger + '?', danger: true, confirm: 'Delete loan', html: `<p>This permanently removes the loan, its ${money(l.charge)} charge Its Appraiser 2 and Helper amounts are removed from the pending balances. Payments you already recorded stay in Settlement history. Income totals will change. This cannot be undone.</p>` })) return;
    dropLoan(id); await St.flush(); GD.toast(St.state.storageError || 'Loan deleted', St.state.storageError ? 'err' : ''); GD.refresh();
  };
  F.deleteCustomer = async id => {
    const c = GD.cust(id), ls = db().loans.filter(l => l.cid === id);
    if (!await GD.confirm({ title: 'Delete ' + c.name + '?', danger: true, confirm: 'Delete customer', html: `<p>${ls.length ? 'This customer has <b>' + ls.length + '</b> loan(s) (' + ls.map(l => esc(l.ledger)).join(', ') + '). They will be deleted too, and their Appraiser 2 / Helper amounts leave the pending balances (payments already recorded stay in history), so nothing is left without a customer.' : 'This customer has no loans.'} Income and pending totals will change. This cannot be undone.</p>` })) return;
    ls.forEach(l => dropLoan(l.id)); St.remove('customers', id, 'Customer deleted'); await St.flush(); GD.toast(St.state.storageError || 'Customer deleted', St.state.storageError ? 'err' : ''); GD.refresh();
  };

  /* ================= RENEWALS ================= */
  GD.pages.renewals = {
    mount() {
      $('page-renewals').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Renewal reminders</div><h1>Renewals</h1><p>Overdue loans and loans due within the reminder period. Loans without a renewal date are not listed.</p></div><span class="pill">Showing due within <span id="rDays">10</span> days</span></div>
<div class="grid stats3"><div class="card"><div class="label">Due today</div><div class="value" id="rToday">0</div></div><div class="card"><div class="label">Upcoming</div><div class="value" id="rUp">0</div></div><div class="card"><div class="label">Overdue</div><div class="value" id="rOver">0</div></div></div>
<div class="toolbar" style="margin-top:15px">${row('rSearch', 'Search ledger, customer or mobile…', 'type="search"')}<select id="rFilter" class="btn" aria-label="Filter"><option value="">All active loans</option><option>Due Today</option><option>Upcoming</option><option>Overdue</option></select></div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Ledger / Customer</th><th>Mobile</th><th>Loan amount</th><th>Renewal date</th><th>State</th><th>Action</th><th>Reminder</th></tr></thead><tbody id="rBody"></tbody></table></div></div>
<div class="titleline" style="margin-top:22px"><div><h2>Renewed &amp; closed loans</h2><p>Archived records keep the customer’s history.</p></div></div>
<div class="card tablecard"><div class="tablewrap"><table><thead><tr><th>Ledger / Customer</th><th>Loan amount</th><th>Renewal date</th><th>Record state</th><th>Linked loan</th></tr></thead><tbody id="rArch"></tbody></table></div></div>`;
      ['rSearch', 'rFilter'].forEach(i => $(i).addEventListener('input', () => this.render()));
      $('page-renewals').addEventListener('click', e => { const b = e.target.closest('[data-manage],[data-rem],[data-arch]'); if (!b) return; if (b.dataset.manage) F.renewal(b.dataset.manage); else if (b.dataset.rem) F.reminder(b.dataset.rem); else F.loanView(b.dataset.arch); });
    },
    render() {
      const D = db(), td = today(), q = val('rSearch').toLowerCase(), f = $('rFilter').value, all = C.renewalList(D, td);
      set('rDays', D.settings.reminderDays); set('rToday', all.filter(x => C.renewalState(x, td) === 'Due Today').length); set('rUp', all.filter(x => C.renewalState(x, td) === 'Upcoming').length); set('rOver', all.filter(x => C.renewalState(x, td) === 'Overdue').length);
      const a = all.filter(x => [x.ledger, custName(x.cid), GD.cust(x.cid).mobile].some(v => String(v || '').toLowerCase().includes(q)) && (!f || C.renewalState(x, td) === f));
      $('rBody').innerHTML = a.map(x => { const s = C.renewalState(x, td); return `<tr><td><b>${esc(x.ledger)}</b><small>${esc(custName(x.cid))}</small></td><td>${esc(GD.cust(x.cid).mobile || '—')}</td><td>${money(x.amount)}</td><td>${fmt(x.renewal)}</td><td><span class="status ${s === 'Overdue' ? 'unpaid' : s === 'Due Today' ? 'partial' : 'due'}">${s}</span></td><td><button class="btn small" data-manage="${x.id}">Renew / Close</button></td><td><button class="btn small wa" data-rem="${x.id}">Reminder</button></td></tr>`; }).join('') || `<tr><td colspan="7">${empty('No renewals due', 'Nothing is overdue or due in the next ' + D.settings.reminderDays + ' days.')}</td></tr>`;
      $('rArch').innerHTML = C.renewalArchive(D).map(x => { const nx = D.loans.find(l => l.id === x.renewedTo), pv = D.loans.find(l => l.id === x.renewedFrom); return `<tr class="touchrow" data-arch="${x.id}"><td><b>${esc(x.ledger)}</b><small>${esc(custName(x.cid))}</small></td><td>${money(x.amount)}</td><td>${fmt(x.renewal)}</td><td><span class="pill">${esc(x.renewalStatus)}</span></td><td>${nx ? 'Renewed as ' + esc(nx.ledger) : pv ? 'Renewal of ' + esc(pv.ledger) : '—'}</td></tr>`; }).join('') || `<tr><td colspan="5">${empty('No renewed or closed loans yet')}</td></tr>`;
    }
  };
  F.renewal = id => {
    const l = db().loans.find(x => x.id === id); if (!l) return;
    GD.openModal({ title: 'Manage loan renewal', sub: l.ledger + ' · ' + custName(l.cid) + ' · due ' + fmt(l.renewal), save: 'Save', body: `<div class="formgrid"><div class="field full"><label for="rnAct">Action</label><select id="rnAct"><option value="renew">Renew — create the new loan record</option><option value="sent">Loan completed / gold sent off</option><option value="closed">Close loan (no further renewal)</option></select></div>
<div id="rnNew" class="formgrid full" style="grid-column:1/-1"><div class="field"><label for="rnLedger">New ledger number *</label><input id="rnLedger"></div><div class="field"><label for="rnAmt">New loan amount (₹) *</label><input id="rnAmt" type="number" step=".01" value="${l.amount}"></div><div class="field"><label for="rnDate">Renewal (new loan) date</label><input id="rnDate" type="date" value="${today()}"></div><div class="field"><label for="rnNext">Next renewal due date</label><input id="rnNext" type="date" value="${C.addDays(today(), 365)}"></div>
<label class="check full"><input type="checkbox" id="rnFee"> Appraiser charge applies to this renewal (creates income and a helper settlement)</label></div>
<div class="field full"><label for="rnNote">Note (optional)</label><input id="rnNote"></div></div><div class="notice" style="margin-top:12px">Renewing archives this loan and links the new loan to the same customer. Earlier loans and their images stay in the customer’s history.</div>`,
      onOpen: () => { $('rnAct').onchange = () => { $('rnNew').style.display = $('rnAct').value === 'renew' ? '' : 'none'; }; },
      onSave: () => {
        const a = $('rnAct').value, note = val('rnNote'), now = today();
        if (a === 'renew') {
          const ledger = val('rnLedger'), amt = Number($('rnAmt').value), d = $('rnDate').value, nx = $('rnNext').value;
          if (!ledger) throw new Error('Enter the new ledger number.'); if (!(amt > 0)) throw new Error('Enter the new loan amount.'); if (!C.isISO(d) || !C.isISO(nx)) throw new Error('Enter valid dates.'); if (nx <= d) throw new Error('The next renewal date must be after the renewal date.');
          if (db().loans.some(x => x.ledger.toLowerCase() === ledger.toLowerCase())) throw new Error('Ledger number “' + ledger + '” already exists.');
          St.commit(D => { const charge = $('rnFee').checked ? C.calcFee(amt, D.settings) : 0, n = { id: C.uid('L'), cid: l.cid, ledger, amount: amt, charge, received: charge, receipts: charge ? [{ id: C.uid('R'), date: d, amount: charge, note: 'Charge assumed received on entry' }] : [], date: d, renewal: nx, renewalStatus: 'Active', renewalHistory: [{ date: now, action: 'Renewal of ' + l.ledger, note }], notes: '', goldImage: '', appImage: '', imageIds: [], previousImageIds: [], renewedFrom: l.id };
            D.loans.unshift(n); l.renewalStatus = 'Renewed'; l.renewedTo = n.id; l.renewalHistory.push({ date: now, previousDate: l.renewal, action: 'Renewed as ' + ledger, note }); St.touch('loans', n, 'Created', 'Renewal of ' + l.ledger); St.touch('loans', l, 'Renewed', 'New ledger ' + ledger); });
          GD.toast('Renewed — new loan ' + ledger + ' linked to the same customer');
        } else { St.commit(() => { l.renewalStatus = a === 'sent' ? 'Sent off / completed' : 'Closed Loan'; l.renewalHistory.push({ date: now, previousDate: l.renewal, action: l.renewalStatus, note }); St.touch('loans', l, l.renewalStatus); }); GD.toast('Loan archived'); }
      } });
  };
  /* ---- reminder image preview / download / share ---- */
  F.reminder = id => {
    const l = db().loans.find(x => x.id === id); if (!l) return; const c = GD.cust(l.cid), s = db().settings, rem = s.reminder;
    const opts = () => ({ ref: val('mRef'), name: c.name, account: l.ledger, amount: l.amount, loanDate: l.date, dueDate: l.renewal, gross: val('mGross'), nett: val('mNett'), items: val('mItems'), notice: $('mNotice').value, branch: s.branchName + ' ( ' + s.branchCode + ' )', fontScale: Number($('mFont').value) || 1, rows: { due: $('mDue').checked, gross: $('mGr').checked, nett: $('mNe').checked, items: $('mIt').checked } });
    let blob = null, timer;
    const draw = async () => { if (!$('mImg')) return; const st = $('mState'); st.innerHTML = '<span class="spinner"></span> Creating image…'; try { const r = await root.GDReminder.render(opts()); if (!$('mImg')) return; blob = r.blob; $('mImg').src = URL.createObjectURL(blob); st.textContent = r.width + ' × ' + r.height + ' px PNG'; ['mDl', 'mWa'].forEach(i => { $(i).disabled = false; }); } catch (e) { if (!$('mImg')) return; blob = null; st.innerHTML = '<span class="errc">Could not create the image: ' + esc(e.message || e) + '</span>'; ['mDl', 'mWa'].forEach(i => { $(i).disabled = true; }); } };
    GD.openModal({ title: 'Renewal reminder', sub: l.ledger + ' · ' + c.name + ' · ' + (c.mobile || 'no mobile number'), wide: true, hideSave: true, cancel: 'Close', body: `<div class="remprev"><div><img id="mImg" alt="Reminder preview"><div class="sub" id="mState" style="margin-top:6px"></div></div><div class="opts">
<div class="actions" style="gap:14px"><button class="btn primary" id="mDl" disabled>↓ Download Image</button><button class="btn wa" id="mWa" disabled>Share on WhatsApp</button></div><p class="sub" style="margin:-4px 0 8px">Share sends the PNG itself through your device’s share sheet (pick the customer’s WhatsApp chat). Where the browser cannot share files, the image is copied and the customer’s chat is opened so you can paste it.</p>
<div class="field"><label for="mRef">Ref no. (optional)</label><input id="mRef"></div>
<div class="check-row"><label class="check"><input type="checkbox" id="mDue" ${rem.due ? 'checked' : ''}> Due date row</label> <label class="check"><input type="checkbox" id="mGr" ${rem.gross ? 'checked' : ''}> Gross weight</label> <label class="check"><input type="checkbox" id="mNe" ${rem.nett ? 'checked' : ''}> Nett weight</label> <label class="check"><input type="checkbox" id="mIt" ${rem.items ? 'checked' : ''}> No. of items</label></div>
<div class="formgrid"><div class="field"><label for="mGross">Gross weight</label><input id="mGross" type="number" step=".001"></div><div class="field"><label for="mNett">Nett weight</label><input id="mNett" type="number" step=".001"></div><div class="field"><label for="mItems">No. of items</label><input id="mItems" type="number"></div><div class="field"><label for="mFont">Font size</label><select id="mFont">${[0.8, 0.9, 1, 1.1, 1.2, 1.4].map(v => `<option value="${v}" ${v === (rem.fontScale || 1) ? 'selected' : ''}>${Math.round(v * 100)}%</option>`).join('')}</select></div></div>
<div class="field"><label for="mNotice">Notice message</label><textarea id="mNotice" rows="7"></textarea></div><button class="btn small" id="mSave" type="button">Save these options as default</button></div></div>`,
      onOpen: b => {
        $('mNotice').value = rem.notice || C.TAMIL_NOTICE; const again = () => { clearTimeout(timer); timer = setTimeout(draw, 250); };
        b.querySelectorAll('input,textarea,select').forEach(i => i.addEventListener('input', again)); draw();
        $('mDl').onclick = () => { if (blob) root.GDReminder.download(blob, 'renewal-' + l.ledger.replace(/[^\w-]/g, '_') + '.png'); };
        $('mWa').onclick = async () => { if (!blob) return; try { const r = await root.GDReminder.share(blob, { filename: 'renewal-' + l.ledger.replace(/[^\w-]/g, '_') + '.png', text: $('mNotice').value, mobile: c.mobile }); } catch (e) { GD.toast('Could not share: ' + e.message, 'err'); } };
        $('mSave').onclick = () => { St.commit(D => { D.settings.reminder = { due: $('mDue').checked, gross: $('mGr').checked, nett: $('mNe').checked, items: $('mIt').checked, fontScale: Number($('mFont').value) || 1, notice: $('mNotice').value }; }); St.touchSettings(); GD.toast('Reminder options saved'); };
      } });
  };

  /* ================= GOLD RATE ================= */
  let posterURL = '', posterBlob = null, posterKey = '';
  GD.pages.rates = {
    mount() {
      $('page-rates').innerHTML = `<div class="sectionhead"><div><div class="eyebrow">Daily reference</div><h1>Gold Rate Card</h1><p>Refresh reads the 22K rate from the PNB Digital Gold Loan website when your browser allows it. You can always enter the rate by hand.</p></div></div>
<div class="posterbox"><div><img id="pImg" alt="Gold loan rates poster"><div class="sub" id="pState" style="margin-top:6px"></div></div><div class="card"><div class="titleline"><div><h2>Rate details</h2><p>Poster date: <b id="pDate"></b> — moves to the next day at 7 PM.</p></div></div>
<div class="field" style="margin-bottom:12px"><label for="pRate">Market rate per gram (₹) *</label><input id="pRate" type="number" min="0" step="1" inputmode="numeric"></div>
<div class="formgrid"><div class="field"><label for="pAgri">Agri advance (%)</label><input id="pAgri" type="number" min="1" max="100" step=".01"></div><div class="field"><label for="pNon">Non-Agri advance (%)</label><input id="pNon" type="number" min="1" max="100" step=".01"></div></div>
<div class="rateline" style="color:var(--ink);border-color:var(--line)"><span>Agri advance</span><b id="pAV">₹0</b></div><div class="rateline" style="color:var(--ink);border-color:var(--line)"><span>Non-Agri advance</span><b id="pNV">₹0</b></div>
<div class="actions" style="margin-top:14px"><button class="btn primary" id="pRefresh">↻ Refresh from PNB</button></div><div class="sub" id="pFetchInfo" style="margin:8px 0"></div><div class="field" style="margin:8px 0"><label for="pRelay">Rate relay URL (your Cloudflare Worker address)</label><div style="display:flex;gap:8px"><input id="pRelay" placeholder="https://gold-rate.yourname.workers.dev" style="flex:1"><button class="btn small" id="pRelaySave" type="button">Save</button><button class="btn small" id="pRelayTest" type="button">Test</button></div></div><div class="actions"><button class="btn teal" id="pSave">Save rate</button><button class="btn" id="pShare">Open WhatsApp chat</button><button class="btn" id="pDl">↓ Download image</button><button class="btn wa" id="pWa">Share on WhatsApp</button></div><p class="sub" style="margin-top:10px">Download and share use the poster exactly as previewed.</p></div></div>`;
      let t; const again = () => { clearTimeout(t); t = setTimeout(() => this.draw(), 200); };
      ['pRate', 'pAgri', 'pNon'].forEach(i => $(i).addEventListener('input', again));
      $('pSave').onclick = () => { const r = Number($('pRate').value), a = Number($('pAgri').value), n = Number($('pNon').value); if (!(r > 0)) return GD.toast('Enter the market rate per gram.', 'err'); if (!(a > 0 && a <= 100 && n > 0 && n <= 100)) return GD.toast('Percentages must be between 1 and 100.', 'err'); St.commit(D => { Object.assign(D.settings, { rate: r, agriPercent: a, nonAgriPercent: n, rateSavedFor: C.rateDate(new Date()) }); }); St.touchSettings(); GD.toast('Rate saved'); };
      $('pDl').onclick = async () => { if (!(Number($('pRate').value) > 0)) return GD.toast('Enter the market rate first.', 'err'); if (await this.draw(true)) GD.download(posterBlob, 'PNB-Gold-Loan-Rates-' + C.rateDate(new Date()) + '.png'); };
      $('pWa').onclick = async () => { if (!(Number($('pRate').value) > 0)) return GD.toast('Enter the market rate first.', 'err'); if (!await this.draw(true)) return; const d = C.rateDate(new Date()).split('-').reverse().join('.'), txt = 'PNB Gold Loan Rates ' + d + '\nMarket rate: ₹' + root.GDPoster.inr(Number($('pRate').value)) + '/-'; try { const r = await root.GDReminder.share(posterBlob, { filename: 'PNB-Gold-Loan-Rates-' + C.rateDate(new Date()) + '.png', text: txt, mobile: db().settings.rateWhatsapp }); } catch (e) { GD.toast('Could not share: ' + e.message, 'err'); } };
      setInterval(() => { if (GD.current === 'rates' && posterKey && !posterKey.startsWith(C.rateDate(new Date()))) this.draw(); }, 30000);
    },
    enter() { const s = db().settings; $('pRate').value = s.rate || ''; $('pAgri').value = s.agriPercent; $('pNon').value = s.nonAgriPercent; this.draw(); },
    render() {},
    async draw(force) {
      const r = Number($('pRate').value) || 0, a = Number($('pAgri').value) || 0, n = Number($('pNon').value) || 0, d = C.rateDate(new Date());
      set('pDate', d.split('-').reverse().join('.')); set('pAV', money(Math.round(r * a / 100))); set('pNV', money(Math.round(r * n / 100)));
      if (!(a > 0 && n > 0)) return false; if (!r) { set('pState', 'Enter the market rate to build the poster.'); }
      const key = [d, r, a, n].join('|'); if (key === posterKey && posterBlob && !force) return true;
      try { const c = await root.GDPoster.render({ date: d, rate: r, agriPct: a, nonAgriPct: n }); posterBlob = await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('Image encoding failed')), 'image/png')); if (posterURL) URL.revokeObjectURL(posterURL); posterURL = URL.createObjectURL(posterBlob); $('pImg').src = posterURL; posterKey = key; if (r) set('pState', c.width + ' × ' + c.height + ' px PNG'); return true; }
      catch (e) { set('pState', 'Could not build the poster: ' + (e.message || e)); GD.toast('Poster failed: ' + (e.message || e), 'err'); return false; }
    }
  };
  /* ---- Refresh the market rate. Tries the site directly, then your relay, then public relays. Only a validated 22K value is saved. ---- */
  (function () {
    const R = GD.pages.rates, m = R.mount, en = R.enter, SRC = 'https://digigoldloan.pnb.bank.in/GoldLoan/Processor/CustomerLogin';
    /* The PNB page shows e.g. "Gold Rate: 22 carat = ₹13934/gm". */
    const parse = html => { const t = String(html).replace(/<[^>]+>/g, ' ').replace(/&#8377;|&#x20B9;|&rupee;/gi, '₹').replace(/&nbsp;/g, ' '), x = t.match(/22\s*(?:carat|karat|ct|k)\s*[=:\-–]?\s*(?:₹|Rs\.?|INR)?\s*([\d,]+(?:\.\d{1,2})?)\s*\/\s*(?:gm|gms|g|gram)/i); return x ? Math.round(Number(x[1].replace(/,/g, ''))) : 0; };
    const info = () => { const S = db().settings; set('pFetchInfo', S.rateFetchedAt ? 'Last updated from PNB: ' + new Date(S.rateFetchedAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }) + (S.rateVia ? ' (via ' + S.rateVia + ')' : '') + ' · the PNB page publishes no timestamp, so this is the time it was read.' : 'Press Refresh to fetch the latest PNB rate, or type it below.'); };
    /* Order: your own relay (Cloudflare Worker, see Settings → Rate fetch proxy), then a direct request.
       Public proxies are intentionally not used. */
    async function getRate() {
      const S = db().settings, tries = [], list = [...(S.rateProxy ? [S.rateProxy] : []), 'direct'], hasRelay = !!S.rateProxy;
      for (const rl of list) {
        const name = rl === 'direct' ? 'direct request to digigoldloan.pnb.bank.in' : (() => { try { return new URL(rl.replace('{url}', 'x')).hostname; } catch (e) { return 'your relay'; } })(), ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 15000);
        try {
          const u = rl === 'direct' ? SRC + '?_=' + Date.now() : rl.includes('{url}') ? rl.replace('{url}', encodeURIComponent(SRC + '?_=' + Date.now())) : rl + (rl.includes('?') ? '&' : '?') + '_=' + Date.now();
          const r = await fetch(u, { signal: ctl.signal, cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status);
          const body = await r.text(); let rate = 0, at = '';
          try { const j = JSON.parse(body); if (j && j.rate) { rate = Math.round(Number(j.rate)); at = j.fetchedAt || ''; } } catch (e) { rate = parse(body); }
          if (rate) return { rate, via: name, at }; tries.push(name + ': the 22 carat rate was not found in the response (PNB may have changed the page)');
        } catch (e) { tries.push(name + ': ' + (e.name === 'AbortError' ? 'timed out after 15 s' : e instanceof TypeError ? (rl === 'direct' ? 'blocked by the browser (the PNB site does not allow other websites to read it — CORS)' : 'could not reach the relay (offline, wrong address, or relay blocked)') : e.message)); } finally { clearTimeout(to); }
      }
      if (!hasRelay) tries.push('No relay is configured. Deploy the free Cloudflare Worker (gold-rate-worker.js) and paste its address in Settings → Rate fetch proxy.');
      throw new Error(tries.join(' · '));
    }
    async function fetchRate() {
      const b = $('pRefresh'), S = db().settings; b.disabled = true; set('pFetchInfo', 'Fetching the latest rate…');
      try {
        const { rate, via, at } = await getRate(), prev = Number(S.rate) || 0;
        if (!(rate >= 1000 && rate <= 100000)) throw new Error('The value found (₹' + rate + ') is not a plausible gold rate, so it was ignored.');
        if (prev && Math.abs(rate - prev) / prev > 0.3) throw new Error('The fetched rate ₹' + rate + ' differs from your saved ₹' + prev + ' by more than 30%, so it was not applied. Enter it by hand if it is correct.');
        St.commit(D => { Object.assign(D.settings, { rate, rateSavedFor: C.rateDate(new Date()), rateFetchedAt: at && !isNaN(new Date(at)) ? new Date(at).toISOString() : new Date().toISOString(), rateVia: via }); }); St.touchSettings(); await St.flush();
        if (St.state.storageError) throw new Error(St.state.storageError);
        $('pRate').value = rate; await R.draw(true); info(); GD.toast('Rate updated: ₹' + rate + ' per gram (22K)');
      } catch (e) { info(); $('pFetchInfo').innerHTML += '<div class="errc" style="margin-top:4px">Could not update the rate — your saved rate is unchanged. ' + esc(e.message) + '</div>'; GD.toast('Rate not updated', 'err'); }
      finally { b.disabled = false; }
    }
    R.mount = function () { m.call(this); $('pRefresh').onclick = fetchRate;
      $('pRelaySave').onclick = async () => { const v = $('pRelay').value.trim(); if (v && !/^(https:\/\/|http:\/\/localhost)/i.test(v)) return GD.toast('The relay address must start with https://', 'err'); St.commit(D => { D.settings.rateProxy = v; }); St.touchSettings(); await St.flush(); GD.toast(v ? 'Relay address saved' : 'Relay address cleared'); };
      $('pRelayTest').onclick = async () => { const v = $('pRelay').value.trim(); if (!v) return GD.toast('Enter the relay address first.', 'err'); try { const r = await fetch(v + (v.includes('?') ? '&' : '?') + '_=' + Date.now(), { cache: 'no-store' }), j = await r.json(); if (j.rate) GD.toast('Relay works: 22 carat = ₹' + j.rate + '/g (not saved — press Refresh)'); else GD.toast('Relay reached but: ' + (j.error || 'no rate returned'), 'err'); } catch (e) { GD.toast('Relay test failed: ' + (e instanceof TypeError ? 'cannot reach it (wrong address, not deployed, or blocked)' : e.message), 'err'); } };
      $('pShare').onclick = async () => { if (!(Number($('pRate').value) > 0)) return GD.toast('Enter the market rate first.', 'err'); if (!await R.draw(true)) return; try { const r = await root.GDReminder.share(posterBlob, { filename: 'PNB-Gold-Loan-Rates-' + C.rateDate(new Date()) + '.png', text: 'PNB Gold Loan Rates', mobile: db().settings.rateWhatsapp, chat: true }); } catch (e) { GD.toast('Could not share: ' + e.message, 'err'); } }; };
    R.enter = function () { en.call(this); $('pRelay').value = db().settings.rateProxy || ''; info(); };
  })();
})(window);
