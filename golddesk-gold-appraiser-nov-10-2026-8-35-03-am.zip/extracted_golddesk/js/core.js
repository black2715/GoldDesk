/* GoldDesk Professional — core business logic.
   Pure functions only (no DOM, no storage) so the same code runs in the browser and in Node tests.
   Money is handled in rupees rounded to 2 decimals; dates are local calendar dates as 'YYYY-MM-DD'. */
(function (root) {
  'use strict';

  const SCHEMA = 5;
  const pad = n => String(n).padStart(2, '0');
  const toISO = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parseISO = s => { const [y, m, d] = String(s).split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (iso, n) => { const d = parseISO(iso); d.setDate(d.getDate() + n); return toISO(d); };
  const round2 = n => { n = Number(n) || 0; return Math.round((n + (n >= 0 ? 1e-9 : -1e-9)) * 100) / 100; };
  const uid = p => (p || 'id') + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const isISO = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && toISO(parseISO(s)) === s;
  const isSunday = iso => parseISO(iso).getDay() === 0;

  const DEFAULT_SETTINGS = {
    appraiser1Name: 'Aravindhan', appraiser2Name: 'Appraiser 2', helperName: 'Vengatesan',
    split1: 37.5, split2: 37.5, splitHelper: 25,
    bankMode: 'percent', bankShareValue: 50,
    feeMode: 'fixed', feeStandard: 500, feeHigh: 1000, feeThreshold: 500000, feePercent: 0.2, feeMin: 0, feeMax: 0,
    packetRate: 100, reminderDays: 10, rateWhatsapp: '', rateProxy: '', rateFetchedAt: '', rateVia: '',
    agriPercent: 85, nonAgriPercent: 68, rate: 0, rateSavedFor: '',
    branchName: 'CUDDALORE', branchCode: '010400',
    reminder: { gross: false, nett: false, items: false, due: true, fontScale: 1, notice: '' }
  };

  const TAMIL_NOTICE =
    'வணக்கம்,\n\nதங்களது நகைக் கடனுக்கான காலக்கெடு (Due Date) விரைவில் முடிவடைய உள்ளது. எனவே, காலக்கெடு முடிவடைவதற்கு முன்பாக நிலுவைத் தொகையைச் செலுத்தி அடமான நகையை மீட்டுக்கொள்ளுமாறு கேட்டுக்கொள்கிறோம்.\n\nகடனைப் புதுப்பித்துக் கொள்ள (Renewal) விரும்பினால், வங்கிக் கிளையை அணுகுங்கள். வங்கிக்கு வரும்போது ஆதார் அட்டை மற்றும் பான் கார்டின் நகலை தவறாமல் கொண்டு வாருங்கள். நன்றி!';

  const mergeSettings = s => {
    const o = Object.assign({}, DEFAULT_SETTINGS, s || {});
    o.reminder = Object.assign({}, DEFAULT_SETTINGS.reminder, (s && s.reminder) || {});
    if (s && s.appraiserName && !s.appraiser1Name) o.appraiser1Name = s.appraiserName; // legacy key
    delete o.appraiserName;
    return o;
  };
  const emptyDB = () => ({ schema: SCHEMA, customers: [], loans: [], inspections: [], settlements: [], receivables: [], holidays: [], a2payments: [], payments: [], payMigrated: false, settings: mergeSettings(), audit: [] });

  /* ---------- Date rules ---------- */
  // Rate-card date: today, or tomorrow once the clock passes 7 PM.
  const rateDate = (now) => { now = now || new Date(); const d = new Date(now); if (d.getHours() >= 19) d.setDate(d.getDate() + 1); return toISO(d); };
  // Week = Monday..Saturday. Month/Year = calendar month/year. Day = the date itself.
  function weekBounds(ref) { const d = parseISO(ref), back = (d.getDay() + 6) % 7, a = new Date(d); a.setDate(d.getDate() - back); const b = new Date(a); b.setDate(a.getDate() + 5); return [toISO(a), toISO(b)]; }
  function bounds(period, ref) {
    const d = parseISO(ref);
    if (period === 'week') return weekBounds(ref);
    if (period === 'month') return [toISO(new Date(d.getFullYear(), d.getMonth(), 1)), toISO(new Date(d.getFullYear(), d.getMonth() + 1, 0))];
    if (period === 'year') return [d.getFullYear() + '-01-01', d.getFullYear() + '-12-31'];
    return [ref, ref];
  }
  const within = (d, a, b) => !!d && d >= a && d <= b;
  function eachDay(a, b) { const out = []; for (let d = parseISO(a), e = parseISO(b); d <= e; d.setDate(d.getDate() + 1)) out.push(toISO(d)); return out; }

  /* ---------- Loan charge and income split ---------- */
  // Whole-rupee rule: fraction < .50 down, >= .50 up. Allocations use full precision, then the largest-remainder
  // method so parts always add up to the rounded charge; exact ties go to Appraiser 1, then Appraiser 2, then Helper.
  const rupee = n => { n = Number(n) || 0; return n >= 0 ? Math.floor(n + 0.5 + 1e-9) : -Math.floor(-n + 0.5 + 1e-9); };
  function calcFee(amount, S) {
    amount = Number(amount) || 0;
    let f = S.feeMode === 'percent' ? amount * S.feePercent / 100 : (amount > S.feeThreshold ? S.feeHigh : S.feeStandard);
    if (S.feeMin > 0) f = Math.max(f, S.feeMin);
    if (S.feeMax > 0) f = Math.min(f, S.feeMax);
    return rupee(f);
  }
  // charge → each party's share. The helper allocation is borne wholly by Appraiser 1; Appraiser 2 pays nothing toward it; the
  // appraisers' own shares are NOT reduced by it (no double deduction).
  function splitCharge(charge, S) {
    const total = Math.max(0, rupee(charge)), raw = [S.split1, S.split2, S.splitHelper].map(p => total * (Number(p) || 0) / 100);
    const part = raw.map(Math.floor); let rest = total - part.reduce((a, b) => a + b, 0);
    [0, 1, 2].sort((i, j) => (Math.round((raw[j] - part[j]) * 1e6) - Math.round((raw[i] - part[i]) * 1e6)) || i - j).forEach(i => { if (rest > 0) { part[i]++; rest--; } });
    const [a1, a2, helper] = part, payA1 = helper, payA2 = 0; /* Helper's share is borne entirely by Appraiser 1 */
    return { charge: total, a1, a2, helper, payA1, payA2 };
  }
  const loanA1Income = (x, S) => splitCharge(x.charge, S).a1;
  function inspectionBankPart(x, S) {
    const r = Number(x.received) || 0;
    return S.bankMode === 'fixed' ? Math.min(r, Number(S.bankShareValue) || 0) : rupee(r * (Number(S.bankShareValue) || 0) / 100);
  }
  const inspectionA1Income = (x, S) => Math.max(0, round2((Number(x.received) || 0) - inspectionBankPart(x, S)));
  const inspectionCharge = (packets, rate) => round2((Number(packets) || 0) * (Number(rate) || 0));
  const balance = x => Math.max(0, round2((Number(x.charge) || 0) - (Number(x.received) || 0)));
  const payStatus = x => (Number(x.received) || 0) <= 0 ? 'Unpaid' : (Number(x.received) >= Number(x.charge) ? 'Paid' : 'Partially Paid');

  /* ---------- Income events (single source for every total) ---------- */
  function incomeEvents(DB) {
    const S = DB.settings, e = [];
    DB.loans.forEach(x => { const v = loanA1Income(x, S); if (v) e.push({ date: x.date, amount: v, type: 'Loan income', ref: x.ledger, kind: 'loan' }); });
    DB.inspections.forEach(x => { const v = inspectionA1Income(x, S); if (v) e.push({ date: x.date, amount: v, type: 'Inspection income', ref: x.branch, kind: 'inspection' }); });
    DB.receivables.forEach(r => {
      e.push({ date: r.sourceDate, amount: -Number(r.amount || 0), type: 'Pending adjustment', ref: r.description || r.id, kind: 'adjust' });
      (r.payments || []).forEach(p => e.push({ date: p.date, amount: Number(p.amount || 0), type: 'Pending received', ref: r.description || r.id, kind: 'adjust' }));
    });
    return e;
  }
  const sumEvents = (ev, a, b, kind) => round2(ev.filter(e => within(e.date, a, b) && (!kind || e.kind === kind)).reduce((n, e) => n + e.amount, 0));
  const incomeBetween = (DB, a, b) => sumEvents(incomeEvents(DB), a, b);

  /* Aggregates for dashboard / analytics. `today` is injected for testability. */
  function totals(DB, today) {
    const S = DB.settings, ev = incomeEvents(DB), W = bounds('week', today), M = bounds('month', today), Y = bounds('year', today);
    const all = ['0000-01-01', '9999-12-31'];
    const loanPool = round2(DB.loans.reduce((n, x) => n + (Number(x.charge) || 0), 0));
    const parts = DB.loans.reduce((n, x) => { const s = splitCharge(x.charge, S); n.a1 += s.a1; n.a2 += s.a2; n.helper += s.helper; return n; }, { a1: 0, a2: 0, helper: 0 });
    const months = new Set(ev.filter(e => e.date).map(e => e.date.slice(0, 7)));
    let avgMonthly = 0;
    if (months.size) { const first = [...months].sort()[0], [fy, fm] = first.split('-').map(Number), [ty, tm] = today.split('-').map(Number); const n = (ty - fy) * 12 + (tm - fm) + 1; avgMonthly = round2(sumEvents(ev, all[0], all[1]) / Math.max(1, n)); }
    const inspAll = sumEvents(ev, all[0], all[1], 'inspection');
    const AC = accounts(DB), helperPending = AC.helperPending;
    const WS = addDays(W[0], 6); // payments made on Sunday still belong to that week
    const helperPaidWeek = round2((DB.payments || []).filter(p => p.status !== 'reversed' && p.acct !== 'a2' && within(p.date, W[0], WS)).reduce((n, p) => n + p.amount, 0));
    const pendLoans = round2(DB.loans.reduce((n, x) => n + balance(x), 0));
    const a2Unpaid = AC.a2.pending;
    const pendInsp = round2(DB.inspections.reduce((n, x) => n + balance(x), 0));
    const pendRec = round2(DB.receivables.reduce((n, r) => n + Math.max(0, r.amount - (r.paid || 0)), 0));
    return {
      week: sumEvents(ev, W[0], W[1]), month: sumEvents(ev, M[0], M[1]), year: sumEvents(ev, Y[0], Y[1]), total: sumEvents(ev, all[0], all[1]),
      inspectionMonth: sumEvents(ev, M[0], M[1], 'inspection'), inspectionTotal: inspAll, avgMonthly,
      loanPool, a1Loan: round2(parts.a1), a2Share: round2(parts.a2), helperAllocation: round2(parts.helper),
      a2Unpaid, helperPending, helperPaidWeek, pendLoans, pendInsp, pendRec, pendingToReceive: round2(pendLoans + pendInsp + pendRec),
      sundayIncome: round2(ev.filter(e => e.date && isSunday(e.date)).reduce((n, e) => n + e.amount, 0)), weekRange: W
    };
  }
  /* ---------- Settlement running accounts ----------
     Each loan stores an allocation snapshot (loan.alloc) taken when the loan is saved, so later percentage changes never alter old loans.
     a2 = payable to Appraiser 2; hA1 = Helper's allocation, borne wholly by Appraiser 1 (hA2 is legacy only: always 0 accrued; its old payments count toward the Helper total). Pending = accrued − active payments. */
  const ACCTS = ['a2', 'hA1', 'hA2'];
  function snapshotAlloc(DB) {
    DB.loans.forEach(x => { const c = Math.max(0, rupee(x.charge)); if (!x.alloc || x.alloc.charge !== c) { const p = splitCharge(x.charge, DB.settings); x.alloc = { charge: p.charge, a2: p.a2, helper: p.helper, payA1: p.payA1, payA2: p.payA2 }; } });
  }
  function migratePayments(DB, now) {
    if (DB.payMigrated) return; DB.payments = DB.payments || []; const have = new Set(DB.payments.map(p => p.id));
    const add = (id, acct, date, amount, note) => { amount = Number(amount) || 0; if (!have.has(id) && amount > 0 && isISO(date)) { have.add(id); DB.payments.push({ id, acct, date, amount: round2(amount), note, status: 'active', createdAt: now, updatedAt: now, history: [{ at: now, action: 'Migrated from earlier version', amount, date }] }); } };
    DB.settlements.forEach(t => { if (t.status === 'paid') add('MIG-' + t.id + '-hA1', 'hA1', t.paidDate, t.paidAmount, 'Earlier helper settlement'); if (t.a2Status === 'paid') add('MIG-' + t.id + '-a2', 'a2', t.a2PaidDate, t.a2PaidAmount, 'Earlier settlement'); });
    (DB.a2payments || []).forEach(p => add('MIG-' + p.id, 'a2', p.date, p.amount, p.note || 'Earlier payment'));
    DB.payMigrated = true;
  }
  function accounts(DB) {
    const A = { a2: { accrued: 0, paid: 0 }, hA1: { accrued: 0, paid: 0 }, hA2: { accrued: 0, paid: 0 } };
    DB.loans.forEach(l => { const a = l.alloc || splitCharge(l.charge, DB.settings); A.a2.accrued += a.a2; A.hA1.accrued += a.helper; });
    (DB.payments || []).forEach(p => { if (p.status !== 'reversed' && A[p.acct]) A[p.acct === 'hA2' ? 'hA1' : p.acct].paid += Number(p.amount) || 0; });
    ACCTS.forEach(k => { const x = A[k]; x.accrued = round2(x.accrued); x.paid = round2(x.paid); x.pending = Math.max(0, round2(x.accrued - x.paid)); x.advance = Math.max(0, round2(x.paid - x.accrued)); });
    A.helperPending = round2(A.hA1.pending + A.hA2.pending); return A;
  }
  function checkPayment(DB, o, ignoreId) {
    if (!ACCTS.includes(o.acct)) throw new Error('Choose an account.'); if (!(Number(o.amount) > 0)) throw new Error('Enter an amount greater than zero.'); if (!isISO(o.date)) throw new Error('Enter a valid payment date.');
    const A = accounts(DB)[o.acct], own = ignoreId ? ((DB.payments.find(p => p.id === ignoreId && p.status !== 'reversed') || {}).amount || 0) : 0, room = round2(A.accrued - (A.paid - own));
    if (o.amount > room + 0.005 && !o.allowOver) throw new Error('₹' + Math.max(0, room) + ' is pending, so ₹' + o.amount + ' is too much. Tick “Allow more than pending” and add a note if this is a real advance.');
    if (o.amount > room + 0.005 && !String(o.note || '').trim()) throw new Error('Add a note explaining the payment above the pending amount.');
  }
  function addPayment(DB, o, now) {
    checkPayment(DB, o); const amount = round2(o.amount);
    if ((DB.payments || []).some(p => p.status !== 'reversed' && p.acct === o.acct && p.date === o.date && p.amount === amount && now && (new Date(now) - new Date(p.createdAt)) < 10000)) throw new Error('This looks like a duplicate of the payment just recorded.');
    const p = { id: uid('PAY'), acct: o.acct, date: o.date, amount, note: String(o.note || '').trim(), status: 'active', createdAt: now, updatedAt: now, history: [{ at: now, action: 'Recorded', amount, date: o.date }] };
    DB.payments.push(p); return p;
  }
  function editPayment(DB, id, o, now) {
    const p = DB.payments.find(x => x.id === id); if (!p) throw new Error('Payment not found.'); if (p.status === 'reversed') throw new Error('A reversed payment cannot be edited.');
    checkPayment(DB, Object.assign({}, o, { acct: p.acct }), id); const amount = round2(o.amount);
    p.history.push({ at: now, action: 'Corrected', from: { amount: p.amount, date: p.date, note: p.note }, to: { amount, date: o.date, note: String(o.note || '').trim() } });
    Object.assign(p, { amount, date: o.date, note: String(o.note || '').trim(), updatedAt: now }); return p;
  }
  function reversePayment(DB, id, now) {
    const p = DB.payments.find(x => x.id === id); if (!p || p.status === 'reversed') throw new Error('Nothing to reverse.');
    p.status = 'reversed'; p.updatedAt = now; p.history.push({ at: now, action: 'Reversed', amount: p.amount, date: p.date }); return p;
  }
  // Appraiser 2 pending = allocation of every settlement not yet marked Paid (all months).
  function C_a2Unpaid(DB) { return round2(DB.settlements.reduce((n, t) => n + (t.a2Status === 'paid' ? 0 : Number(t.a2Amount) || 0), 0)); }
  function markPaidA2(t, now, date) {
    if (t.a2Status === 'paid') return t; date = date || now.slice(0, 10);
    t.a2Status = 'paid'; t.a2PaidDate = date; t.a2PaidAmount = Number(t.a2Amount) || 0; t.updatedAt = now; (t.a2History = t.a2History || []).push({ at: now, action: 'Marked paid', date, amount: t.a2PaidAmount }); return t;
  }
  function markUnpaidA2(t, now) {
    if (t.a2Status !== 'paid') return t;
    (t.a2History = t.a2History || []).push({ at: now, action: 'Reverted to unpaid', previousDate: t.a2PaidDate, previousAmount: t.a2PaidAmount });
    t.a2Status = 'unpaid'; t.a2PaidDate = ''; t.a2PaidAmount = 0; t.updatedAt = now; return t;
  }
  // Bars for a period: week → Mon..Sat (six bars), month → each day, year → 12 months, day → one bar.
  function series(DB, period, ref) {
    const ev = incomeEvents(DB);
    if (period === 'year') {
      const y = parseISO(ref).getFullYear();
      return Array.from({ length: 12 }, (_, i) => { const a = y + '-' + pad(i + 1) + '-01', b = toISO(new Date(y, i + 1, 0)); return { key: a, label: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i], value: sumEvents(ev, a, b) }; });
    }
    const [a, b] = bounds(period, ref), names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return eachDay(a, b).map(d => ({ key: d, label: period === 'week' ? names[parseISO(d).getDay()] : String(parseISO(d).getDate()), value: sumEvents(ev, d, d), sunday: isSunday(d) }));
  }

  /* ---------- Helper settlements ---------- */
  function buildSettlement(loan, S, now) {
    const sp = splitCharge(loan.charge, S);
    return { id: 'H-' + loan.id, loanId: loan.id, ledger: loan.ledger, cid: loan.cid, date: loan.date,
      helperAllocation: sp.helper, payableA1: sp.payA1, payableA2: sp.payA2, status: 'unpaid', paidDate: '', paidAmount: 0, a2Amount: sp.a2, a2Status: 'unpaid', a2PaidDate: '', a2PaidAmount: 0, a2History: [],
      history: [{ at: now, action: 'Created', allocation: sp.helper, payableA1: sp.payA1 }], createdAt: now, updatedAt: now, version: 0 };
  }
  // Every loan with a helper allocation has exactly one settlement. Unpaid records follow later
  // edits to the loan; paid records are never silently changed.
  function ensureSettlements(DB, now) {
    const S = DB.settings, changed = [];
    now = now || new Date().toISOString();
    snapshotAlloc(DB); migratePayments(DB, now);
    DB.loans.forEach(loan => {
      const sp = splitCharge(loan.charge, S);
      let t = DB.settlements.find(s => s.loanId === loan.id);
      if (!t) {
        return; // settlements are now a running account (DB.payments); no per-loan records are created
        DB.settlements.push(t = buildSettlement(loan, S, now)); changed.push(t); return;
      }
      if (t.status !== 'paid' && (t.helperAllocation !== sp.helper || t.payableA1 !== sp.payA1 || t.payableA2 !== sp.payA2 || t.ledger !== loan.ledger || t.date !== loan.date)) {
        t.history.push({ at: now, action: 'Allocation recalculated', from: t.helperAllocation, to: sp.helper });
        Object.assign(t, { helperAllocation: sp.helper, payableA1: sp.payA1, payableA2: sp.payA2, ledger: loan.ledger, date: loan.date, updatedAt: now }); changed.push(t);
      }
      if (t.a2Status == null) { Object.assign(t, { a2Amount: sp.a2, a2Status: 'unpaid', a2PaidDate: '', a2PaidAmount: 0, a2History: [] }); t.updatedAt = now; changed.push(t); }
      else if (t.a2Status !== 'paid' && t.a2Amount !== sp.a2) { t.a2Amount = sp.a2; t.updatedAt = now; changed.push(t); }
    });
    return changed;
  }
  function markPaid(t, opts, now) {
    if (t.status === 'paid') throw new Error('This settlement is already marked Paid.');
    const amount = round2(opts && opts.amount != null ? opts.amount : t.payableA1), date = (opts && opts.date) || now.slice(0, 10);
    if (!(amount > 0)) throw new Error('Paid amount must be greater than zero.');
    if (!isISO(date)) throw new Error('Enter a valid payment date.');
    t.status = 'paid'; t.paidDate = date; t.paidAmount = amount; t.updatedAt = now;
    t.history.push({ at: now, action: 'Marked paid', date, amount });
    return t;
  }
  function markUnpaid(t, now, reason) {
    if (t.status !== 'paid') throw new Error('This settlement is not marked Paid.');
    t.history.push({ at: now, action: 'Reverted to unpaid', previousDate: t.paidDate, previousAmount: t.paidAmount, reason: reason || '' });
    t.status = 'unpaid'; t.paidDate = ''; t.paidAmount = 0; t.updatedAt = now;
    return t;
  }
  const unpaidSettlements = DB => DB.settlements.filter(s => s.status !== 'paid').sort((a, b) => (b.date || '').localeCompare(a.date || '') || String(b.ledger).localeCompare(String(a.ledger)));
  const paidSettlements = DB => DB.settlements.filter(s => s.status === 'paid').sort((a, b) => b.paidDate.localeCompare(a.paidDate));
  // Year → Month → Day options for the cascading filters (by actual payment date).
  function paidTree(DB) {
    const t = {};
    paidSettlements(DB).forEach(s => { const [y, m, d] = s.paidDate.split('-'); ((t[y] = t[y] || {})[m] = t[y][m] || new Set()).add(d); });
    return t;
  }
  function filterPaid(DB, y, m, d) {
    return paidSettlements(DB).filter(s => { const [yy, mm, dd] = s.paidDate.split('-'); return (!y || yy === y) && (!m || mm === m) && (!d || dd === d); });
  }

  /* ---------- Renewals ---------- */
  const ARCHIVED = ['Renewed', 'Closed Loan', 'Sent off / completed'];
  const normalizeRenewalStatus = s => !s || s === 'Active' ? 'Active' : s === 'Closed' ? 'Closed Loan' : s;
  const isArchived = x => ARCHIVED.includes(normalizeRenewalStatus(x.renewalStatus));
  function renewalState(x, today) {
    if (isArchived(x)) return normalizeRenewalStatus(x.renewalStatus);
    if (!x.renewal) return 'No date';
    return x.renewal < today ? 'Overdue' : x.renewal === today ? 'Due Today' : 'Upcoming';
  }
  // Active renewals: overdue or due within the configured window. Loans with no renewal date are excluded.
  function renewalList(DB, today) {
    const lim = addDays(today, Number(DB.settings.reminderDays) || 0);
    return DB.loans.filter(x => !isArchived(x) && x.renewal && x.renewal <= lim).sort((a, b) => a.renewal.localeCompare(b.renewal));
  }
  const renewalArchive = DB => DB.loans.filter(isArchived);

  /* ---------- Validation & migration of backups ---------- */
  const COLLECTIONS = ['customers', 'loans', 'inspections', 'settlements', 'receivables', 'holidays', 'a2payments', 'payments'];
  function legacyToDB(d) {
    // Old GoldDesk shapes: { customers, loans, inspections, settlements, settings } or IndexedDB state { C, L, I, T, R, HP, HOL, S }.
    const o = emptyDB(), g = (a, b) => d[a] || d[b] || [];
    o.customers = g('customers', 'C').map(c => Object.assign({}, c));
    o.settings = mergeSettings(d.settings || d.S || {});
    const imgs = {};
    o.loans = g('loans', 'L').map(x => {
      const l = Object.assign({ renewalHistory: [], receipts: [] }, x);
      l.renewalStatus = normalizeRenewalStatus(l.renewalStatus); l.imageIds = l.imageIds || [];
      ['imageData1', 'imageData2'].forEach((k, i) => { if (l[k]) { const id = 'img-' + l.id + '-' + (i + 1); imgs[id] = l[k]; l.imageIds.push(id); } delete l[k]; });
      delete l.images; delete l.application; delete l.loanState;
      return l;
    });
    o.inspections = g('inspections', 'I').map(x => Object.assign({}, x));
    o.receivables = (d.receivables || d.R || []).map(r => { const n = Object.assign({}, r); (n.payments || []).forEach(p => delete p.proof); return n; });
    o.holidays = (d.holidays || d.HOL || []).map(h => Object.assign({}, h));
    const now = new Date().toISOString();
    ensureSettlements(o, now);
    // carry over legacy payment state: a legacy settlement fully paid becomes Paid
    (g('settlements', 'T')).forEach(t => {
      const s = o.settlements.find(z => z.loanId === t.loanId || (t.ledger && z.ledger === t.ledger));
      const paid = Number(t.paid) || 0, due = Number(t.fatherDue != null ? t.fatherDue : t.payableA1) || 0;
      if (s && paid > 0 && paid >= due - 0.005) {
        const last = (t.payments || []).slice(-1)[0];
        const date = (last && last.date) || t.weekEnd || (s.date) || now.slice(0, 10);
        markPaid(s, { amount: paid, date: isISO(date) ? date : now.slice(0, 10) }, now); s.history[s.history.length - 1].note = 'Migrated from earlier GoldDesk data';
      } else if (!s && !t.loanId && due > 0) {
        o.settlements.push({ id: t.id || uid('H'), loanId: '', ledger: t.ledger || '—', cid: '', date: t.weekEnd || now.slice(0, 10), helperAllocation: Number(t.helperShare) || due * 2, payableA1: due, payableA2: due, status: paid >= due ? 'paid' : 'unpaid', paidDate: paid >= due ? (t.weekEnd || now.slice(0, 10)) : '', paidAmount: paid >= due ? due : 0, history: [{ at: now, action: 'Migrated' }], createdAt: now, updatedAt: now, version: 0 });
      }
    });
    return { db: o, images: imgs };
  }
  /* Returns { ok, errors[], warnings[], db, images }. Never throws; never mutates input. */
  function validateBackup(data) {
    const errors = [], warnings = [];
    if (!data || typeof data !== 'object' || Array.isArray(data)) return { ok: false, errors: ['The file is not a GoldDesk backup (expected a JSON object).'], warnings };
    const legacy = !data.schema && (Array.isArray(data.customers) || Array.isArray(data.C));
    if (!legacy && data.format !== 'golddesk-backup') return { ok: false, errors: ['This is not a GoldDesk backup file.'], warnings };
    if (!legacy && Number(data.schema) > SCHEMA) return { ok: false, errors: ['This backup was made by a newer version of GoldDesk (schema ' + data.schema + '). Update the app before importing it.'], warnings };
    let db, images = {};
    if (legacy) { try { ({ db, images } = legacyToDB(data)); } catch (e) { return { ok: false, errors: ['Could not read this older backup: ' + e.message], warnings }; } warnings.push('Older GoldDesk backup detected. Records were converted to the current format.'); }
    else {
      db = emptyDB(); const src = data.data || {};
      COLLECTIONS.forEach(k => { if (src[k] != null && !Array.isArray(src[k])) errors.push('"' + k + '" must be a list.'); db[k] = Array.isArray(src[k]) ? src[k].map(x => Object.assign({}, x)) : []; });
      db.payMigrated = !!src.payMigrated; db.settings = mergeSettings(src.settings); db.audit = Array.isArray(src.audit) ? src.audit : [];
      images = data.images && typeof data.images === 'object' ? data.images : {};
    }
    if (errors.length) return { ok: false, errors, warnings };
    const ids = new Set(), ledgers = new Set(), cids = new Set(db.customers.map(c => c.id));
    db.customers.forEach((c, i) => { if (!c.id || !c.name) errors.push('Customer #' + (i + 1) + ' is missing an id or name.'); });
    db.loans.forEach((x, i) => {
      const tag = 'Loan ' + (x.ledger || '#' + (i + 1));
      if (!x.id || !x.ledger) errors.push(tag + ' is missing an id or ledger number.');
      if (ids.has(x.id)) errors.push(tag + ' has a duplicate id.'); ids.add(x.id);
      const lk = String(x.ledger || '').toLowerCase(); if (ledgers.has(lk)) errors.push('Duplicate ledger number: ' + x.ledger); ledgers.add(lk);
      if (!(Number(x.amount) > 0)) errors.push(tag + ' has an invalid loan amount.');
      if (!(Number(x.charge) >= 0)) errors.push(tag + ' has an invalid charge.');
      if (!isISO(x.date)) errors.push(tag + ' has an invalid loan date.');
      if (x.renewal && !isISO(x.renewal)) errors.push(tag + ' has an invalid renewal date.');
      if (!cids.has(x.cid)) errors.push(tag + ' refers to a customer that is not in the backup.');
      x.amount = Number(x.amount); x.charge = Number(x.charge) || 0; x.received = Number(x.received) || 0; x.renewalStatus = normalizeRenewalStatus(x.renewalStatus);
      x.imageIds = x.imageIds || []; x.renewalHistory = x.renewalHistory || []; x.receipts = x.receipts || [];
    });
    db.inspections.forEach((x, i) => { if (!isISO(x.date) || !x.branch || !(Number(x.charge) >= 0)) errors.push('Inspection #' + (i + 1) + ' is incomplete or has an invalid date/amount.'); x.charge = Number(x.charge) || 0; x.received = Number(x.received) || 0; x.packets = Number(x.packets) || 0; });
    db.settlements.forEach((t, i) => {
      if (!t.id) errors.push('Settlement #' + (i + 1) + ' is missing an id.');
      if (t.status === 'paid' && (!isISO(t.paidDate) || !(Number(t.paidAmount) > 0))) errors.push('Paid settlement ' + (t.ledger || '#' + (i + 1)) + ' has no valid payment date or amount.');
      t.history = t.history || [];
    });
    db.payments.forEach((p, i) => { if (!p.id || !ACCTS.includes(p.acct) || !isISO(p.date) || !(Number(p.amount) > 0)) errors.push('Settlement payment #' + (i + 1) + ' has an invalid account, date or amount.'); p.amount = Number(p.amount); p.status = p.status === 'reversed' ? 'reversed' : 'active'; p.history = p.history || []; });
    db.a2payments.forEach((p, i) => { if (!p.id || !isISO(p.date) || !(Number(p.amount) > 0)) errors.push('Appraiser 2 payment #' + (i + 1) + ' has an invalid id, date or amount.'); p.amount = Number(p.amount); });
    const loanIds = new Set(db.loans.map(l => l.id)); const seen = new Set();
    db.settlements.forEach(t => { if (t.loanId) { if (seen.has(t.loanId)) errors.push('Duplicate settlement for loan ' + t.ledger + '.'); seen.add(t.loanId); if (!loanIds.has(t.loanId)) warnings.push('Settlement ' + t.ledger + ' refers to a loan that is not in the backup.'); } });
    const s = db.settings; if (Math.abs(s.split1 + s.split2 + s.splitHelper - 100) > 0.001) errors.push('Income split percentages in the backup do not total 100%.');
    if (!errors.length) { ensureSettlements(db, new Date().toISOString()); }
    return { ok: !errors.length, errors, warnings, db, images };
  }
  function exportBackup(DB, images, meta) {
    return { format: 'golddesk-backup', schema: SCHEMA, exportedAt: new Date().toISOString(), app: 'GoldDesk Professional', meta: meta || {},
      data: { customers: DB.customers, loans: DB.loans, inspections: DB.inspections, settlements: DB.settlements, receivables: DB.receivables, holidays: DB.holidays, a2payments: DB.a2payments || [], payments: DB.payments || [], payMigrated: !!DB.payMigrated, settings: DB.settings, audit: DB.audit },
      images: images || {} };
  }

  const api = { SCHEMA, DEFAULT_SETTINGS, TAMIL_NOTICE, mergeSettings, emptyDB, uid, round2, toISO, parseISO, addDays, isISO, isSunday, rateDate, weekBounds, bounds, within, eachDay,
    calcFee, splitCharge, loanA1Income, inspectionBankPart, inspectionA1Income, inspectionCharge, balance, payStatus, incomeEvents, incomeBetween, totals, series,
    buildSettlement, ensureSettlements, markPaid, markUnpaid, unpaidSettlements, paidSettlements, paidTree, filterPaid,
    rupee, ACCTS, accounts, addPayment, editPayment, reversePayment, a2Unpaid: C_a2Unpaid, markPaidA2, markUnpaidA2, isArchived, normalizeRenewalStatus, renewalState, renewalList, renewalArchive, validateBackup, exportBackup, legacyToDB, COLLECTIONS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GDCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
