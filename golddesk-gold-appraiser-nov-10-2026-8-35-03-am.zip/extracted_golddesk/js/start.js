/* GoldDesk Professional — startup. */
(function () {
  'use strict';
  const GD = window.GD, St = window.GDStore, $ = GD.$;
  let raf = 0;
  const schedule = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => GD.refresh()); };
  async function boot() {
    $('today').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
    try { await St.init(); }
    catch (e) { document.getElementById('content').innerHTML = '<div class="card"><div class="notice err"><b>GoldDesk cannot store data in this browser.</b><br>' + GD.esc(e.message) + ' Try a normal (non-private) window, or install the app.</div></div>'; return; }
    Object.values(GD.pages).forEach(p => p.mount());
    document.querySelectorAll('[data-page]').forEach(b => b.addEventListener('click', () => GD.goPage(b.dataset.page)));
    const open = v => { $('sidebar').classList.toggle('open', v); $('overlay').classList.toggle('show', v); $('menuBtn').setAttribute('aria-expanded', v); };
    $('menuBtn').addEventListener('click', () => open(!$('sidebar').classList.contains('open')));
    $('overlay').addEventListener('click', () => open(false));
    addEventListener('keydown', e => { if (e.key === 'Escape') { open(false); if ($('modalbg').classList.contains('open')) GD.closeModal(); } });
    addEventListener('resize', () => { if (innerWidth > 900) open(false); });
    $('modalClose').onclick = $('modalCancel').onclick = () => GD.closeModal();
    let down = false; $('modalbg').addEventListener('mousedown', e => { down = e.target === $('modalbg'); }); $('modalbg').addEventListener('click', e => { if (down && e.target === $('modalbg')) GD.closeModal(); });
    $('modalSave').onclick = () => GD.runSave();
    St.subscribe(schedule);
    const start = location.hash.slice(1);
    GD.goPage(GD.pages[start] ? start : 'dashboard');
    addEventListener('hashchange', () => { const h = location.hash.slice(1); if (GD.pages[h] && h !== GD.current) GD.goPage(h); });
    setInterval(() => { $('today').textContent = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }); GD.refresh(); }, 60000);
    if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(() => {});
    window.__gdReady = true;
  }
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
})();
