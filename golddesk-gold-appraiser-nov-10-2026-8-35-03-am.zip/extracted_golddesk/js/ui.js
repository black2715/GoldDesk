/* GoldDesk Professional — UI shell, shared helpers, Dashboard, Analytics and Settings. */
(function (root) {
  'use strict';
  const C = root.GDCore, St = root.GDStore, db = () => St.state.db;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const today = () => C.toISO(new Date());
  const fmt = iso => iso ? iso.split('-').reverse().join('/') : '—';
  const N = () => { const s = db().settings; return { a1: s.appraiser1Name.trim() || 'Appraiser 1', a2: s.appraiser2Name.trim() || 'Appraiser 2', helper: s.helperName.trim() || 'Helper' }; };
  const pct = n => (Math.round(n * 100) / 100) + '%';
  const sc = s => s === 'Paid' ? 'paid' : s === 'Unpaid' ? 'unpaid' : 'partial';
  const set = (id, v) => { const e = $(id); if (e) e.textContent = v; };
  const GD = root.GD = { $, esc, money, today, fmt, N, pct, sc, set, pages: {}, current: 'dashboard' };

  /* ---------- toast ---------- */
  let toastT; GD.toast = (msg, kind) => { const t = $('toast'); t.textContent = msg; t.style.background = kind === 'err' ? '#9c2f3a' : ''; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), kind === 'err' ? 5000 : 2600); };

  /* ---------- modal ---------- */
  let modalCfg = null, lastFocus = null;
  GD.closeModal = () => { $('modalbg').classList.remove('open'); document.body.style.overflow = ''; $('modal').classList.remove('wide'); modalCfg = null; if (lastFocus && lastFocus.focus) lastFocus.focus(); };
  GD.openModal = cfg => {
    modalCfg = cfg; lastFocus = document.activeElement;
    $('modalTitle').textContent = cfg.title || ''; $('modalSub').textContent = cfg.sub || ''; $('modalBody').innerHTML = cfg.body || '<div></div>';
    $('modal').classList.toggle('wide', !!cfg.wide);
    const s = $('modalSave'), c = $('modalCancel'); s.hidden = !!cfg.hideSave; s.textContent = cfg.save || 'Save'; s.disabled = false; s.className = 'btn ' + (cfg.danger ? 'danger' : 'primary'); c.textContent = cfg.cancel || 'Cancel'; c.hidden = !!cfg.hideCancel;
    $('modalbg').classList.add('open'); document.body.style.overflow = 'hidden';
    if (cfg.onOpen) cfg.onOpen($('modalBody'));
    const f = $('modalBody').querySelector('input:not([type=hidden]):not([disabled]),select,textarea'); if (f && !cfg.noFocus && matchMedia('(min-width:721px)').matches) f.focus();
  };
  GD.modalError = msg => { let e = $('modalErr'); if (!e) { e = document.createElement('div'); e.id = 'modalErr'; e.className = 'notice err'; e.style.marginTop = '12px'; $('modalBody').appendChild(e); } e.textContent = msg; e.scrollIntoView({ block: 'nearest' }); };
  async function runSave() {
    if (!modalCfg || !modalCfg.onSave) return GD.closeModal();
    const s = $('modalSave'); s.disabled = true; const old = s.textContent; s.innerHTML = '<span class="spinner"></span>';
    try { const r = await modalCfg.onSave($('modalBody')); if (r !== false) GD.closeModal(); }
    catch (e) { GD.modalError(e.message || String(e)); }
    finally { s.disabled = false; s.textContent = old; }
  }
  GD.runSave = runSave;
  GD.confirm = o => new Promise(res => {
    let done = false; const fin = v => { if (!done) { done = true; res(v); } };
    GD.openModal({ title: o.title, body: '<div class="confirmbox">' + (o.html || '<p>' + esc(o.message) + '</p>') + '</div>', save: o.confirm || 'Confirm', danger: o.danger, noFocus: true,
      onSave: () => { fin(true); return true; } });
    const prev = modalCfg; const iv = setInterval(() => { if (modalCfg !== prev) { clearInterval(iv); fin(false); } }, 80);
  });

  /* ---------- image viewer (view larger + download) ---------- */
  GD.viewImage = async (id, name) => {
    const url = await St.imageURL(id); if (!url) return GD.toast('This image is not available on this device yet. Sync with your server or re-attach it.', 'err');
    const v = document.createElement('div'); v.className = 'gd-image-viewer';
    v.innerHTML = '<div class="gd-image-toolbar"><a class="btn teal" download="' + esc(name || id) + '.jpg" href="' + url + '">↓ Download</a><button class="btn" type="button">Close</button></div><img alt="">';
    v.querySelector('img').src = url; v.addEventListener('click', e => { if (e.target === v || e.target.tagName === 'BUTTON') v.remove(); }); document.body.appendChild(v);
  };
  GD.thumbs = async (container, ids, label) => {
    container.innerHTML = '';
    if (!ids.length) { container.innerHTML = '<div class="empty" style="width:100%">No image attached.</div>'; return; }
    for (const [i, id] of ids.entries()) {
      const url = await St.imageURL(id), d = document.createElement('div'); d.className = 'thumb';
      d.innerHTML = url ? '<img alt="' + esc(label || 'Image') + ' ' + (i + 1) + '"><div class="rowact"><button class="btn small" type="button">View</button><a class="btn small" download="' + esc((label || 'image') + '-' + (i + 1)) + '.jpg" href="' + url + '">Download</a></div>' : '<div class="empty">Image not on this device</div>';
      if (url) { d.querySelector('img').src = url; d.querySelector('img').onclick = d.querySelector('button').onclick = () => GD.viewImage(id, (label || 'image') + '-' + (i + 1)); }
      container.appendChild(d);
    }
  };

  /* ---------- navigation ---------- */
  const TITLES = { dashboard: 'Dashboard', customers: 'Customers', loans: 'Gold Loans', inspection: 'Inspection', settlements: 'Settlement', renewals: 'Renewals', rates: 'Gold Rate Card', analytics: 'Analytics & Reports', settings: 'Settings' };
  const drawer = open => { $('sidebar').classList.toggle('open', open); $('overlay').classList.toggle('show', open); $('menuBtn').setAttribute('aria-expanded', open); };
  GD.goPage = name => {
    if (!TITLES[name]) name = 'dashboard';
    document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + name));
    document.querySelectorAll('[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === name));
    set('crumb', TITLES[name]); GD.current = name; drawer(false); scrollTo(0, 0);
    if (GD.pages[name].enter) GD.pages[name].enter(); GD.refresh(); if (location.hash.slice(1) !== name) history.replaceState(null, '', '#' + name);
  };
  GD.refresh = () => {
    if (!St.state.ready) return;
    const n = N(); document.querySelectorAll('[data-name]').forEach(e => { e.textContent = n[e.dataset.name]; });
    set('sideName', n.a1); set('sideAvatar', n.a1.slice(0, 1).toUpperCase());
    const t = C.totals(db(), today()), unpaid = (a => [a.a2, a.hA1, a.hA2].filter(x => x.pending > 0).length)(C.accounts(db())), ren = C.renewalList(db(), today()).filter(x => C.renewalState(x, today()) !== 'Upcoming').length;
    const nd = $('navDue'); nd.hidden = !unpaid; nd.textContent = unpaid; const nr = $('navRenew'); nr.hidden = !ren; nr.textContent = ren;
    const ss = St.state.sync; let st;
    if (St.state.storageError) st = '<span class="errc">●</span> Save problem — export a backup';
    else if (ss.token) st = ss.status === 'syncing' ? '<span class="warnc">●</span> Syncing…' : ss.status === 'error' ? '<span class="errc">●</span> Sync failed — saved on device' : '<span class="online">●</span> Synced' + (ss.last ? ' ' + new Date(ss.last).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '');
    else st = '<span class="online">●</span> Saved on this device';
    $('storageState').innerHTML = st; void t;
    const p = GD.pages[GD.current]; if (p && p.render) p.render();
  };

  /* ================= DASHBOARD ================= */
  let wkOff = 0;
  const SC = [['loan', '＋', 'blue', 'Add Gold Loan'], ['customer', '♙', 'blue', 'Add Customer'], ['go:inspection', '◇', 'mint', 'Inspection'], ['go:settlements', '⇄', 'rose', 'Settlement'], ['go:rates', '₹', 'gold', 'Gold Rate Poster'], ['go:renewals', '◷', 'gold', 'Loan Renewal Reminder']];
  GD.pages.dashboard = {
    mount() {
      $('page-dashboard').innerHTML = `
<div class="welcome"><div><div class="eyebrow">Financial overview</div><h1>GoldDesk</h1></div></div>
<div class="qa"><div class="eyebrow" style="margin-bottom:8px">Quick Access</div><div class="shortcuts">${SC.map(x => `<button class="sc" data-sc="${x[0]}"><span class="mi ${x[2]}">${x[1]}</span>${x[3]}</button>`).join('')}</div></div>
<div class="grid dhero"><div class="card hero"><div class="metrichead"><span class="label"><span data-name="a1"></span> — Monthly income</span><span class="mi mint">₹</span></div><div class="value" id="dA1M">₹0</div><div class="foot" id="dMonthLbl"></div></div>
<div class="dtri"><div class="card"><div class="dsm"><span class="label"><span data-name="a2"></span> — Total unpaid</span><button class="btn small" data-go="settlements">Settle</button></div><div class="value" id="dA2U">₹0</div></div>
<div class="card"><div class="dsm"><span class="label"><span data-name="helper"></span> — Total unpaid</span><button class="btn small" data-go="settlements">Settle</button></div><div class="value" id="dHU">₹0</div><div class="foot" id="dHU2"></div></div>
</div></div>
<div class="card"><div class="titleline"><div><h2>Weekly income</h2><p><span data-name="a1"></span> · Monday – Saturday · <b id="dWkRange"></b></p></div><div class="wknav"><button class="btn small" data-wk="-1" aria-label="Previous week">‹</button><button class="btn small" data-wk="0">This week</button><button class="btn small" data-wk="1" aria-label="Next week">›</button></div></div>
<div class="incomeline"><div><div class="label">Week total</div><div class="big" id="dWkTotal">₹0</div></div></div><div id="dChart"></div></div>
`;
      $('page-dashboard').addEventListener('click', e => {
        const t = e.target.closest('[data-act],[data-go],[data-wk],[data-sc]'); if (!t) return;
        if (t.dataset.wk != null) { wkOff = t.dataset.wk === '0' ? 0 : wkOff + Number(t.dataset.wk); return GD.pages.dashboard.render(); }
        if (t.dataset.go) return GD.goPage(t.dataset.go);
        if (t.dataset.sc) return t.dataset.sc === 'loan' ? GD.forms.loan() : t.dataset.sc === 'customer' ? GD.forms.customer() : GD.goPage(t.dataset.sc.slice(3));
      });
    },
    render() {
      const D = db(), td = today(), t = C.totals(D, td), ref = C.addDays(td, wkOff * 7), sr = C.series(D, 'week', ref).filter(x => !x.sunday), [w0, w1] = C.weekBounds(ref);
      set('dA1M', money(t.month)); set('dMonthLbl', new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' }) + ' · calendar month');
      set('dA2U', money(t.a2Unpaid)); set('dHU', money(t.helperPending)); { const AC = C.accounts(D); set('dHU2', 'Borne by ' + N().a1 + ' only · accrued ' + money(AC.hA1.accrued) + ' · paid ' + money(AC.hA1.paid)); }
      set('dWkRange', fmt(w0) + ' – ' + fmt(C.addDays(w0, 5))); set('dWkTotal', money(sr.reduce((n, x) => n + x.value, 0)));
      GD.barChart($('dChart'), sr, 'week');
    }
  };
  GD.cust = id => db().customers.find(c => c.id === id) || { name: 'Unknown customer', mobile: '', address: '' };

  /* Bar chart: HTML/CSS bars so labels never overlap. Week → Mon..Sat six bars. */
  GD.barChart = (el, data, kind) => {
    const max = Math.max(1, ...data.map(d => Math.abs(d.value))), dense = data.length > 14;
    el.innerHTML = '<div class="barchart' + (dense ? ' dense' : '') + '" role="img" aria-label="Income chart">' + data.map(d => { const h = Math.max(2, Math.abs(d.value) / max * 150); return `<div class="col" title="${esc(d.key + ': ' + money(d.value))}">${dense ? '' : '<span class="val">' + (d.value ? money(d.value) : '') + '</span>'}<div class="bar2${d.value ? '' : ' zero'}${d.sunday ? ' sun' : ''}" style="height:${h}px"></div></div>`; }).join('') + '</div><div class="barlabels">' + data.map((d, i) => `<span>${dense && i % 2 ? '' : esc(d.label)}</span>`).join('') + '</div>';
  };

  /* ================= ANALYTICS ================= */
  GD.pages.analytics = {
    mount() {
      $('page-analytics').innerHTML = `
<div class="sectionhead"><div><div class="eyebrow">Business performance</div><h1>Analytics &amp; Reports</h1><p>Actual income by calendar period, pending receipts and settlement figures.</p></div><button class="btn primary" data-export>↓ Export data</button></div>
<div class="card" style="margin-bottom:15px"><div class="titleline"><div><h2>Financial history</h2><p>Year → Month → Week (Mon–Sat) → Day → Transactions</p></div><button class="btn small" id="hRec">＋ Income adjustment</button></div>
<div class="field" style="margin-bottom:10px"><input id="hSearch" type="search" placeholder="Search ledger, customer, branch, type, date (dd/mm/yyyy or yyyy-mm-dd)" aria-label="Search financial history"></div><div class="hier" id="hTree"></div></div>
<div class="card" style="margin-bottom:15px"><div class="titleline"><div><h2>Period analysis</h2><p>Day · Week (Mon–Sat) · Month (calendar) · Year (Jan–Dec)</p></div><span class="pill" id="aCaption"></span></div>
<div class="ctlgrid"><div class="field"><label for="aPeriod">Period</label><select id="aPeriod"><option value="day">Daily</option><option value="week">Weekly</option><option value="month" selected>Monthly</option><option value="year">Yearly</option></select></div>
<div class="field"><label for="aRef">Reference date</label><input id="aRef" type="date"></div></div>
<div class="incomeline"><div><div class="label"><span data-name="a1"></span> – actual income</div><div class="big" id="aIncome">₹0</div></div></div>
<div id="aChart"></div><div class="tablewrap" style="margin-top:14px"><table><thead><tr><th>Date</th><th>Type</th><th>Reference</th><th style="text-align:right">Amount</th></tr></thead><tbody id="aRows"></tbody></table></div></div>
<div class="grid metrics"><div class="card"><div class="label">Income this week</div><div class="value" id="aWeek">₹0</div></div><div class="card"><div class="label">Income this month</div><div class="value" id="aMonth">₹0</div></div><div class="card"><div class="label">Income this year</div><div class="value" id="aYear">₹0</div></div><div class="card"><div class="label">Average monthly income</div><div class="value" id="aAvg">₹0</div></div></div>
<div class="grid settingsgrid" style="margin-top:15px"><div class="card"><div class="titleline"><div><h2>Receivables</h2><p>Amounts still to be received</p></div></div>
<div class="setting"><div><strong>Loan charges pending</strong><small>Unpaid and partly paid loan charges</small></div><b id="aLoanPend">₹0</b></div><div class="setting"><div><strong>Inspection pending</strong><small>Unpaid inspection charges</small></div><b id="aInspPend">₹0</b></div><div class="setting"><div><strong>Adjustments pending</strong><small>Income adjustments awaiting receipt</small></div><b id="aRecPend">₹0</b></div><div class="setting"><div><strong>Total pending to receive</strong></div><b id="aPend">₹0</b></div></div>
<div class="card"><div class="titleline"><div><h2>Shares &amp; settlement</h2><p>From loan charges recorded</p></div></div>
<div class="setting"><div><strong>Total loan charges</strong><small>100% pool</small></div><b id="aPool">₹0</b></div><div class="setting"><div><strong><span data-name="a2"></span> – share</strong></div><b id="aA2">₹0</b></div><div class="setting"><div><strong><span data-name="helper"></span> – allocation</strong></div><b id="aHelper">₹0</b></div>
<div class="setting"><div><strong>Helper paid this week</strong><small>Settlements marked Paid</small></div><b id="aHPaid">₹0</b></div><div class="setting"><div><strong>Helper pending</strong><small><span data-name="a1"></span>’s unpaid half</small></div><b id="aHPend">₹0</b></div>
<div class="setting"><div><strong>Inspection income (month)</strong></div><b id="aInspMonth">₹0</b></div></div></div>`;
      $('aRef').value = today();
      ['aPeriod', 'aRef'].forEach(i => $(i).addEventListener('input', () => GD.pages.analytics.render()));
      $('page-analytics').querySelector('[data-export]').onclick = () => GD.exportBackup();
    },
    render() {
      const D = db(), period = $('aPeriod').value, ref = C.isISO($('aRef').value) ? $('aRef').value : today(), [a, b] = C.bounds(period, ref), ev = C.incomeEvents(D).filter(e => C.within(e.date, a, b)).sort((x, y) => y.date.localeCompare(x.date));
      set('aCaption', a === b ? fmt(a) : fmt(a) + ' – ' + fmt(b)); set('aIncome', money(ev.reduce((n, e) => n + e.amount, 0)));
      GD.barChart($('aChart'), C.series(D, period === 'day' ? 'week' : period, ref).map(x => period === 'day' ? Object.assign({}, x, { value: x.key === ref ? x.value : x.value }) : x), period);
      $('aRows').innerHTML = ev.map(e => `<tr><td>${fmt(e.date)}</td><td>${esc(e.type)}</td><td>${esc(e.ref)}</td><td style="text-align:right"><b>${money(e.amount)}</b></td></tr>`).join('') || '<tr><td colspan="4"><div class="empty"><b>No income in this period</b>Choose another date or period.</div></td></tr>';
      const t = C.totals(D, today());
      set('aWeek', money(t.week)); set('aMonth', money(t.month)); set('aYear', money(t.year)); set('aAvg', money(t.avgMonthly)); set('aLoanPend', money(t.pendLoans)); set('aInspPend', money(t.pendInsp)); set('aRecPend', money(t.pendRec)); set('aPend', money(t.pendingToReceive));
      set('aPool', money(t.loanPool)); set('aA2', money(t.a2Share)); set('aHelper', money(t.helperAllocation)); set('aHPaid', money(t.helperPaidWeek)); set('aHPend', money(t.helperPending)); set('aInspMonth', money(t.inspectionMonth));
    }
  };

  /* ---------- Financial history: Year → Month → Week → Day → Transactions ---------- */
  const openKeys = new Set(), MN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function txns(D) {
    const S = D.settings, o = [];
    D.loans.forEach(x => { const p = C.splitCharge(x.charge, S); o.push({ date: x.date, type: 'Loan charge', ref: x.ledger, who: GD.cust(x.cid).name, gross: p.charge, a1: p.a1, a2: p.a2, h: p.helper, recv: x.received || 0, due: C.balance(x), st: C.payStatus(x) }); });
    D.inspections.forEach(x => o.push({ date: x.date, type: 'Inspection', ref: x.branch, who: '', gross: x.charge, a1: C.inspectionA1Income(x, S), recv: x.received || 0, due: C.balance(x), st: C.payStatus(x) }));
    D.payments.filter(p => p.status !== 'reversed').forEach(p => o.push({ date: p.date, type: 'Settlement payment', ref: p.acct === 'a2' ? 'Appraiser 2' : 'Helper', who: p.note || '', gross: p.amount, st: 'Paid' }));
    D.receivables.forEach(r => { o.push({ date: r.sourceDate, type: 'Income adjustment', ref: r.description || r.id, who: '', gross: -Number(r.amount || 0), st: '' }); (r.payments || []).forEach(p => o.push({ date: p.date, type: 'Adjustment received', ref: r.description || r.id, who: '', gross: Number(p.amount || 0), st: 'Paid' })); });
    return o.filter(x => C.isISO(x.date));
  }
  function renderHistory() {
    const D = db(), q = $('hSearch').value.trim().toLowerCase(), hol = new Map(D.holidays.map(h => [h.date, h.name]));
    const rows = txns(D).filter(x => !q || [x.type, x.ref, x.who, x.st, x.date, fmt(x.date)].join(' ').toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date));
    const sum = l => l.reduce((n, x) => n + (x.a1 || 0), 0), grp = (l, f) => { const m = new Map(); l.forEach(x => { const k = f(x); (m.get(k) || m.set(k, []).get(k)).push(x); }); return [...m]; };
    const det = (key, title, sub, inner) => `<details data-k="${key}" ${(q || openKeys.has(key)) ? 'open' : ''}><summary><span>${title}</span><small>${sub}</small></summary>${inner}</details>`;
    const sub = l => 'Appraiser 1 ' + money(sum(l)) + ' · ' + l.length + ' record' + (l.length > 1 ? 's' : '');
    $('hTree').innerHTML = rows.map(() => '').join('') + (grp(rows, x => x.date.slice(0, 4)).map(([y, ly]) => det(y, y, sub(ly),
      grp(ly, x => x.date.slice(0, 7)).map(([m, lm]) => det(m, MN[+m.slice(5) - 1], sub(lm),
        grp(lm, x => C.weekBounds(x.date)[0]).sort((a, b) => a[0].localeCompare(b[0])).map(([w, lw], i) => det('w' + w, 'Week ' + (i + 1) + ' <small>' + fmt(w) + ' – ' + fmt(C.addDays(w, 5)) + '</small>', sub(lw),
          grp(lw, x => x.date).map(([d, ld]) => { const dow = C.parseISO(d).getDay(), tag = hol.has(d) ? hol.get(d) : dow === 0 ? 'Sunday holiday' : dow === 6 ? 'Saturday' : '';
            return det('d' + d, new Date(d + 'T00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'long' }) + (tag ? '<span class="hbadge">' + esc(tag) + '</span>' : ''), sub(ld),
              '<div class="tablewrap"><table><thead><tr><th>Type</th><th>Ref</th><th style="text-align:right">Gross</th><th style="text-align:right">A1</th><th style="text-align:right">A2</th><th style="text-align:right">Helper</th><th style="text-align:right">Received</th><th style="text-align:right">Due</th><th>Status</th></tr></thead><tbody>' + ld.map(x => `<tr><td>${esc(x.type)}</td><td>${esc(x.ref)}${x.who ? '<small> · ' + esc(x.who) + '</small>' : ''}</td><td style="text-align:right">${money(x.gross)}</td><td style="text-align:right">${x.a1 == null ? '—' : money(x.a1)}</td><td style="text-align:right">${x.a2 == null ? '—' : money(x.a2)}</td><td style="text-align:right">${x.h == null ? '—' : money(x.h)}</td><td style="text-align:right">${x.recv == null ? '—' : money(x.recv)}</td><td style="text-align:right">${x.due == null ? '—' : money(x.due)}</td><td>${esc(x.st)}</td></tr>`).join('') + '</tbody></table></div>'); }).join(''))).join(''))).join(''))).join('')
      || '<div class="empty"><b>' + (q ? 'No records match your search.' : 'No financial records yet.') + '</b></div>');
  }
  (function () { const A = GD.pages.analytics, m = A.mount, r = A.render;
    A.mount = function () { m.call(this); $('hSearch').addEventListener('input', renderHistory); $('hRec').onclick = () => GD.forms.receivable(); $('hTree').addEventListener('toggle', e => { const k = e.target.dataset && e.target.dataset.k; if (k && !$('hSearch').value) e.target.open ? openKeys.add(k) : openKeys.delete(k); }, true); };
    A.render = function () { r.call(this); renderHistory(); }; })();

  /* ================= SETTINGS ================= */
  GD.download = (blob, name) => root.GDReminder.download(blob, name);
  GD.exportBackup = async () => {
    try { const b = await St.exportAll(); GD.download(new Blob([JSON.stringify(b)], { type: 'application/json' }), 'golddesk-backup-' + today() + '.json'); GD.toast('Backup exported (' + b.data.loans.length + ' loans, ' + Object.keys(b.images).length + ' images)'); }
    catch (e) { GD.toast('Export failed: ' + e.message, 'err'); }
  };
  async function importFile(file) {
    let json; try { json = JSON.parse(await file.text()); } catch (e) { return GD.openModal({ title: 'Cannot import this file', body: '<div class="notice err">This file is not valid JSON, so it cannot be a GoldDesk backup. Nothing was changed.</div>', hideSave: true, cancel: 'Close' }); }
    const v = C.validateBackup(json);
    if (!v.ok) return GD.openModal({ title: 'Backup not imported', sub: 'Nothing was changed. Your current data is safe.', body: '<div class="notice err"><b>This backup has problems:</b><ul class="errlist">' + v.errors.slice(0, 12).map(e => '<li>' + esc(e) + '</li>').join('') + (v.errors.length > 12 ? '<li>…and ' + (v.errors.length - 12) + ' more</li>' : '') + '</ul></div>', hideSave: true, cancel: 'Close' });
    const d = v.db, ok = await GD.confirm({ title: 'Replace all current data?', confirm: 'Replace with backup', danger: true,
      html: `<p>This backup contains <b>${d.customers.length}</b> customers, <b>${d.loans.length}</b> loans, <b>${d.inspections.length}</b> inspections, <b>${d.settlements.length}</b> helper settlements and <b>${Object.keys(v.images).length}</b> images.</p><p>Everything currently in GoldDesk on this device will be replaced. A safety copy of the current data is kept so you can undo this.</p>` + (v.warnings.length ? '<div class="notice" style="margin-top:8px">' + v.warnings.map(esc).join('<br>') + '</div>' : '') });
    if (!ok) return;
    try { await St.importValidated(v); GD.toast('Backup imported successfully'); GD.pages.settings.enter(); } catch (e) { GD.toast('Import failed: ' + e.message + ' Your previous data was kept.', 'err'); }
  }
  const SF = ['split1', 'split2', 'splitHelper', 'bankShareValue', 'feeStandard', 'feeHigh', 'feeThreshold', 'feePercent', 'feeMin', 'feeMax', 'packetRate', 'reminderDays'];
  GD.pages.settings = {
    mount() {
      $('page-settings').innerHTML = `
<div class="sectionhead"><div><div class="eyebrow">Business settings</div><h1>Settings</h1><p>Names, income split, charges, reminders and data. Changes apply across the whole application.</p></div><button class="btn primary" id="saveSettings">Save settings</button></div>
<div class="grid settingsgrid">
<div class="card"><div class="titleline"><div><h2>Names &amp; income split</h2><p>Names appear everywhere in the app. Shares must total 100%.</p></div><span class="pill" id="splitTotal">Total 100%</span></div>
<div class="setting"><div class="grow"><strong>Appraiser 1</strong><small>Name · share of loan charges</small></div><div class="pair"><input class="name" id="appraiser1Name" maxlength="40" aria-label="Appraiser 1 name"><input class="pct" id="split1" type="number" step=".01" min="0" aria-label="Appraiser 1 share %"></div></div>
<div class="setting"><div class="grow"><strong>Appraiser 2</strong><small>Name · share of loan charges</small></div><div class="pair"><input class="name" id="appraiser2Name" maxlength="40" aria-label="Appraiser 2 name"><input class="pct" id="split2" type="number" step=".01" min="0" aria-label="Appraiser 2 share %"></div></div>
<div class="setting"><div class="grow"><strong>Helper</strong><small>Name · allocation, borne entirely by Appraiser 1</small></div><div class="pair"><input class="name" id="helperName" maxlength="40" aria-label="Helper name"><input class="pct" id="splitHelper" type="number" step=".01" min="0" aria-label="Helper share %"></div></div>
<div class="setting"><div><strong>Bank share of inspection</strong><small>Percentage or fixed amount</small></div><select id="bankMode"><option value="percent">Percent</option><option value="fixed">Fixed ₹</option></select></div>
<div class="setting"><div><strong>Bank share value</strong><small>Decimals allowed</small></div><input id="bankShareValue" type="number" step=".01" min="0"></div></div>
<div class="card"><div class="titleline"><div><h2>Loan charge rules</h2><p>Fixed fee or percentage with limits.</p></div></div>
<div class="setting"><div><strong>Standard fee (up to threshold)</strong><small>Per loan</small></div><input id="feeStandard" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Fee above threshold</strong></div><input id="feeHigh" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Threshold (₹)</strong><small>Editable boundary</small></div><input id="feeThreshold" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Calculation mode</strong><small>Fixed or percentage</small></div><select id="feeMode"><option value="fixed">Fixed fee</option><option value="percent">Percentage</option></select></div>
<div class="setting"><div><strong>Percentage (%)</strong><small>Used in percentage mode</small></div><input id="feePercent" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Minimum fee (₹)</strong><small>Optional floor</small></div><input id="feeMin" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Maximum fee (₹)</strong><small>0 means no maximum</small></div><input id="feeMax" type="number" step=".01" min="0"></div></div>
<div class="card"><div class="titleline"><div><h2>Inspection &amp; renewals</h2><p>Packet rate, reminder window and branch.</p></div></div>
<div class="setting"><div><strong>Charge per packet (₹)</strong><small>Inspection rate</small></div><input id="packetRate" type="number" step=".01" min="0"></div>
<div class="setting"><div><strong>Renewal reminder period</strong><small>Show loans due within this many days</small></div><input id="reminderDays" type="number" min="0" max="365"></div>
<div class="setting"><div><strong>Branch name (reminder card)</strong></div><input class="name" id="branchName" maxlength="40"></div>
<div class="setting"><div><strong>Branch code (reminder card)</strong></div><input class="name" id="branchCode" maxlength="12"></div>
<div class="setting"><div><strong>Gold-rate WhatsApp number</strong><small>Chat opened by Share Gold Rate (10-digit Indian number or with country code)</small></div><input class="name" id="rateWhatsapp" inputmode="tel" maxlength="16"></div>
<div class="setting"><div><strong>Rate fetch relay URL</strong><small>Address of your Cloudflare Worker (gold-rate-worker.js). Required for Refresh to work from a browser.</small></div><input class="name" id="rateProxy" maxlength="300" placeholder="https://gold-rate.yourname.workers.dev"></div></div>
<div class="card"><div class="titleline"><div><h2>Holiday calendar</h2><p>Mark non-working days. Sundays are always non-working.</p></div></div>
<div class="toolbar"><div class="field"><label for="holDate">Date</label><input id="holDate" type="date"></div><div class="field" style="flex:1"><label for="holName">Reason</label><input id="holName" placeholder="e.g. Bank holiday"></div><button class="btn primary" id="holAdd" type="button">Add</button></div><div id="holRows"></div></div>
<div class="card" id="dataCard" style="grid-column:1/-1"><div class="titleline"><div><h2>Data &amp; storage</h2><p id="storageNote">Your records</p></div></div>
<div id="storageNotice"></div>
<div class="setting"><div><strong>Export backup</strong><small>Customers, loans, images, inspections, settlements, settings and history in one file.</small></div><button class="btn" id="btnExport">↓ Export backup</button></div>
<div class="setting"><div><strong>Import backup</strong><small>Validated before anything is replaced. A safety copy of current data is kept.</small></div><button class="btn primary" id="btnImport">↑ Import backup</button></div><input type="file" id="importFile" accept=".json,application/json" hidden>
<div class="setting"><div><strong>Undo last import</strong><small>Restores the copy taken just before the last import.</small></div><button class="btn" id="btnUndoImport">Restore previous data</button></div>
<h3 style="font-size:13px;margin:22px 0 6px">Server account &amp; sync</h3><div id="syncBox"></div></div>
</div>`;
      const pg = $('page-settings');
      $('saveSettings').onclick = () => GD.pages.settings.save();
      ['split1', 'split2', 'splitHelper'].forEach(i => $(i).addEventListener('input', GD.pages.settings.total));
      $('btnExport').onclick = GD.exportBackup; $('btnImport').onclick = () => $('importFile').click();
      $('importFile').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) await importFile(f); };
      $('btnUndoImport').onclick = async () => { if (await GD.confirm({ title: 'Restore the data from before the last import?', message: 'Current data will be replaced by the safety copy.', confirm: 'Restore', danger: true })) { try { await St.restorePreImport(); GD.toast('Previous data restored'); GD.pages.settings.enter(); } catch (e) { GD.toast(e.message, 'err'); } } };
      $('holDate').value = today();
      $('holAdd').onclick = () => { const d = $('holDate').value; if (!C.isISO(d)) return GD.toast('Choose a holiday date', 'err'); St.commit(D => { const o = D.holidays.find(h => h.date === d); if (o) { o.name = $('holName').value.trim() || 'Holiday'; St.touch('holidays', o, 'Updated'); } else { const h = { id: C.uid('HOL'), date: d, name: $('holName').value.trim() || 'Holiday' }; D.holidays.push(h); St.touch('holidays', h, 'Created'); } }); $('holName').value = ''; GD.toast('Holiday saved'); };
      $('holRows').addEventListener('click', e => { const b = e.target.closest('[data-del]'); if (b) { St.remove('holidays', b.dataset.del); } });
      GD.syncUI.mount($('syncBox'));
    },
    enter() { const s = db().settings; SF.forEach(k => { $(k).value = s[k]; }); ['appraiser1Name', 'appraiser2Name', 'helperName', 'branchName', 'branchCode', 'bankMode', 'feeMode', 'rateWhatsapp', 'rateProxy'].forEach(k => { $(k).value = s[k] || ''; }); GD.pages.settings.total(); },
    total() { const n = (Number($('split1').value) || 0) + (Number($('split2').value) || 0) + (Number($('splitHelper').value) || 0), ok = Math.abs(n - 100) < .001, p = $('splitTotal'); p.textContent = 'Total ' + (Math.round(n * 100) / 100) + '%'; p.style.color = ok ? '#16846e' : '#c34d59'; p.style.background = ok ? '#e6f8f1' : '#fff0f1'; },
    save() {
      const v = {}; SF.forEach(k => { v[k] = Number($(k).value); if (!isFinite(v[k]) || v[k] < 0) v[k] = NaN; });
      const bad = SF.find(k => isNaN(v[k])); if (bad) return GD.toast('Enter a valid number in every settings field.', 'err');
      if (Math.abs(v.split1 + v.split2 + v.splitHelper - 100) > .001) return GD.toast('Income split must total exactly 100%.', 'err');
      const names = { appraiser1Name: $('appraiser1Name').value.trim(), appraiser2Name: $('appraiser2Name').value.trim(), helperName: $('helperName').value.trim() };
      if (!names.appraiser1Name || !names.appraiser2Name || !names.helperName) return GD.toast('Appraiser 1, Appraiser 2 and Helper names cannot be empty.', 'err');
      const wa = $('rateWhatsapp').value.replace(/\D/g, ''); if (wa && wa.length < 10) return GD.toast('Enter a valid WhatsApp number (at least 10 digits).', 'err');
      St.commit(D => { Object.assign(D.settings, v, names, { rateWhatsapp: $('rateWhatsapp').value.trim(), rateProxy: $('rateProxy').value.trim(), bankMode: $('bankMode').value, feeMode: $('feeMode').value, branchName: $('branchName').value.trim(), branchCode: $('branchCode').value.trim() }); });
      St.touchSettings(); GD.toast('Settings saved'); GD.refresh();
    },
    render() {
      $('holRows').innerHTML = db().holidays.slice().sort((a, b) => b.date.localeCompare(a.date)).map(h => `<div class="setting"><div><strong>${fmt(h.date)}</strong><small>${esc(h.name)}</small></div><button class="btn small danger" data-del="${h.id}">Remove</button></div>`).join('') || '<div class="sub">No holidays added.</div>';
      $('storageNotice').innerHTML = St.state.storageError ? '<div class="notice err">' + esc(St.state.storageError) + '</div>' : '<div class="notice ok">All records are saved on this device' + (St.state.sync.token ? ' and synchronised with your server.' : '. Sign in below to synchronise with a server and use the same account on mobile and desktop.') + '</div>';
      GD.syncUI.render();
    }
  };

  /* ---------- server account / sync panel ---------- */
  GD.syncUI = {
    mount(box) {
      box.innerHTML = `<div id="syncOut"></div><div id="syncForm"><div class="formgrid"><div class="field full"><label for="syUrl">Server address</label><input id="syUrl" placeholder="https://golddesk.example.com  (leave empty if this page is served by your server)" autocomplete="url"></div><div class="field"><label for="syEmail">Email</label><input id="syEmail" type="email" autocomplete="username"></div><div class="field"><label for="syPass">Password</label><input id="syPass" type="password" autocomplete="current-password"></div></div>
<div class="actions" style="margin-top:12px"><button class="btn primary" id="syLogin">Sign in &amp; sync</button><button class="btn" id="syReg">Create account</button></div><div id="syErr"></div></div>
<div id="syActions" hidden><div class="actions"><button class="btn teal" id="syNow">↻ Sync now</button><button class="btn" id="syOut">Sign out</button></div></div><div id="syConf"></div>`;
      const go = async reg => { $('syErr').innerHTML = ''; try { $('syLogin').disabled = $('syReg').disabled = true; await St.login($('syUrl').value.trim(), $('syEmail').value.trim(), $('syPass').value, reg); $('syPass').value = ''; GD.toast('Signed in and synchronised'); } catch (e) { $('syErr').innerHTML = '<div class="notice err" style="margin-top:10px">' + esc(e.message === 'Failed to fetch' ? 'Cannot reach the server. Check the address and your connection.' : e.message) + '</div>'; } finally { $('syLogin').disabled = $('syReg').disabled = false; GD.refresh(); } };
      $('syLogin').onclick = () => go(false); $('syReg').onclick = () => go(true);
      $('syNow').onclick = async () => { try { await St.syncNow(); GD.toast('Synchronised'); } catch (e) { GD.toast('Sync failed: ' + e.message, 'err'); } };
      $('syOut').onclick = async () => { await St.logout(); GD.toast('Signed out. Records stay on this device.'); GD.refresh(); };
      $('syConf').addEventListener('click', async e => { const b = e.target.closest('[data-c]'); if (b) { await St.resolveConflict(Number(b.dataset.c), b.dataset.mine === '1'); GD.refresh(); } });
    },
    render() {
      const s = St.state.sync, on = !!s.token; $('syncForm').hidden = on; $('syActions').hidden = !on;
      if (!$('syUrl').value && s.url) $('syUrl').value = s.url; if (!$('syEmail').value && s.email) $('syEmail').value = s.email;
      $('syncOut').innerHTML = on ? '<div class="notice ' + (s.status === 'error' ? 'err' : 'ok') + '" style="margin-bottom:10px">Signed in as <b>' + esc(s.email) + '</b>' + (s.last ? ' · last synced ' + new Date(s.last).toLocaleString('en-IN') : '') + (s.status === 'error' ? '<br>Last sync failed: ' + esc(s.error || '') + '. Your data is safe on this device and will retry.' : '') + '</div>' : '<div class="notice" style="margin-bottom:10px">Not signed in. Records are stored only on this device.</div>';
      $('syConf').innerHTML = s.conflicts.length ? '<h3 style="font-size:13px;margin:16px 0 6px">Changes that need your attention (' + s.conflicts.length + ')</h3>' + s.conflicts.map((c, i) => `<div class="setting"><div><strong>${esc(c.coll)} · ${esc(c.id)}</strong><small>Edited on two devices at once. The server copy is in use; your version is kept here.</small></div><div class="rowact"><button class="btn small" data-c="${i}" data-mine="0">Keep server copy</button><button class="btn small primary" data-c="${i}" data-mine="1">Use my version</button></div></div>`).join('') : '';
    }
  };
})(window);
