/* GoldDesk — Gold Rate poster renderer.
   The poster is the supplied PNB reference artwork (logo, coins, ornaments, borders, labels)
   with only the date, market rate, percentages and advance values drawn live on top. */
(function (root) {
  'use strict';
  const W = 1086, H = 1448;
  const MAROON = '#8b0118', INK = '#8b0118', WHITE = '#ffffff';
  // Layout measured from the reference image (pixels at 1086×1448).
  const L = {
    date: { cx: 615,  base: 628,  size: 85, max: 313, color: WHITE },
    rate: { right: 1022, base: 769,  size: 92, max: 334, color: WHITE },
    pctA: { right: 629,  base: 941,  size: 72, max: 125, color: INK },
    pctN: { right: 630,  base: 1125, size: 74, max: 126, color: INK },
    valA: { right: 1039, base: 943,  size: 88, max: 342, color: INK },
    valN: { right: 1039, base: 1130, size: 92, max: 319, color: INK }
  };
  const inr = n => Math.round(Number(n) || 0).toLocaleString('en-IN');
  async function loadAssets(base) {
    base = base || '';
    if (!loadAssets._p) {
      loadAssets._p = (async () => {
        const ff = new FontFace('GDPoster', 'url(' + (GD_ASSETS['fonts/PlayfairDisplay-Lining.ttf']) + ')', { weight: '400 900' });
        await ff.load(); document.fonts.add(ff);
        const fr = new FontFace('GDRupee', 'url(' + (GD_ASSETS['fonts/NotoSansTamil.ttf']) + ')', { weight: '100 900' });
        await fr.load(); document.fonts.add(fr);
        const img = new Image(); img.src = GD_ASSETS['assets/poster-template.jpg'];
        await img.decode();
        return img;
      })();
    }
    return loadAssets._p;
  }
  // Draw one line. Digits use Playfair (lining figures); the rupee sign uses a bold sans glyph and the
  // trailing "/-" dash is drawn as a bar, because both are much heavier in the reference artwork.
  // Lines are condensed horizontally (never stretched) when they would exceed the reference width.
  function put(ctx, text, spec, align) {
    const hasRupee = text.charAt(0) === '₹', hasDash = text.slice(-2) === '/-';
    let body = text; if (hasRupee) body = body.slice(2); if (hasDash) body = body.slice(0, -1);
    const fs = spec.size;
    ctx.font = '900 ' + fs + 'px GDPoster'; const bw = ctx.measureText(body).width;
    ctx.font = '800 ' + (fs * 0.96) + 'px GDRupee'; const rw = hasRupee ? ctx.measureText('₹').width : 0;
    const gapR = hasRupee ? fs * 0.22 : 0, gapD = hasDash ? fs * 0.04 : 0, dw = hasDash ? fs * 0.42 : 0;
    const total = rw + gapR + bw + gapD + dw, sx = Math.min(1, spec.max / total);
    const x0 = align === 'center' ? spec.cx - total * sx / 2 : spec.right - total * sx;
    ctx.save(); ctx.translate(x0, spec.base); ctx.scale(sx, 1);
    ctx.fillStyle = ctx.strokeStyle = spec.color; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left'; ctx.lineJoin = 'round';
    let x = 0;
    if (hasRupee) { ctx.font = '800 ' + (fs * 0.96) + 'px GDRupee'; ctx.fillText('₹', 0, 0); x += rw + gapR; }
    ctx.font = '900 ' + fs + 'px GDPoster'; ctx.lineWidth = Math.max(1, fs * 0.02);
    ctx.fillText(body, x, 0); ctx.strokeText(body, x, 0); x += bw + gapD;
    if (hasDash) ctx.fillRect(x, -fs * 0.40, dw, fs * 0.095);
    ctx.restore();
  }
  /* data: { date:'2026-11-03', rate: 12599, agriPct: 85, nonAgriPct: 68 }  → canvas */
  async function render(data, base) {
    const img = await loadAssets(base);
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0, W, H);
    const [y, m, d] = String(data.date).split('-');
    const rate = Number(data.rate) || 0;
    put(ctx, d + '.' + m + '.' + y.slice(2), L.date, 'center');
    put(ctx, '₹ ' + inr(rate) + '/-', L.rate, 'right');
    put(ctx, data.agriPct + '%', L.pctA, 'right');
    put(ctx, data.nonAgriPct + '%', L.pctN, 'right');
    put(ctx, '₹ ' + inr(rate * data.agriPct / 100) + '/-', L.valA, 'right');
    put(ctx, '₹ ' + inr(rate * data.nonAgriPct / 100) + '/-', L.valN, 'right');
    return c;
  }
  const api = { render, loadAssets, W, H, layout: L, inr };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GDPoster = api;
})(typeof window !== 'undefined' ? window : globalThis);
