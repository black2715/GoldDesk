# Security Specification for GoldDesk Gold Appraiser

## 1. Data Invariants
1. **User Isolation**: All subcollections (`customers`, `loans`, `inspections`, `payments`, `settlements`, `receivables`, `holidays`, `settings`, `photos`) are nested under `/users/{userId}/`. Only authenticated users matching `request.auth.uid == userId` can read or write their own documents.
2. **Identity Integrity**: `userId` field inside document payloads must strictly match `request.auth.uid`.
3. **No Cross-User Leaks**: Blanket reads across all users are strictly denied.
4. **Permanent Photo Retention**: Photos are safeguarded against accidental deletion.
5. **Settlement Accounting Integrity**: Settlement payments can be marked active or reversed with audit history, and amounts must be positive numbers.

## 2. The Dirty Dozen Payloads
1. **Ghost User Write**: Attempt to write a customer under `/users/otherUser/customers/c1` -> `PERMISSION_DENIED`.
2. **Unauthenticated Read**: Attempt to read `/users/user1/loans` without authentication -> `PERMISSION_DENIED`.
3. **Mismatched userId**: Attempt to write a loan with payload `{ userId: "attacker", ... }` under `/users/user1/loans/l1` -> `PERMISSION_DENIED`.
4. **Invalid Path ID**: Attempt to use an oversized/poisoned ID (`/users/user1/customers/$$$###128bytejunk...`) -> `PERMISSION_DENIED`.
5. **Direct RBAC Claim Tampering**: Attempt to set client custom claims or bypass user scope -> `PERMISSION_DENIED`.
6. **Negative Loan Charge**: Attempt to create a loan with `{ amount: 100000, charge: -500 }` -> `PERMISSION_DENIED`.
7. **Negative Payment Amount**: Attempt to record a settlement payment with `{ amount: -100 }` -> `PERMISSION_DENIED`.
8. **Invalid ISO Date**: Attempt to save loan date as `"yesterday"` instead of `"YYYY-MM-DD"` -> `PERMISSION_DENIED`.
9. **Blanket Collection Query**: Attempt to query `collectionGroup('customers')` without userId filter -> `PERMISSION_DENIED`.
10. **Shadow Field Injection**: Attempt to inject arbitrary administrative fields into settings -> `PERMISSION_DENIED`.
11. **Cross-Tenant Photo Theft**: Attempt to access `/users/user2/photos/p1` while logged in as `user1` -> `PERMISSION_DENIED`.
12. **Tampering with Audit History**: Attempt to forge timestamps or overwrite root document rules -> `PERMISSION_DENIED`.
